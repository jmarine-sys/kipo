--
-- PostgreSQL database dump
--

\restrict qqZbKaGM48j2aFVAPpFEBu3mHCfawWZUAZdqu2MVQIgzVXBTk4lKFSw6gqOMGYp

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP EVENT TRIGGER IF EXISTS pgrst_drop_watch;
DROP EVENT TRIGGER IF EXISTS pgrst_ddl_watch;
DROP EVENT TRIGGER IF EXISTS issue_pg_net_access;
DROP EVENT TRIGGER IF EXISTS issue_pg_graphql_access;
DROP EVENT TRIGGER IF EXISTS issue_pg_cron_access;
DROP EVENT TRIGGER IF EXISTS issue_graphql_placeholder;
DROP EVENT TRIGGER IF EXISTS ensure_rls;
DROP PUBLICATION IF EXISTS supabase_realtime;
DROP POLICY IF EXISTS transaction_activo_rw ON public.transaction;
DROP POLICY IF EXISTS scheduled_event_activo_rw ON public.scheduled_event;
DROP POLICY IF EXISTS price_activo_rw ON public.price;
DROP POLICY IF EXISTS portfolio_member_rw ON public.portfolio;
DROP POLICY IF EXISTS portfolio_account_activo ON public.portfolio_account;
DROP POLICY IF EXISTS ledger_member_ver ON public.ledger_member;
DROP POLICY IF EXISTS ledger_member_admin ON public.ledger_member;
DROP POLICY IF EXISTS ledger_activo ON public.ledger;
DROP POLICY IF EXISTS instrument_activo_up ON public.instrument;
DROP POLICY IF EXISTS instrument_activo_rw ON public.instrument;
DROP POLICY IF EXISTS instrument_activo_ro ON public.instrument;
DROP POLICY IF EXISTS instrument_activo_del ON public.instrument;
DROP POLICY IF EXISTS fx_rate_activo_rw ON public.fx_rate;
DROP POLICY IF EXISTS entry_activo_rw ON public.entry;
DROP POLICY IF EXISTS category_activo_up ON public.category;
DROP POLICY IF EXISTS category_activo_rw ON public.category;
DROP POLICY IF EXISTS category_activo_ro ON public.category;
DROP POLICY IF EXISTS category_activo_del ON public.category;
DROP POLICY IF EXISTS budget_activo_rw ON public.budget;
DROP POLICY IF EXISTS active_ledger_self ON public.active_ledger;
DROP POLICY IF EXISTS account_activo_up ON public.account;
DROP POLICY IF EXISTS account_activo_rw ON public.account;
DROP POLICY IF EXISTS account_activo_ro ON public.account;
DROP POLICY IF EXISTS account_activo_del ON public.account;
ALTER TABLE IF EXISTS ONLY storage.vector_indexes DROP CONSTRAINT IF EXISTS vector_indexes_bucket_id_fkey;
ALTER TABLE IF EXISTS ONLY storage.s3_multipart_uploads_parts DROP CONSTRAINT IF EXISTS s3_multipart_uploads_parts_upload_id_fkey;
ALTER TABLE IF EXISTS ONLY storage.s3_multipart_uploads_parts DROP CONSTRAINT IF EXISTS s3_multipart_uploads_parts_bucket_id_fkey;
ALTER TABLE IF EXISTS ONLY storage.s3_multipart_uploads DROP CONSTRAINT IF EXISTS s3_multipart_uploads_bucket_id_fkey;
ALTER TABLE IF EXISTS ONLY storage.objects DROP CONSTRAINT IF EXISTS "objects_bucketId_fkey";
ALTER TABLE IF EXISTS ONLY public.transaction DROP CONSTRAINT IF EXISTS transaction_sched_same_ledger;
ALTER TABLE IF EXISTS ONLY public.transaction DROP CONSTRAINT IF EXISTS transaction_ledger_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transaction DROP CONSTRAINT IF EXISTS transaction_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.scheduled_event DROP CONSTRAINT IF EXISTS scheduled_event_ledger_id_fkey;
ALTER TABLE IF EXISTS ONLY public.scheduled_event DROP CONSTRAINT IF EXISTS sched_counter_same_ledger;
ALTER TABLE IF EXISTS ONLY public.scheduled_event DROP CONSTRAINT IF EXISTS sched_category_same_ledger;
ALTER TABLE IF EXISTS ONLY public.scheduled_event DROP CONSTRAINT IF EXISTS sched_account_same_ledger;
ALTER TABLE IF EXISTS ONLY public.price DROP CONSTRAINT IF EXISTS price_ledger_id_fkey;
ALTER TABLE IF EXISTS ONLY public.price DROP CONSTRAINT IF EXISTS price_instrument_id_fkey;
ALTER TABLE IF EXISTS ONLY public.portfolio DROP CONSTRAINT IF EXISTS portfolio_ledger_id_fkey;
ALTER TABLE IF EXISTS ONLY public.portfolio_account DROP CONSTRAINT IF EXISTS pa_portfolio_same_ledger;
ALTER TABLE IF EXISTS ONLY public.portfolio_account DROP CONSTRAINT IF EXISTS pa_account_same_ledger;
ALTER TABLE IF EXISTS ONLY public.ledger_member DROP CONSTRAINT IF EXISTS ledger_member_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ledger_member DROP CONSTRAINT IF EXISTS ledger_member_ledger_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ledger_invite DROP CONSTRAINT IF EXISTS ledger_invite_used_by_fkey;
ALTER TABLE IF EXISTS ONLY public.ledger_invite DROP CONSTRAINT IF EXISTS ledger_invite_ledger_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ledger_invite DROP CONSTRAINT IF EXISTS ledger_invite_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.account DROP CONSTRAINT IF EXISTS instrument_same_ledger;
ALTER TABLE IF EXISTS ONLY public.instrument DROP CONSTRAINT IF EXISTS instrument_ledger_id_fkey;
ALTER TABLE IF EXISTS ONLY public.fx_rate DROP CONSTRAINT IF EXISTS fx_rate_ledger_id_fkey;
ALTER TABLE IF EXISTS ONLY public.entry DROP CONSTRAINT IF EXISTS entry_tx_same_ledger;
ALTER TABLE IF EXISTS ONLY public.entry DROP CONSTRAINT IF EXISTS entry_ledger_id_fkey;
ALTER TABLE IF EXISTS ONLY public.entry DROP CONSTRAINT IF EXISTS entry_category_same_ledger;
ALTER TABLE IF EXISTS ONLY public.entry DROP CONSTRAINT IF EXISTS entry_account_same_ledger;
ALTER TABLE IF EXISTS ONLY public.category DROP CONSTRAINT IF EXISTS category_parent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.category DROP CONSTRAINT IF EXISTS category_ledger_id_fkey;
ALTER TABLE IF EXISTS ONLY public.budget DROP CONSTRAINT IF EXISTS budget_ledger_id_fkey;
ALTER TABLE IF EXISTS ONLY public.budget DROP CONSTRAINT IF EXISTS budget_category_same_ledger;
ALTER TABLE IF EXISTS ONLY public.active_ledger DROP CONSTRAINT IF EXISTS active_ledger_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.active_ledger DROP CONSTRAINT IF EXISTS active_ledger_ledger_id_fkey;
ALTER TABLE IF EXISTS ONLY public.account DROP CONSTRAINT IF EXISTS account_ledger_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.webauthn_credentials DROP CONSTRAINT IF EXISTS webauthn_credentials_user_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.webauthn_challenges DROP CONSTRAINT IF EXISTS webauthn_challenges_user_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.sso_domains DROP CONSTRAINT IF EXISTS sso_domains_sso_provider_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.sessions DROP CONSTRAINT IF EXISTS sessions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.sessions DROP CONSTRAINT IF EXISTS sessions_oauth_client_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.scim_users DROP CONSTRAINT IF EXISTS scim_users_user_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.scim_users DROP CONSTRAINT IF EXISTS scim_users_sso_provider_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.scim_tokens DROP CONSTRAINT IF EXISTS scim_tokens_sso_provider_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.saml_relay_states DROP CONSTRAINT IF EXISTS saml_relay_states_sso_provider_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.saml_relay_states DROP CONSTRAINT IF EXISTS saml_relay_states_flow_state_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.saml_providers DROP CONSTRAINT IF EXISTS saml_providers_sso_provider_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.refresh_tokens DROP CONSTRAINT IF EXISTS refresh_tokens_session_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.one_time_tokens DROP CONSTRAINT IF EXISTS one_time_tokens_user_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.oauth_consents DROP CONSTRAINT IF EXISTS oauth_consents_user_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.oauth_consents DROP CONSTRAINT IF EXISTS oauth_consents_client_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.oauth_authorizations DROP CONSTRAINT IF EXISTS oauth_authorizations_user_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.oauth_authorizations DROP CONSTRAINT IF EXISTS oauth_authorizations_client_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.mfa_recovery_codes DROP CONSTRAINT IF EXISTS mfa_recovery_codes_mfa_recovery_code_set_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.mfa_recovery_code_sets DROP CONSTRAINT IF EXISTS mfa_recovery_code_sets_user_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.mfa_recovery_code_sets DROP CONSTRAINT IF EXISTS mfa_recovery_code_sets_mfa_factor_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.mfa_factors DROP CONSTRAINT IF EXISTS mfa_factors_user_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.mfa_challenges DROP CONSTRAINT IF EXISTS mfa_challenges_auth_factor_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.mfa_amr_claims DROP CONSTRAINT IF EXISTS mfa_amr_claims_session_id_fkey;
ALTER TABLE IF EXISTS ONLY auth.identities DROP CONSTRAINT IF EXISTS identities_user_id_fkey;
DROP TRIGGER IF EXISTS update_objects_updated_at ON storage.objects;
DROP TRIGGER IF EXISTS protect_objects_delete ON storage.objects;
DROP TRIGGER IF EXISTS protect_buckets_delete ON storage.buckets;
DROP TRIGGER IF EXISTS enforce_bucket_name_length_trigger ON storage.buckets;
DROP TRIGGER IF EXISTS tr_check_filters ON realtime.subscription;
DROP TRIGGER IF EXISTS transaction_touch ON public.transaction;
DROP TRIGGER IF EXISTS transaction_balances ON public.entry;
DROP TRIGGER IF EXISTS scheduled_event_fin_de_mes ON public.scheduled_event;
DROP TRIGGER IF EXISTS instrument_lamina ON public.instrument;
DROP TRIGGER IF EXISTS entry_unit_matches_account ON public.entry;
DROP TRIGGER IF EXISTS category_two_levels ON public.category;
DROP TRIGGER IF EXISTS account_cartera_del_broker ON public.account;
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE OR REPLACE VIEW public.account_balance AS
SELECT
    NULL::uuid AS account_id,
    NULL::uuid AS ledger_id,
    NULL::text AS name,
    NULL::text AS kind,
    NULL::text AS valuation,
    NULL::text AS unit,
    NULL::boolean AS is_spendable,
    NULL::text AS institution,
    NULL::numeric AS balance,
    NULL::bigint AS movimientos;
DROP INDEX IF EXISTS storage.vector_indexes_name_bucket_id_idx;
DROP INDEX IF EXISTS storage.objects_bucket_id_name_version_key;
DROP INDEX IF EXISTS storage.name_prefix_search;
DROP INDEX IF EXISTS storage.idx_objects_null_version;
DROP INDEX IF EXISTS storage.idx_objects_current_version;
DROP INDEX IF EXISTS storage.idx_objects_bucket_id_name_lower;
DROP INDEX IF EXISTS storage.idx_objects_bucket_id_name;
DROP INDEX IF EXISTS storage.idx_multipart_uploads_list;
DROP INDEX IF EXISTS storage.buckets_analytics_unique_name_idx;
DROP INDEX IF EXISTS storage.bucketid_objname;
DROP INDEX IF EXISTS storage.bname;
DROP INDEX IF EXISTS realtime.subscription_subscription_id_entity_filters_action_filter_selec;
DROP INDEX IF EXISTS realtime.messages_inserted_at_topic_index;
DROP INDEX IF EXISTS realtime.ix_realtime_subscription_entity;
DROP INDEX IF EXISTS public.transaction_sched_idx;
DROP INDEX IF EXISTS public.transaction_ledger_date_idx;
DROP INDEX IF EXISTS public.transaction_cross_ref_idx;
DROP INDEX IF EXISTS public.portfolio_account_cuenta_idx;
DROP INDEX IF EXISTS public.entry_transaction_idx;
DROP INDEX IF EXISTS public.entry_ledger_category_idx;
DROP INDEX IF EXISTS public.entry_ledger_account_idx;
DROP INDEX IF EXISTS public.category_system_role_idx;
DROP INDEX IF EXISTS auth.webauthn_credentials_user_id_idx;
DROP INDEX IF EXISTS auth.webauthn_credentials_credential_id_key;
DROP INDEX IF EXISTS auth.webauthn_challenges_user_id_idx;
DROP INDEX IF EXISTS auth.webauthn_challenges_expires_at_idx;
DROP INDEX IF EXISTS auth.users_is_anonymous_idx;
DROP INDEX IF EXISTS auth.users_instance_id_idx;
DROP INDEX IF EXISTS auth.users_instance_id_email_idx;
DROP INDEX IF EXISTS auth.users_email_partial_key;
DROP INDEX IF EXISTS auth.user_id_created_at_idx;
DROP INDEX IF EXISTS auth.unique_phone_factor_per_user;
DROP INDEX IF EXISTS auth.sso_providers_resource_id_pattern_idx;
DROP INDEX IF EXISTS auth.sso_providers_resource_id_idx;
DROP INDEX IF EXISTS auth.sso_domains_sso_provider_id_idx;
DROP INDEX IF EXISTS auth.sso_domains_domain_idx;
DROP INDEX IF EXISTS auth.sessions_user_id_idx;
DROP INDEX IF EXISTS auth.sessions_oauth_client_id_idx;
DROP INDEX IF EXISTS auth.sessions_not_after_idx;
DROP INDEX IF EXISTS auth.scim_users_user_name_key;
DROP INDEX IF EXISTS auth.scim_users_user_name_idx;
DROP INDEX IF EXISTS auth.scim_users_user_id_idx;
DROP INDEX IF EXISTS auth.scim_users_updated_at_idx;
DROP INDEX IF EXISTS auth.scim_users_sso_provider_id_idx;
DROP INDEX IF EXISTS auth.scim_users_id_idx;
DROP INDEX IF EXISTS auth.scim_users_external_id_key;
DROP INDEX IF EXISTS auth.scim_users_deleted_at_idx;
DROP INDEX IF EXISTS auth.scim_users_created_at_idx;
DROP INDEX IF EXISTS auth.scim_tokens_token_hash_key;
DROP INDEX IF EXISTS auth.scim_tokens_sso_provider_id_idx;
DROP INDEX IF EXISTS auth.scim_tokens_revoked_at_idx;
DROP INDEX IF EXISTS auth.scim_tokens_expires_at_idx;
DROP INDEX IF EXISTS auth.saml_relay_states_sso_provider_id_idx;
DROP INDEX IF EXISTS auth.saml_relay_states_for_email_idx;
DROP INDEX IF EXISTS auth.saml_relay_states_created_at_idx;
DROP INDEX IF EXISTS auth.saml_providers_sso_provider_id_idx;
DROP INDEX IF EXISTS auth.refresh_tokens_updated_at_idx;
DROP INDEX IF EXISTS auth.refresh_tokens_session_id_revoked_idx;
DROP INDEX IF EXISTS auth.refresh_tokens_parent_idx;
DROP INDEX IF EXISTS auth.refresh_tokens_instance_id_user_id_idx;
DROP INDEX IF EXISTS auth.refresh_tokens_instance_id_idx;
DROP INDEX IF EXISTS auth.recovery_token_idx;
DROP INDEX IF EXISTS auth.reauthentication_token_idx;
DROP INDEX IF EXISTS auth.one_time_tokens_user_id_token_type_key;
DROP INDEX IF EXISTS auth.one_time_tokens_token_hash_hash_idx;
DROP INDEX IF EXISTS auth.one_time_tokens_relates_to_hash_idx;
DROP INDEX IF EXISTS auth.oauth_consents_user_order_idx;
DROP INDEX IF EXISTS auth.oauth_consents_active_user_client_idx;
DROP INDEX IF EXISTS auth.oauth_consents_active_client_idx;
DROP INDEX IF EXISTS auth.oauth_clients_deleted_at_idx;
DROP INDEX IF EXISTS auth.oauth_auth_pending_exp_idx;
DROP INDEX IF EXISTS auth.mfa_recovery_codes_set_id_idx;
DROP INDEX IF EXISTS auth.mfa_factors_user_id_idx;
DROP INDEX IF EXISTS auth.mfa_factors_user_friendly_name_unique;
DROP INDEX IF EXISTS auth.mfa_challenge_created_at_idx;
DROP INDEX IF EXISTS auth.idx_users_name;
DROP INDEX IF EXISTS auth.idx_users_last_sign_in_at_desc;
DROP INDEX IF EXISTS auth.idx_users_email;
DROP INDEX IF EXISTS auth.idx_users_created_at_desc;
DROP INDEX IF EXISTS auth.idx_user_id_auth_method;
DROP INDEX IF EXISTS auth.idx_oauth_client_states_created_at;
DROP INDEX IF EXISTS auth.idx_auth_code;
DROP INDEX IF EXISTS auth.identities_user_id_idx;
DROP INDEX IF EXISTS auth.identities_email_idx;
DROP INDEX IF EXISTS auth.flow_state_created_at_idx;
DROP INDEX IF EXISTS auth.factor_id_created_at_idx;
DROP INDEX IF EXISTS auth.email_change_token_new_idx;
DROP INDEX IF EXISTS auth.email_change_token_current_idx;
DROP INDEX IF EXISTS auth.custom_oauth_providers_provider_type_idx;
DROP INDEX IF EXISTS auth.custom_oauth_providers_identifier_idx;
DROP INDEX IF EXISTS auth.custom_oauth_providers_enabled_idx;
DROP INDEX IF EXISTS auth.custom_oauth_providers_created_at_idx;
DROP INDEX IF EXISTS auth.confirmation_token_idx;
DROP INDEX IF EXISTS auth.audit_logs_instance_id_idx;
ALTER TABLE IF EXISTS ONLY supabase_migrations.schema_migrations DROP CONSTRAINT IF EXISTS schema_migrations_pkey;
ALTER TABLE IF EXISTS ONLY storage.vector_indexes DROP CONSTRAINT IF EXISTS vector_indexes_pkey;
ALTER TABLE IF EXISTS ONLY storage.s3_multipart_uploads DROP CONSTRAINT IF EXISTS s3_multipart_uploads_pkey;
ALTER TABLE IF EXISTS ONLY storage.s3_multipart_uploads_parts DROP CONSTRAINT IF EXISTS s3_multipart_uploads_parts_pkey;
ALTER TABLE IF EXISTS ONLY storage.objects DROP CONSTRAINT IF EXISTS objects_pkey;
ALTER TABLE IF EXISTS ONLY storage.migrations DROP CONSTRAINT IF EXISTS migrations_pkey;
ALTER TABLE IF EXISTS ONLY storage.migrations DROP CONSTRAINT IF EXISTS migrations_name_key;
ALTER TABLE IF EXISTS ONLY storage.buckets_vectors DROP CONSTRAINT IF EXISTS buckets_vectors_pkey;
ALTER TABLE IF EXISTS ONLY storage.buckets DROP CONSTRAINT IF EXISTS buckets_pkey;
ALTER TABLE IF EXISTS ONLY storage.buckets_analytics DROP CONSTRAINT IF EXISTS buckets_analytics_pkey;
ALTER TABLE IF EXISTS ONLY realtime.schema_migrations DROP CONSTRAINT IF EXISTS schema_migrations_pkey;
ALTER TABLE IF EXISTS ONLY realtime.subscription DROP CONSTRAINT IF EXISTS pk_subscription;
ALTER TABLE IF EXISTS ONLY realtime.messages DROP CONSTRAINT IF EXISTS messages_pkey;
ALTER TABLE IF EXISTS realtime.messages DROP CONSTRAINT IF EXISTS messages_payload_exclusive;
ALTER TABLE IF EXISTS ONLY public.transaction DROP CONSTRAINT IF EXISTS transaction_pkey;
ALTER TABLE IF EXISTS ONLY public.transaction DROP CONSTRAINT IF EXISTS transaction_id_ledger_id_key;
ALTER TABLE IF EXISTS ONLY public.scheduled_event DROP CONSTRAINT IF EXISTS scheduled_event_pkey;
ALTER TABLE IF EXISTS ONLY public.scheduled_event DROP CONSTRAINT IF EXISTS scheduled_event_id_ledger_uk;
ALTER TABLE IF EXISTS ONLY public.price DROP CONSTRAINT IF EXISTS price_pkey;
ALTER TABLE IF EXISTS ONLY public.portfolio DROP CONSTRAINT IF EXISTS portfolio_pkey;
ALTER TABLE IF EXISTS ONLY public.portfolio DROP CONSTRAINT IF EXISTS portfolio_ledger_id_name_key;
ALTER TABLE IF EXISTS ONLY public.portfolio DROP CONSTRAINT IF EXISTS portfolio_id_ledger_id_key;
ALTER TABLE IF EXISTS ONLY public.portfolio_account DROP CONSTRAINT IF EXISTS portfolio_account_pkey;
ALTER TABLE IF EXISTS ONLY public.ledger DROP CONSTRAINT IF EXISTS ledger_pkey;
ALTER TABLE IF EXISTS ONLY public.ledger_member DROP CONSTRAINT IF EXISTS ledger_member_pkey;
ALTER TABLE IF EXISTS ONLY public.ledger_invite DROP CONSTRAINT IF EXISTS ledger_invite_pkey;
ALTER TABLE IF EXISTS ONLY public.instrument DROP CONSTRAINT IF EXISTS instrument_pkey;
ALTER TABLE IF EXISTS ONLY public.instrument DROP CONSTRAINT IF EXISTS instrument_ledger_id_symbol_key;
ALTER TABLE IF EXISTS ONLY public.instrument DROP CONSTRAINT IF EXISTS instrument_id_ledger_id_key;
ALTER TABLE IF EXISTS ONLY public.fx_rate DROP CONSTRAINT IF EXISTS fx_rate_pkey;
ALTER TABLE IF EXISTS ONLY public.entry DROP CONSTRAINT IF EXISTS entry_pkey;
ALTER TABLE IF EXISTS ONLY public.category DROP CONSTRAINT IF EXISTS category_pkey;
ALTER TABLE IF EXISTS ONLY public.category DROP CONSTRAINT IF EXISTS category_id_ledger_id_key;
ALTER TABLE IF EXISTS ONLY public.budget DROP CONSTRAINT IF EXISTS budget_pkey;
ALTER TABLE IF EXISTS ONLY public.budget DROP CONSTRAINT IF EXISTS budget_ledger_id_category_id_period_key;
ALTER TABLE IF EXISTS ONLY public.active_ledger DROP CONSTRAINT IF EXISTS active_ledger_pkey;
ALTER TABLE IF EXISTS ONLY public.account DROP CONSTRAINT IF EXISTS account_pkey;
ALTER TABLE IF EXISTS ONLY public.account DROP CONSTRAINT IF EXISTS account_id_ledger_id_key;
ALTER TABLE IF EXISTS ONLY auth.webauthn_credentials DROP CONSTRAINT IF EXISTS webauthn_credentials_pkey;
ALTER TABLE IF EXISTS ONLY auth.webauthn_challenges DROP CONSTRAINT IF EXISTS webauthn_challenges_pkey;
ALTER TABLE IF EXISTS ONLY auth.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY auth.users DROP CONSTRAINT IF EXISTS users_phone_key;
ALTER TABLE IF EXISTS ONLY auth.sso_providers DROP CONSTRAINT IF EXISTS sso_providers_pkey;
ALTER TABLE IF EXISTS ONLY auth.sso_domains DROP CONSTRAINT IF EXISTS sso_domains_pkey;
ALTER TABLE IF EXISTS ONLY auth.sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
ALTER TABLE IF EXISTS ONLY auth.scim_users DROP CONSTRAINT IF EXISTS scim_users_pkey;
ALTER TABLE IF EXISTS ONLY auth.scim_tokens DROP CONSTRAINT IF EXISTS scim_tokens_pkey;
ALTER TABLE IF EXISTS ONLY auth.schema_migrations DROP CONSTRAINT IF EXISTS schema_migrations_pkey;
ALTER TABLE IF EXISTS ONLY auth.saml_relay_states DROP CONSTRAINT IF EXISTS saml_relay_states_pkey;
ALTER TABLE IF EXISTS ONLY auth.saml_providers DROP CONSTRAINT IF EXISTS saml_providers_pkey;
ALTER TABLE IF EXISTS ONLY auth.saml_providers DROP CONSTRAINT IF EXISTS saml_providers_entity_id_key;
ALTER TABLE IF EXISTS ONLY auth.refresh_tokens DROP CONSTRAINT IF EXISTS refresh_tokens_token_unique;
ALTER TABLE IF EXISTS ONLY auth.refresh_tokens DROP CONSTRAINT IF EXISTS refresh_tokens_pkey;
ALTER TABLE IF EXISTS ONLY auth.one_time_tokens DROP CONSTRAINT IF EXISTS one_time_tokens_pkey;
ALTER TABLE IF EXISTS ONLY auth.oauth_consents DROP CONSTRAINT IF EXISTS oauth_consents_user_client_unique;
ALTER TABLE IF EXISTS ONLY auth.oauth_consents DROP CONSTRAINT IF EXISTS oauth_consents_pkey;
ALTER TABLE IF EXISTS ONLY auth.oauth_clients DROP CONSTRAINT IF EXISTS oauth_clients_pkey;
ALTER TABLE IF EXISTS ONLY auth.oauth_client_states DROP CONSTRAINT IF EXISTS oauth_client_states_pkey;
ALTER TABLE IF EXISTS ONLY auth.oauth_authorizations DROP CONSTRAINT IF EXISTS oauth_authorizations_pkey;
ALTER TABLE IF EXISTS ONLY auth.oauth_authorizations DROP CONSTRAINT IF EXISTS oauth_authorizations_authorization_id_key;
ALTER TABLE IF EXISTS ONLY auth.oauth_authorizations DROP CONSTRAINT IF EXISTS oauth_authorizations_authorization_code_key;
ALTER TABLE IF EXISTS ONLY auth.mfa_recovery_codes DROP CONSTRAINT IF EXISTS mfa_recovery_codes_pkey;
ALTER TABLE IF EXISTS ONLY auth.mfa_recovery_code_sets DROP CONSTRAINT IF EXISTS mfa_recovery_code_sets_user_id_key;
ALTER TABLE IF EXISTS ONLY auth.mfa_recovery_code_sets DROP CONSTRAINT IF EXISTS mfa_recovery_code_sets_pkey;
ALTER TABLE IF EXISTS ONLY auth.mfa_recovery_code_sets DROP CONSTRAINT IF EXISTS mfa_recovery_code_sets_mfa_factor_id_key;
ALTER TABLE IF EXISTS ONLY auth.mfa_factors DROP CONSTRAINT IF EXISTS mfa_factors_pkey;
ALTER TABLE IF EXISTS ONLY auth.mfa_factors DROP CONSTRAINT IF EXISTS mfa_factors_last_challenged_at_key;
ALTER TABLE IF EXISTS ONLY auth.mfa_challenges DROP CONSTRAINT IF EXISTS mfa_challenges_pkey;
ALTER TABLE IF EXISTS ONLY auth.mfa_amr_claims DROP CONSTRAINT IF EXISTS mfa_amr_claims_session_id_authentication_method_pkey;
ALTER TABLE IF EXISTS ONLY auth.instances DROP CONSTRAINT IF EXISTS instances_pkey;
ALTER TABLE IF EXISTS ONLY auth.identities DROP CONSTRAINT IF EXISTS identities_provider_id_provider_unique;
ALTER TABLE IF EXISTS ONLY auth.identities DROP CONSTRAINT IF EXISTS identities_pkey;
ALTER TABLE IF EXISTS ONLY auth.flow_state DROP CONSTRAINT IF EXISTS flow_state_pkey;
ALTER TABLE IF EXISTS ONLY auth.custom_oauth_providers DROP CONSTRAINT IF EXISTS custom_oauth_providers_pkey;
ALTER TABLE IF EXISTS ONLY auth.custom_oauth_providers DROP CONSTRAINT IF EXISTS custom_oauth_providers_identifier_key;
ALTER TABLE IF EXISTS ONLY auth.audit_log_entries DROP CONSTRAINT IF EXISTS audit_log_entries_pkey;
ALTER TABLE IF EXISTS ONLY auth.mfa_amr_claims DROP CONSTRAINT IF EXISTS amr_id_pk;
ALTER TABLE IF EXISTS auth.refresh_tokens ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS supabase_migrations.schema_migrations;
DROP TABLE IF EXISTS storage.vector_indexes;
DROP TABLE IF EXISTS storage.s3_multipart_uploads_parts;
DROP TABLE IF EXISTS storage.s3_multipart_uploads;
DROP TABLE IF EXISTS storage.objects;
DROP TABLE IF EXISTS storage.migrations;
DROP TABLE IF EXISTS storage.buckets_vectors;
DROP TABLE IF EXISTS storage.buckets_analytics;
DROP TABLE IF EXISTS storage.buckets;
DROP TABLE IF EXISTS realtime.subscription;
DROP TABLE IF EXISTS realtime.schema_migrations;
DROP TABLE IF EXISTS realtime.messages;
DROP VIEW IF EXISTS public.valor_portafolio;
DROP VIEW IF EXISTS public.valor_inversion;
DROP VIEW IF EXISTS public.valor_cuenta;
DROP VIEW IF EXISTS public.upcoming;
DROP TABLE IF EXISTS public.scheduled_event;
DROP VIEW IF EXISTS public.resumen_tarjeta;
DROP VIEW IF EXISTS public.posicion;
DROP TABLE IF EXISTS public.price;
DROP VIEW IF EXISTS public.mi_libro;
DROP VIEW IF EXISTS public.medicion_faltante;
DROP TABLE IF EXISTS public.ledger_member;
DROP TABLE IF EXISTS public.ledger_invite;
DROP TABLE IF EXISTS public.ledger;
DROP TABLE IF EXISTS public.instrument;
DROP TABLE IF EXISTS public.fx_rate;
DROP VIEW IF EXISTS public.flujo_portafolio;
DROP TABLE IF EXISTS public.portfolio_account;
DROP TABLE IF EXISTS public.portfolio;
DROP VIEW IF EXISTS public.flujo_inversion;
DROP VIEW IF EXISTS public.entry_detail;
DROP VIEW IF EXISTS public.cuota;
DROP TABLE IF EXISTS public.transaction;
DROP VIEW IF EXISTS public.category_usage;
DROP TABLE IF EXISTS public.entry;
DROP TABLE IF EXISTS public.category;
DROP TABLE IF EXISTS public.budget;
DROP TABLE IF EXISTS public.active_ledger;
DROP VIEW IF EXISTS public.account_balance;
DROP TABLE IF EXISTS public.account;
DROP TABLE IF EXISTS auth.webauthn_credentials;
DROP TABLE IF EXISTS auth.webauthn_challenges;
DROP TABLE IF EXISTS auth.users;
DROP TABLE IF EXISTS auth.sso_providers;
DROP TABLE IF EXISTS auth.sso_domains;
DROP TABLE IF EXISTS auth.sessions;
DROP TABLE IF EXISTS auth.scim_users;
DROP TABLE IF EXISTS auth.scim_tokens;
DROP TABLE IF EXISTS auth.schema_migrations;
DROP TABLE IF EXISTS auth.saml_relay_states;
DROP TABLE IF EXISTS auth.saml_providers;
DROP SEQUENCE IF EXISTS auth.refresh_tokens_id_seq;
DROP TABLE IF EXISTS auth.refresh_tokens;
DROP TABLE IF EXISTS auth.one_time_tokens;
DROP TABLE IF EXISTS auth.oauth_consents;
DROP TABLE IF EXISTS auth.oauth_clients;
DROP TABLE IF EXISTS auth.oauth_client_states;
DROP TABLE IF EXISTS auth.oauth_authorizations;
DROP TABLE IF EXISTS auth.mfa_recovery_codes;
DROP TABLE IF EXISTS auth.mfa_recovery_code_sets;
DROP TABLE IF EXISTS auth.mfa_factors;
DROP TABLE IF EXISTS auth.mfa_challenges;
DROP TABLE IF EXISTS auth.mfa_amr_claims;
DROP TABLE IF EXISTS auth.instances;
DROP TABLE IF EXISTS auth.identities;
DROP TABLE IF EXISTS auth.flow_state;
DROP TABLE IF EXISTS auth.custom_oauth_providers;
DROP TABLE IF EXISTS auth.audit_log_entries;
DROP FUNCTION IF EXISTS storage.update_updated_at_column();
DROP FUNCTION IF EXISTS storage.search_v2(prefix text, bucket_name text, limits integer, levels integer, start_after text, sort_order text, sort_column text, sort_column_after text);
DROP FUNCTION IF EXISTS storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text);
DROP FUNCTION IF EXISTS storage.search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text);
DROP FUNCTION IF EXISTS storage.protect_delete();
DROP FUNCTION IF EXISTS storage.operation();
DROP FUNCTION IF EXISTS storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer, start_after text, next_token text, sort_order text);
DROP FUNCTION IF EXISTS storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, next_key_token text, next_upload_token text);
DROP FUNCTION IF EXISTS storage.get_size_by_bucket();
DROP FUNCTION IF EXISTS storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text);
DROP FUNCTION IF EXISTS storage.foldername(name text);
DROP FUNCTION IF EXISTS storage.filename(name text);
DROP FUNCTION IF EXISTS storage.extension(name text);
DROP FUNCTION IF EXISTS storage.enforce_bucket_name_length();
DROP FUNCTION IF EXISTS storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb);
DROP FUNCTION IF EXISTS storage.allow_only_operation(expected_operation text);
DROP FUNCTION IF EXISTS storage.allow_any_operation(expected_operations text[]);
DROP FUNCTION IF EXISTS realtime.wal2json_escape_identifier(name text);
DROP FUNCTION IF EXISTS realtime.topic();
DROP FUNCTION IF EXISTS realtime.to_regrole(role_name text);
DROP FUNCTION IF EXISTS realtime.subscription_check_filters();
DROP FUNCTION IF EXISTS realtime.send_binary(payload bytea, event text, topic text, private boolean);
DROP FUNCTION IF EXISTS realtime.send(payload jsonb, event text, topic text, private boolean);
DROP FUNCTION IF EXISTS realtime.quote_wal2json(entity regclass);
DROP FUNCTION IF EXISTS realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer);
DROP FUNCTION IF EXISTS realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]);
DROP FUNCTION IF EXISTS realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean);
DROP FUNCTION IF EXISTS realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text);
DROP FUNCTION IF EXISTS realtime."cast"(val text, type_ regtype);
DROP FUNCTION IF EXISTS realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]);
DROP FUNCTION IF EXISTS realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text);
DROP FUNCTION IF EXISTS realtime.apply_rls(wal jsonb, max_record_bytes integer);
DROP FUNCTION IF EXISTS public.vender_activo(p_pos uuid, p_unidades numeric, p_hacia uuid, p_monto numeric, p_on date);
DROP FUNCTION IF EXISTS public.touch_updated_at();
DROP FUNCTION IF EXISTS public.skip_scheduled(p_event uuid);
DROP FUNCTION IF EXISTS public.sembrar_libro(p_ledger uuid);
DROP FUNCTION IF EXISTS public.rls_auto_enable();
DROP FUNCTION IF EXISTS public.register_scheduled(p_event uuid, p_amount numeric, p_on date, p_account uuid);
DROP FUNCTION IF EXISTS public.register_maturity(p_event uuid, p_total numeric, p_to uuid, p_on date);
DROP FUNCTION IF EXISTS public.my_ledgers();
DROP FUNCTION IF EXISTS public.my_ledger();
DROP FUNCTION IF EXISTS public.my_fx_source();
DROP FUNCTION IF EXISTS public.mi_rol();
DROP FUNCTION IF EXISTS public.lamina_por_defecto();
DROP FUNCTION IF EXISTS public.lamina_de(p_kind text);
DROP FUNCTION IF EXISTS public.handle_new_user();
DROP FUNCTION IF EXISTS public.eliminar_libro(p_ledger uuid);
DROP FUNCTION IF EXISTS public.cuentas_de_libro(p_ledger uuid);
DROP FUNCTION IF EXISTS public.create_transaction(p_occurred_on date, p_kind text, p_entries jsonb, p_description text, p_installments integer);
DROP FUNCTION IF EXISTS public.create_plazo_fijo(p_nombre text, p_desde uuid, p_capital numeric, p_vence date, p_esperado numeric, p_institucion text, p_on date);
DROP FUNCTION IF EXISTS public.crear_libro(p_nombre text);
DROP FUNCTION IF EXISTS public.crear_invitacion(p_role text);
DROP FUNCTION IF EXISTS public.cotizacion_al(p_fecha date, p_fuente text, p_base text, p_quote text);
DROP FUNCTION IF EXISTS public.cotizacion(p_fecha date, p_fuente text, p_base text, p_quote text);
DROP FUNCTION IF EXISTS public.convertir(p_monto numeric, p_unidad text, p_fecha date, p_medida text, p_fuente text);
DROP FUNCTION IF EXISTS public.comprar_activo(p_symbol text, p_nombre text, p_kind text, p_moneda text, p_decimals integer, p_desde uuid, p_monto numeric, p_unidades numeric, p_broker text, p_on date, p_ratio numeric, p_subyacente text);
DROP FUNCTION IF EXISTS public.check_transaction_balances();
DROP FUNCTION IF EXISTS public.check_entry_unit();
DROP FUNCTION IF EXISTS public.check_category_depth();
DROP FUNCTION IF EXISTS public.categoria_de_rol(p_ledger uuid, p_rol text);
DROP FUNCTION IF EXISTS public.cartera_del_broker();
DROP FUNCTION IF EXISTS public.cambiar_libro(p_ledger uuid);
DROP FUNCTION IF EXISTS public.avanzar_fecha(p_desde date, p_frecuencia text);
DROP FUNCTION IF EXISTS public.archivar_libro(p_ledger uuid);
DROP FUNCTION IF EXISTS public.aportar_a_libro(p_destino uuid, p_cuenta_origen uuid, p_cuenta_destino uuid, p_monto numeric, p_on date, p_detalle text);
DROP FUNCTION IF EXISTS public.ajustar_fin_de_mes();
DROP FUNCTION IF EXISTS public.aceptar_invitacion(p_code text);
DROP FUNCTION IF EXISTS pgbouncer.get_auth(p_usename text);
DROP FUNCTION IF EXISTS graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb);
DROP FUNCTION IF EXISTS extensions.set_graphql_placeholder();
DROP FUNCTION IF EXISTS extensions.pgrst_drop_watch();
DROP FUNCTION IF EXISTS extensions.pgrst_ddl_watch();
DROP FUNCTION IF EXISTS extensions.grant_pg_net_access();
DROP FUNCTION IF EXISTS extensions.grant_pg_graphql_access();
DROP FUNCTION IF EXISTS extensions.grant_pg_cron_access();
DROP FUNCTION IF EXISTS auth.uid();
DROP FUNCTION IF EXISTS auth.role();
DROP FUNCTION IF EXISTS auth.jwt();
DROP FUNCTION IF EXISTS auth.email();
DROP TYPE IF EXISTS storage.buckettype;
DROP TYPE IF EXISTS realtime.wal_rls;
DROP TYPE IF EXISTS realtime.wal_column;
DROP TYPE IF EXISTS realtime.user_defined_filter;
DROP TYPE IF EXISTS realtime.equality_op;
DROP TYPE IF EXISTS realtime.action;
DROP TYPE IF EXISTS auth.one_time_token_type;
DROP TYPE IF EXISTS auth.oauth_response_type;
DROP TYPE IF EXISTS auth.oauth_registration_type;
DROP TYPE IF EXISTS auth.oauth_client_type;
DROP TYPE IF EXISTS auth.oauth_authorization_status;
DROP TYPE IF EXISTS auth.factor_type;
DROP TYPE IF EXISTS auth.factor_status;
DROP TYPE IF EXISTS auth.code_challenge_method;
DROP TYPE IF EXISTS auth.aal_level;
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS supabase_vault;
DROP EXTENSION IF EXISTS pgcrypto;
DROP EXTENSION IF EXISTS pg_stat_statements;
DROP SCHEMA IF EXISTS vault;
DROP SCHEMA IF EXISTS supabase_migrations;
DROP SCHEMA IF EXISTS storage;
DROP SCHEMA IF EXISTS realtime;
DROP SCHEMA IF EXISTS pgbouncer;
DROP SCHEMA IF EXISTS graphql_public;
DROP SCHEMA IF EXISTS graphql;
DROP SCHEMA IF EXISTS extensions;
DROP SCHEMA IF EXISTS auth;
--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA extensions;


--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA graphql;


--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA graphql_public;


--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pgbouncer;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'anon no tiene privilegios: esta app es privada. Ver 20260915120000_grants.sql';


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA realtime;


--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA storage;


--
-- Name: supabase_migrations; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA supabase_migrations;


--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA vault;


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone',
    'recovery_code'
);


--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_authorization_status AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_client_type AS ENUM (
    'public',
    'confidential'
);


--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_response_type AS ENUM (
    'code'
);


--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


--
-- Name: action; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in',
    'like',
    'ilike',
    'is',
    'match',
    'imatch',
    'isdistinct'
);


--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text,
	negate boolean
);


--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: -
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
    revoke trigger on cron.job_run_details from postgres;
  END IF;
END;
$$;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $_$
begin
    if not exists (
        select 1
        from pg_catalog.pg_event_trigger_ddl_commands() ev
        join pg_catalog.pg_extension e on ev.objid = e.oid
        where e.extname = 'pg_graphql'
    ) then
        return;
    end if;

    drop function if exists graphql_public.graphql;
    create or replace function graphql_public.graphql(
        "operationName" text default null,
        query text default null,
        variables jsonb default null,
        extensions jsonb default null
    )
        returns jsonb
        language sql
    as $$
        select graphql.resolve(
            query := query,
            variables := coalesce(variables, '{}'),
            "operationName" := "operationName",
            extensions := extensions
        );
    $$;

    -- Attach the wrapper to the extension so DROP EXTENSION cascades to it,
    -- which in turn triggers set_graphql_placeholder to reinstall the "not enabled" stub.
    alter extension pg_graphql add function graphql_public.graphql(text, text, jsonb, jsonb);

    grant usage on schema graphql to postgres, anon, authenticated, service_role;
    grant execute on function graphql.resolve to postgres, anon, authenticated, service_role;
    grant usage on schema graphql to postgres with grant option;
    grant usage on schema graphql_public to postgres with grant option;
end;
$_$;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8.0', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
            set search_path to ''
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: graphql(text, text, jsonb, jsonb); Type: FUNCTION; Schema: graphql_public; Owner: -
--

CREATE FUNCTION graphql_public.graphql("operationName" text DEFAULT NULL::text, query text DEFAULT NULL::text, variables jsonb DEFAULT NULL::jsonb, extensions jsonb DEFAULT NULL::jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;


--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: -
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


--
-- Name: aceptar_invitacion(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.aceptar_invitacion(p_code text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare
  v_inv ledger_invite%rowtype;
begin
  select * into v_inv from ledger_invite
   where code = upper(trim(p_code)) for update;

  -- El mismo mensaje para "no existe", "ya se uso" y "vencio": distinguirlos
  -- convertiria esto en un oraculo para adivinar codigos.
  if not found or v_inv.used_at is not null or v_inv.expires_at < now() then
    raise exception 'Ese codigo no sirve: puede estar vencido o ya usado';
  end if;

  if exists (select 1 from ledger_member
              where ledger_id = v_inv.ledger_id and user_id = auth.uid()) then
    raise exception 'Ya formas parte de ese libro';
  end if;

  insert into ledger_member (ledger_id, user_id, role)
  values (v_inv.ledger_id, auth.uid(), v_inv.role);

  update ledger_invite set used_by = auth.uid(), used_at = now() where code = v_inv.code;

  -- Entrar a un libro es querer verlo: se pasa a ser el activo.
  insert into active_ledger (user_id, ledger_id) values (auth.uid(), v_inv.ledger_id)
  on conflict (user_id) do update set ledger_id = excluded.ledger_id, set_at = now();

  return v_inv.ledger_id;
end $$;


--
-- Name: ajustar_fin_de_mes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ajustar_fin_de_mes() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
begin
  if new.month_end then
    new.next_on := (date_trunc('month', new.next_on) + interval '1 month - 1 day')::date;
  end if;
  return new;
end $$;


--
-- Name: FUNCTION ajustar_fin_de_mes(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.ajustar_fin_de_mes() IS 'Lleva next_on al ultimo dia de su mes cuando la regla es de fin de mes. Corre en INSERT y en cada UPDATE de next_on, asi ninguna funcion que adelante la agenda necesita acordarse. OD-38.';


--
-- Name: aportar_a_libro(uuid, uuid, uuid, numeric, date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.aportar_a_libro(p_destino uuid, p_cuenta_origen uuid, p_cuenta_destino uuid, p_monto numeric, p_on date DEFAULT NULL::date, p_detalle text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare
  v_origen  uuid := my_ledger();
  v_ref     uuid := gen_random_uuid();
  v_fecha   date := coalesce(p_on, current_date);
  v_unidad  text;
  v_tx      uuid;
  v_cat     uuid;
  v_detalle text := nullif(trim(p_detalle), '');
  v_alla    text;
  v_aca     text;
begin
  if p_monto is null or p_monto <= 0 then
    raise exception 'El aporte tiene que ser mayor que cero';
  end if;
  if v_origen = p_destino then
    raise exception 'Ese es el mismo libro: usa una transferencia comun';
  end if;

  -- Tiene que ser miembro de LOS DOS. Es SECURITY DEFINER, asi que RLS no lo
  -- comprueba por nosotros: se comprueba aca, explicito.
  if not exists (select 1 from ledger_member where ledger_id = v_origen   and user_id = auth.uid())
  or not exists (select 1 from ledger_member where ledger_id = p_destino and user_id = auth.uid()) then
    raise exception 'Solo podes mover plata entre libros que sean tuyos';
  end if;

  select name into v_alla from ledger where id = p_destino;
  select name into v_aca  from ledger where id = v_origen;

  select unit into v_unidad from account
   where id = p_cuenta_origen and ledger_id = v_origen;
  if v_unidad is null then raise exception 'Esa cuenta de origen no es de tu libro'; end if;

  if not exists (select 1 from account
                  where id = p_cuenta_destino and ledger_id = p_destino and unit = v_unidad) then
    raise exception 'La cuenta de destino no existe en ese libro, o esta en otra moneda';
  end if;

  -- En TU libro: sale plata y es un GASTO. Esa plata ya no la podes usar sola.
  v_cat := categoria_de_rol(v_origen, 'aporte_enviado');
  insert into transaction (ledger_id, occurred_on, description, kind, created_by, cross_ref)
       values (v_origen, v_fecha, coalesce(v_detalle, 'Aporte a ' || v_alla),
               'expense', auth.uid(), v_ref)
    returning id into v_tx;
  insert into entry (transaction_id, ledger_id, account_id, category_id, amount, unit) values
    (v_tx, v_origen, p_cuenta_origen, null, -p_monto, v_unidad),
    (v_tx, v_origen, null, v_cat,        p_monto, v_unidad);

  -- En el OTRO libro: entra plata y es un ingreso.
  v_cat := categoria_de_rol(p_destino, 'aporte_recibido');
  insert into transaction (ledger_id, occurred_on, description, kind, created_by, cross_ref)
       values (p_destino, v_fecha, coalesce(v_detalle, 'Aporte de ' || v_aca),
               'income', auth.uid(), v_ref)
    returning id into v_tx;
  insert into entry (transaction_id, ledger_id, account_id, category_id, amount, unit) values
    (v_tx, p_destino, p_cuenta_destino, null,  p_monto, v_unidad),
    (v_tx, p_destino, null,             v_cat, -p_monto, v_unidad);

  return v_ref;
end $$;


--
-- Name: FUNCTION aportar_a_libro(p_destino uuid, p_cuenta_origen uuid, p_cuenta_destino uuid, p_monto numeric, p_on date, p_detalle text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.aportar_a_libro(p_destino uuid, p_cuenta_origen uuid, p_cuenta_destino uuid, p_monto numeric, p_on date, p_detalle text) IS 'Dos movimientos encadenados, uno por libro. No es una transferencia: aportar al libro comun es GASTAR, porque esa plata ya no la podes usar sola. ADR-032.';


--
-- Name: archivar_libro(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.archivar_libro(p_ledger uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
begin
  if not exists (select 1 from ledger_member
                  where ledger_id = p_ledger and user_id = auth.uid() and role = 'owner') then
    raise exception 'Solo quien creo el libro puede archivarlo';
  end if;

  -- Quedarse sin ningun libro deja la aplicacion sin nada que mostrar y sin
  -- forma de volver: no hay pantalla para crear el primero desde afuera.
  if (select count(*) from my_ledgers()) <= 1 then
    raise exception 'Es tu unico libro: no se puede archivar';
  end if;

  update ledger set archived_at = now() where id = p_ledger;

  -- Si era el que estabas mirando, hay que sacarte de ahi.
  delete from active_ledger where user_id = auth.uid() and ledger_id = p_ledger;
end $$;


--
-- Name: avanzar_fecha(date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.avanzar_fecha(p_desde date, p_frecuencia text) RETURNS date
    LANGUAGE sql IMMUTABLE
    SET search_path TO 'public', 'pg_temp'
    AS $$
  select p_desde + case p_frecuencia
    when 'weekly'    then interval '1 week'
    when 'monthly'   then interval '1 month'
    when 'bimonthly' then interval '2 months'
    when 'quarterly' then interval '3 months'
    when 'biannual'  then interval '6 months'
    when 'yearly'    then interval '1 year'
  end
$$;


--
-- Name: FUNCTION avanzar_fecha(p_desde date, p_frecuencia text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.avanzar_fecha(p_desde date, p_frecuencia text) IS 'Postgres ya resuelve bien el caso incomodo: 31 de enero + 1 mes da 28 de febrero, y no se rompe en anios bisiestos.';


--
-- Name: cambiar_libro(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cambiar_libro(p_ledger uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
begin
  if not exists (select 1 from ledger_member
                  where ledger_id = p_ledger and user_id = auth.uid()) then
    raise exception 'Ese libro no es tuyo';
  end if;

  insert into active_ledger (user_id, ledger_id) values (auth.uid(), p_ledger)
  on conflict (user_id) do update set ledger_id = excluded.ledger_id, set_at = now();
end $$;


--
-- Name: cartera_del_broker(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cartera_del_broker() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare
  v_cartera uuid;
  v_donde   text := nullif(trim(coalesce(new.institution, '')), '');
begin
  if v_donde is null then return new; end if;
  if not (new.valuation = 'market' or (new.valuation = 'balance' and not new.is_spendable)) then
    return new;
  end if;

  select id into v_cartera
    from portfolio
   where ledger_id = new.ledger_id and lower(name) = lower(v_donde) and archived_at is null;

  if v_cartera is null then
    insert into portfolio (ledger_id, name) values (new.ledger_id, v_donde)
    returning id into v_cartera;
  end if;

  insert into portfolio_account (portfolio_id, account_id, ledger_id)
  values (v_cartera, new.id, new.ledger_id)
  on conflict do nothing;

  return new;
end $$;


--
-- Name: FUNCTION cartera_del_broker(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.cartera_del_broker() IS 'Una cuenta de broker entra sola a la cartera de su institucion. Sin esto habia que tildar cuenta por cuenta, y hasta hacerlo el rendimiento se media mal en silencio. OD-40.';


--
-- Name: categoria_de_rol(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.categoria_de_rol(p_ledger uuid, p_rol text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare
  v_cat uuid;
begin
  select id into v_cat from category where ledger_id = p_ledger and system_role = p_rol;
  if v_cat is not null then return v_cat; end if;

  -- Se crean reci­en cuando se usan: quien nunca comparta un libro no tiene por
  -- que ver estas categorias en su lista.
  insert into category (ledger_id, name, kind, is_system, sort_order, system_role)
  values (p_ledger,
          case p_rol when 'aporte_enviado' then 'Aporte a otro libro'
                     else 'Aporte recibido' end,
          case p_rol when 'aporte_enviado' then 'expense' else 'income' end,
          true, 95, p_rol)
  returning id into v_cat;

  return v_cat;
end $$;


--
-- Name: check_category_depth(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_category_depth() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
begin
  if new.parent_id is not null and exists (
    select 1 from category where id = new.parent_id and parent_id is not null
  ) then
    raise exception 'Solo se admiten dos niveles de categoria'
      using errcode = 'check_violation';
  end if;
  if new.parent_id = new.id then
    raise exception 'Una categoria no puede ser su propio padre'
      using errcode = 'check_violation';
  end if;
  return new;
end $$;


--
-- Name: check_entry_unit(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_entry_unit() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare v_unit text;
begin
  if new.account_id is not null then
    select unit into v_unit from account where id = new.account_id;
    if v_unit is distinct from new.unit then
      raise exception 'La linea usa la unidad % pero la cuenta tiene %', new.unit, v_unit
        using errcode = 'check_violation';
    end if;
  end if;
  return new;
end $$;


--
-- Name: check_transaction_balances(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_transaction_balances() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare
  v_tx    uuid := coalesce(new.transaction_id, old.transaction_id);
  v_units int;
  v_bad   text;
begin
  select count(*) into v_units
    from (select unit from entry where transaction_id = v_tx group by unit) t;

  -- la transaccion fue borrada entera: nada que validar
  if v_units = 0 then
    return null;
  end if;

  if v_units = 1 then
    select unit into v_bad
      from entry where transaction_id = v_tx
     group by unit having sum(amount) <> 0;
    if v_bad is not null then
      raise exception 'La transaccion % no balancea en %', v_tx, v_bad
        using errcode = 'check_violation';
    end if;

  elsif v_units = 2 then
    -- intercambio (compra de dolares, compra/venta de un activo).
    -- el tipo de cambio o el precio unitario es el COCIENTE y NO SE GUARDA.
    -- lo unico verificable sin una cotizacion externa es que ninguna pata sea neutra.
    if exists (
      select 1 from entry where transaction_id = v_tx
       group by unit having sum(amount) = 0
    ) then
      raise exception
        'En un intercambio ninguna unidad puede tener saldo neto cero (transaccion %)', v_tx
        using errcode = 'check_violation';
    end if;

  else
    -- ADR-010 dice explicitamente RECHAZAR, no suponer que no pasa.
    raise exception
      'Una transaccion no puede mezclar mas de dos unidades (transaccion %, % unidades)',
      v_tx, v_units
      using errcode = 'check_violation';
  end if;

  return null;
end $$;


--
-- Name: comprar_activo(text, text, text, text, integer, uuid, numeric, numeric, text, date, numeric, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.comprar_activo(p_symbol text, p_nombre text, p_kind text, p_moneda text, p_decimals integer, p_desde uuid, p_monto numeric, p_unidades numeric, p_broker text DEFAULT NULL::text, p_on date DEFAULT NULL::date, p_ratio numeric DEFAULT NULL::numeric, p_subyacente text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare
  v_ledger uuid := my_ledger();
  v_origen account%rowtype;
  v_inst   uuid;
  v_pos    uuid;
  v_tx     uuid;
  v_fecha  date := coalesce(p_on, current_date);
  v_fuente text;
begin
  if p_monto is null or p_monto <= 0 then raise exception 'El monto tiene que ser mayor que cero'; end if;
  if p_unidades is null or p_unidades <= 0 then raise exception 'Las unidades tienen que ser mayores que cero'; end if;

  select * into v_origen from account where id = p_desde;
  if not found then raise exception 'No existe la cuenta de origen'; end if;

  select id into v_inst from instrument
   where ledger_id = v_ledger and symbol = upper(trim(p_symbol));
  if v_inst is null then
    insert into instrument (ledger_id, symbol, name, kind, quote_currency, decimals,
                            ratio, underlying_symbol)
         values (v_ledger, upper(trim(p_symbol)), p_nombre, p_kind, p_moneda, p_decimals,
                 p_ratio, nullif(upper(trim(coalesce(p_subyacente,''))), ''))
      returning id into v_inst;
  end if;

  -- Un CEDEAR lleva el CCL adentro de su precio: medirlo con ese mismo dolar es
  -- lo que aisla el rendimiento de la accion del movimiento del tipo de cambio.
  v_fuente := case when p_kind = 'cedear' then 'ccl' else null end;

  select id into v_pos from account
   where ledger_id = v_ledger and instrument_id = v_inst and archived_at is null;
  if v_pos is null then
    insert into account (ledger_id, name, kind, valuation, unit, instrument_id,
                         is_spendable, institution, fx_source)
         values (v_ledger,
                 coalesce(p_broker || ' · ', '') || upper(trim(p_symbol)),
                 'asset', 'market', upper(trim(p_symbol)), v_inst,
                 false, coalesce(p_broker, v_origen.institution), v_fuente)
      returning id into v_pos;
  end if;

  insert into transaction (ledger_id, occurred_on, description, kind, created_by)
       values (v_ledger, v_fecha, 'Compra de ' || upper(trim(p_symbol)), 'trade', auth.uid())
    returning id into v_tx;

  insert into entry (transaction_id, ledger_id, account_id, amount, unit) values
    (v_tx, v_ledger, p_desde, -p_monto,    v_origen.unit),
    (v_tx, v_ledger, v_pos,    p_unidades, upper(trim(p_symbol)));

  return v_pos;
end $$;


--
-- Name: convertir(numeric, text, date, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.convertir(p_monto numeric, p_unidad text, p_fecha date, p_medida text DEFAULT 'USD'::text, p_fuente text DEFAULT NULL::text) RETURNS numeric
    LANGUAGE plpgsql STABLE
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare
  v_fuente text;
  v_usd    numeric;
  v_ars    numeric;
  v_uva    numeric;
begin
  if p_monto is null then return null; end if;

  -- Una unidad que no es moneda -BTC, un CEDEAR- no se convierte aca: primero
  -- hay que valuarla con su precio.
  if p_unidad not in ('ARS','USD','USDT','USDC','DAI') then
    return null;
  end if;

  v_fuente := coalesce(p_fuente, my_fx_source());

  if p_medida = 'USD' then
    -- USDT, USDC y DAI se toman como dolar. Es una aproximacion deliberada: se
    -- despegan unas centesimas y esa diferencia es ruido frente a lo que se mide.
    if p_unidad <> 'ARS' then return p_monto; end if;
    v_usd := cotizacion(p_fecha, v_fuente);
    if v_usd is null or v_usd = 0 then return null; end if;
    return p_monto / v_usd;

  elsif p_medida = 'UVA' then
    v_uva := cotizacion(p_fecha, 'uva', 'UVA', 'ARS');
    if v_uva is null or v_uva = 0 then return null; end if;

    if p_unidad = 'ARS' then
      v_ars := p_monto;
    else
      -- primero a pesos de ese dia, despues a UVAs
      v_usd := cotizacion(p_fecha, v_fuente);
      if v_usd is null then return null; end if;
      v_ars := p_monto * v_usd;
    end if;
    return v_ars / v_uva;
  end if;

  raise exception 'Medida desconocida: %. Se admiten USD y UVA', p_medida;
end $$;


--
-- Name: cotizacion(date, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cotizacion(p_fecha date, p_fuente text, p_base text DEFAULT 'USD'::text, p_quote text DEFAULT 'ARS'::text) RETURNS numeric
    LANGUAGE sql STABLE
    SET search_path TO 'public', 'pg_temp'
    AS $$
  select rate from fx_rate
   where ledger_id = my_ledger()
     and base = p_base and quote = p_quote and source = p_fuente
     and on_date <= p_fecha
   order by on_date desc
   limit 1
$$;


--
-- Name: cotizacion_al(date, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cotizacion_al(p_fecha date, p_fuente text, p_base text DEFAULT 'USD'::text, p_quote text DEFAULT 'ARS'::text) RETURNS date
    LANGUAGE sql STABLE
    SET search_path TO 'public', 'pg_temp'
    AS $$
  select on_date from fx_rate
   where ledger_id = my_ledger()
     and base = p_base and quote = p_quote and source = p_fuente
     and on_date <= p_fecha
   order by on_date desc
   limit 1
$$;


--
-- Name: crear_invitacion(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.crear_invitacion(p_role text DEFAULT 'member'::text) RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare
  v_libro  uuid := my_ledger();
  v_codigo text;
begin
  if mi_rol() is distinct from 'owner' then
    raise exception 'Solo quien creo el libro puede invitar';
  end if;
  if p_role not in ('owner','member') then
    raise exception 'Rol invalido';
  end if;

  -- Ocho caracteres: suficiente con vencimiento y un solo uso, y corto como para
  -- dictarlo por telefono sin equivocarse.
  v_codigo := upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8));

  insert into ledger_invite (code, ledger_id, role, created_by)
  values (v_codigo, v_libro, p_role, auth.uid());

  return v_codigo;
end $$;


--
-- Name: crear_libro(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.crear_libro(p_nombre text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare
  v_libro  uuid;
  v_nombre text := nullif(trim(p_nombre), '');
begin
  if v_nombre is null then raise exception 'El libro necesita un nombre'; end if;
  if auth.uid() is null then raise exception 'Hace falta estar identificado'; end if;

  insert into ledger (name) values (v_nombre) returning id into v_libro;
  insert into ledger_member (ledger_id, user_id, role) values (v_libro, auth.uid(), 'owner');
  perform sembrar_libro(v_libro);

  -- Crear un libro es querer usarlo. Si no, quedaria creado e invisible.
  insert into active_ledger (user_id, ledger_id) values (auth.uid(), v_libro)
  on conflict (user_id) do update set ledger_id = excluded.ledger_id, set_at = now();

  return v_libro;
end $$;


--
-- Name: create_plazo_fijo(text, uuid, numeric, date, numeric, text, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_plazo_fijo(p_nombre text, p_desde uuid, p_capital numeric, p_vence date, p_esperado numeric, p_institucion text DEFAULT NULL::text, p_on date DEFAULT NULL::date) RETURNS uuid
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare
  v_ledger  uuid := my_ledger();
  v_origen  account%rowtype;
  v_cuenta  uuid;
  v_tx      uuid;
  v_fecha   date := coalesce(p_on, current_date);
begin
  select * into v_origen from account where id = p_desde;
  if not found then raise exception 'No existe la cuenta de origen'; end if;
  if p_capital is null or p_capital <= 0 then
    raise exception 'El capital tiene que ser mayor que cero';
  end if;
  if p_esperado is null or p_esperado < p_capital then
    raise exception 'Lo que vuelve al vencimiento no puede ser menor que el capital';
  end if;
  if p_vence <= v_fecha then
    raise exception 'El vencimiento tiene que ser posterior a la constitucion';
  end if;

  insert into account (ledger_id, name, kind, valuation, unit, is_spendable,
                       matures_on, expected_amount, institution)
       values (v_ledger, p_nombre, 'asset', 'accrual', v_origen.unit, false,
               p_vence, p_esperado, coalesce(p_institucion, v_origen.institution))
    returning id into v_cuenta;

  -- Constituirlo no es un gasto: la plata cambia de lugar, el patrimonio no se
  -- mueve. Por eso ninguna categoria participa.
  insert into transaction (ledger_id, occurred_on, description, kind, created_by)
       values (v_ledger, v_fecha, 'Constitución de ' || p_nombre, 'transfer', auth.uid())
    returning id into v_tx;

  insert into entry (transaction_id, ledger_id, account_id, amount, unit) values
    (v_tx, v_ledger, p_desde,  -p_capital, v_origen.unit),
    (v_tx, v_ledger, v_cuenta,  p_capital, v_origen.unit);

  insert into scheduled_event (ledger_id, kind, description, account_id,
                               counter_account_id, amount, currency, next_on)
       values (v_ledger, 'maturity', 'Vence ' || p_nombre, v_cuenta,
               p_desde, p_esperado, v_origen.unit, p_vence);

  return v_cuenta;
end $$;


--
-- Name: create_transaction(date, text, jsonb, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_transaction(p_occurred_on date, p_kind text, p_entries jsonb, p_description text DEFAULT NULL::text, p_installments integer DEFAULT NULL::integer) RETURNS uuid
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare
  v_ledger uuid := my_ledger();
  v_tx     uuid;
  v_n      int;
begin
  if v_ledger is null then
    raise exception 'El usuario no pertenece a ningun libro';
  end if;

  v_n := jsonb_array_length(p_entries);
  if v_n is null or v_n < 2 then
    raise exception 'Un movimiento necesita al menos dos lineas (recibio %)', coalesce(v_n, 0);
  end if;

  insert into transaction (ledger_id, occurred_on, description, kind, created_by, installments)
       values (v_ledger, p_occurred_on, nullif(trim(p_description), ''), p_kind, auth.uid(),
               p_installments)
    returning id into v_tx;

  insert into entry (transaction_id, ledger_id, account_id, category_id, amount, unit)
  select v_tx,
         v_ledger,
         nullif(e->>'account_id', '')::uuid,
         nullif(e->>'category_id', '')::uuid,
         (e->>'amount')::numeric,
         e->>'unit'
    from jsonb_array_elements(p_entries) e;

  -- Al salir de la funcion se confirma la transaccion de base y recien ahi dispara
  -- el trigger diferido de ADR-010. Si no balancea, no queda NADA: ni el movimiento
  -- ni las lineas. Esa es la atomicidad que se buscaba.
  return v_tx;
end $$;


--
-- Name: cuentas_de_libro(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cuentas_de_libro(p_ledger uuid) RETURNS TABLE(id uuid, name text, unit text)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
  select a.id, a.name, a.unit
    from account a
   where a.ledger_id = p_ledger
     and a.archived_at is null
     and a.valuation = 'balance'
     and exists (select 1 from ledger_member m
                  where m.ledger_id = p_ledger and m.user_id = auth.uid())
   order by a.name
$$;


--
-- Name: eliminar_libro(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.eliminar_libro(p_ledger uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare v_movs int;
begin
  if not exists (select 1 from ledger_member
                  where ledger_id = p_ledger and user_id = auth.uid() and role = 'owner') then
    raise exception 'Solo quien creo el libro puede borrarlo';
  end if;
  if (select count(*) from my_ledgers()) <= 1 then
    raise exception 'Es tu unico libro: no se puede borrar';
  end if;

  select count(*) into v_movs from transaction where ledger_id = p_ledger;
  if v_movs > 0 then
    raise exception 'Ese libro tiene % movimientos: archivalo, no lo borres', v_movs;
  end if;

  delete from ledger where id = p_ledger;   -- todo lo demas cae por cascada
end $$;


--
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_new_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare
  v_ledger uuid;
begin
  insert into ledger (name) values ('Personal') returning id into v_ledger;
  insert into ledger_member (ledger_id, user_id, role) values (v_ledger, new.id, 'owner');
  perform sembrar_libro(v_ledger);
  return new;
end $$;


--
-- Name: lamina_de(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.lamina_de(p_kind text) RETURNS numeric
    LANGUAGE sql IMMUTABLE
    SET search_path TO 'public', 'pg_temp'
    AS $$ select case when p_kind = 'bond' then 100 else 1 end $$;


--
-- Name: lamina_por_defecto(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.lamina_por_defecto() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
begin
  if new.quote_size = 1 and lamina_de(new.kind) <> 1 then
    new.quote_size := lamina_de(new.kind);
  end if;
  return new;
end $$;


--
-- Name: FUNCTION lamina_por_defecto(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.lamina_por_defecto() IS 'Un bono con lamina 1 siempre esta mal: cotiza por 100 nominales. Corrige solo ese caso, asi un valor explicito sigue ganando. OD-39.';


--
-- Name: mi_rol(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.mi_rol() RETURNS text
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
  select m.role from ledger_member m
   where m.user_id = auth.uid() and m.ledger_id = my_ledger()
$$;


--
-- Name: my_fx_source(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.my_fx_source() RETURNS text
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
  select l.default_fx_source
    from ledger l
    join ledger_member m on m.ledger_id = l.id
   where m.user_id = auth.uid()
   limit 1
$$;


--
-- Name: my_ledger(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.my_ledger() RETURNS uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
  select coalesce(
    (select a.ledger_id
       from active_ledger a
       join ledger_member m on m.ledger_id = a.ledger_id and m.user_id = a.user_id
       join ledger l on l.id = a.ledger_id and l.archived_at is null
      where a.user_id = auth.uid()),
    (select m.ledger_id from ledger_member m
       join ledger l on l.id = m.ledger_id and l.archived_at is null
      where m.user_id = auth.uid()
      order by m.joined_at, m.ledger_id
      limit 1)
  )
$$;


--
-- Name: my_ledgers(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.my_ledgers() RETURNS SETOF uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
  select m.ledger_id from ledger_member m
    join ledger l on l.id = m.ledger_id
   where m.user_id = auth.uid() and l.archived_at is null
$$;


--
-- Name: register_maturity(uuid, numeric, uuid, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.register_maturity(p_event uuid, p_total numeric DEFAULT NULL::numeric, p_to uuid DEFAULT NULL::uuid, p_on date DEFAULT NULL::date) RETURNS uuid
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare
  ev        scheduled_event%rowtype;
  v_capital numeric;
  v_total   numeric;
  v_interes numeric;
  v_destino uuid;
  v_fecha   date;
  v_cat     uuid;
  v_tx      uuid;
begin
  select * into ev from scheduled_event where id = p_event and kind = 'maturity';
  if not found then raise exception 'No existe ese vencimiento'; end if;
  if ev.archived_at is not null then raise exception 'Ese vencimiento ya se registro'; end if;

  v_destino := coalesce(p_to, ev.counter_account_id);
  if v_destino is null then raise exception 'Hace falta indicar a que cuenta vuelve'; end if;

  v_fecha := coalesce(p_on, ev.next_on);
  v_total := coalesce(p_total, ev.amount);
  if v_total is null or v_total <= 0 then
    raise exception 'Hace falta indicar cuanto volvio';
  end if;

  select coalesce(sum(amount), 0) into v_capital from entry where account_id = ev.account_id;
  if v_capital <= 0 then raise exception 'El plazo fijo no tiene capital'; end if;

  v_interes := v_total - v_capital;

  -- La categoria de intereses se busca por lo que ES, no por su nombre: quien la
  -- renombre no deberia romper esto.
  select id into v_cat from category
   where ledger_id = ev.ledger_id and is_system and kind = 'income'
   limit 1;
  if v_cat is null then raise exception 'Falta la categoria de sistema de ingresos'; end if;

  insert into transaction (ledger_id, occurred_on, description, kind, created_by,
                           scheduled_event_id)
       values (ev.ledger_id, v_fecha, ev.description, 'income', auth.uid(), ev.id)
    returning id into v_tx;

  insert into entry (transaction_id, ledger_id, account_id, amount, unit) values
    (v_tx, ev.ledger_id, ev.account_id, -v_capital, ev.currency),
    (v_tx, ev.ledger_id, v_destino,      v_total,   ev.currency);

  -- Solo si hubo interes. Una linea en cero seria ruido en el historial.
  if v_interes <> 0 then
    insert into entry (transaction_id, ledger_id, category_id, amount, unit)
    values (v_tx, ev.ledger_id, v_cat, -v_interes, ev.currency);
  end if;

  -- El plazo fijo cumplio su ciclo: se archiva, no se borra. Sus movimientos
  -- siguen explicando de donde salio y a donde fue.
  update account set archived_at = now() where id = ev.account_id;
  update scheduled_event set archived_at = now() where id = ev.id;

  return v_tx;
end $$;


--
-- Name: register_scheduled(uuid, numeric, date, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.register_scheduled(p_event uuid, p_amount numeric, p_on date DEFAULT NULL::date, p_account uuid DEFAULT NULL::uuid) RETURNS uuid
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare
  ev       scheduled_event%rowtype;
  v_cuenta uuid;
  v_fecha  date;
  v_tx     uuid;
  v_monto  numeric;
begin
  select * into ev from scheduled_event where id = p_event;
  if not found then
    raise exception 'No existe ese evento programado';
  end if;
  if ev.archived_at is not null then
    raise exception 'Ese evento esta archivado';
  end if;

  v_cuenta := coalesce(p_account, ev.account_id);
  v_fecha  := coalesce(p_on, ev.next_on);
  v_monto  := abs(coalesce(p_amount, ev.amount));

  if v_cuenta is null then
    raise exception 'Hace falta indicar con que cuenta se paga';
  end if;
  if v_monto is null or v_monto = 0 then
    raise exception 'Hace falta indicar el importe';
  end if;

  if ev.kind = 'recurring' then
    if ev.category_id is null then
      raise exception 'La regla no tiene categoria';
    end if;
    -- Un gasto normal: sale de la cuenta hacia la categoria. El convenio de
    -- signos es el mismo de siempre (modelo-de-datos §1).
    insert into transaction (ledger_id, occurred_on, description, kind, created_by,
                             scheduled_event_id)
         values (ev.ledger_id, v_fecha, ev.description, 'expense', auth.uid(), ev.id)
      returning id into v_tx;

    insert into entry (transaction_id, ledger_id, account_id, category_id, amount, unit)
    values (v_tx, ev.ledger_id, v_cuenta, null, -v_monto, ev.currency),
           (v_tx, ev.ledger_id, null, ev.category_id, v_monto, ev.currency);

    -- Se adelanta hasta pasar la fecha registrada: si estuvo vencido varios
    -- periodos, un solo registro no deberia dejarlo vencido otra vez.
    update scheduled_event
       set next_on = avanzar_fecha(next_on, frequency)
     where id = ev.id;

  else
    -- 'maturity': el vencimiento de un plazo fijo. Se resuelve en la etapa de
    -- inversiones; por ahora se rechaza en vez de inventar un asiento.
    raise exception 'Los vencimientos se registran desde la seccion de inversiones';
  end if;

  return v_tx;
end $$;


--
-- Name: rls_auto_enable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.rls_auto_enable() RETURNS event_trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog'
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN
    SELECT *
    FROM pg_event_trigger_ddl_commands()
    WHERE command_tag IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO')
      AND object_type IN ('table','partitioned table')
  LOOP
     IF cmd.schema_name IS NOT NULL AND cmd.schema_name IN ('public') AND cmd.schema_name NOT IN ('pg_catalog','information_schema') AND cmd.schema_name NOT LIKE 'pg_toast%' AND cmd.schema_name NOT LIKE 'pg_temp%' THEN
      BEGIN
        EXECUTE format('alter table if exists %s enable row level security', cmd.object_identity);
        RAISE LOG 'rls_auto_enable: enabled RLS on %', cmd.object_identity;
      EXCEPTION
        WHEN OTHERS THEN
          RAISE LOG 'rls_auto_enable: failed to enable RLS on %', cmd.object_identity;
      END;
     ELSE
        RAISE LOG 'rls_auto_enable: skip % (either system schema or not in enforced list: %.)', cmd.object_identity, cmd.schema_name;
     END IF;
  END LOOP;
END;
$$;


--
-- Name: sembrar_libro(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sembrar_libro(p_ledger uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
begin
  insert into category (ledger_id, name, kind, is_system, sort_order, system_role) values
    (p_ledger, 'Sueldo',           'income',  false, 10, null),
    (p_ledger, 'Intereses',        'income',  true,  20, 'interes'),   -- ADR-013, ADR-014
    (p_ledger, 'Otros ingresos',   'income',  false, 30, null),
    (p_ledger, 'Gastos fijos',     'expense', false, 10, null),
    (p_ledger, 'Gastos variables', 'expense', false, 20, null),
    (p_ledger, 'Ajuste de saldo',  'expense', true,  90, 'ajuste');    -- ADR-005
end $$;


--
-- Name: FUNCTION sembrar_libro(p_ledger uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.sembrar_libro(p_ledger uuid) IS 'Lo minimo con lo que nace un libro. La usan el trigger de alta Y el reseteo, para que no puedan discrepar.';


--
-- Name: skip_scheduled(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.skip_scheduled(p_event uuid) RETURNS date
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare v_next date;
begin
  update scheduled_event
     set next_on = avanzar_fecha(next_on, frequency)
   where id = p_event and archived_at is null and kind = 'recurring'
returning next_on into v_next;

  if v_next is null then
    raise exception 'No se pudo saltear: el evento no existe, esta archivado o no es recurrente';
  end if;
  return v_next;
end $$;


--
-- Name: touch_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
begin new.updated_at := now(); return new; end $$;


--
-- Name: vender_activo(uuid, numeric, uuid, numeric, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.vender_activo(p_pos uuid, p_unidades numeric, p_hacia uuid, p_monto numeric, p_on date DEFAULT NULL::date) RETURNS uuid
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare
  v_pos     account%rowtype;
  v_destino account%rowtype;
  v_tengo   numeric;
  v_tx      uuid;
begin
  select * into v_pos from account where id = p_pos and valuation = 'market';
  if not found then raise exception 'No existe esa posicion'; end if;
  select * into v_destino from account where id = p_hacia;
  if not found then raise exception 'No existe la cuenta de destino'; end if;
  if p_unidades is null or p_unidades <= 0 then raise exception 'Las unidades tienen que ser mayores que cero'; end if;
  if p_monto is null or p_monto <= 0 then raise exception 'El monto tiene que ser mayor que cero'; end if;

  select coalesce(sum(amount), 0) into v_tengo from entry where account_id = p_pos;
  if p_unidades > v_tengo then
    raise exception 'No tenes tantas unidades: hay % y queres vender %', v_tengo, p_unidades;
  end if;

  insert into transaction (ledger_id, occurred_on, description, kind, created_by)
       values (v_pos.ledger_id, coalesce(p_on, current_date),
               'Venta de ' || v_pos.unit, 'trade', auth.uid())
    returning id into v_tx;

  insert into entry (transaction_id, ledger_id, account_id, amount, unit) values
    (v_tx, v_pos.ledger_id, p_pos,   -p_unidades, v_pos.unit),
    (v_tx, v_pos.ledger_id, p_hacia,  p_monto,    v_destino.unit);

  -- Si se vendio todo, la posicion cumplio su ciclo. Se archiva, no se borra:
  -- sus movimientos siguen explicando que paso.
  if v_tengo - p_unidades = 0 then
    update account set archived_at = now() where id = p_pos;
  end if;

  return v_tx;
end $$;


--
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
    -- Regclass of the table e.g. public.notes
    entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

    -- I, U, D, T: insert, update ...
    action realtime.action = (
        case wal ->> 'action'
            when 'I' then 'INSERT'
            when 'U' then 'UPDATE'
            when 'D' then 'DELETE'
            else 'ERROR'
        end
    );

    -- Is row level security enabled for the table
    is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

    subscriptions realtime.subscription[] = array_agg(subs)
        from
            realtime.subscription subs
        where
            subs.entity = entity_
            -- Filter by action early - only get subscriptions interested in this action
            -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
            and (subs.action_filter = '*' or subs.action_filter = action::text);

    -- Subscription vars
    working_role regrole;
    working_selected_columns text[];
    claimed_role regrole;
    claims jsonb;

    subscription_id uuid;
    subscription_has_access bool;
    visible_to_subscription_ids uuid[] = '{}';

    -- structured info for wal's columns
    columns realtime.wal_column[];
    -- previous identity values for update/delete
    old_columns realtime.wal_column[];

    error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

    -- Primary jsonb output for record
    output jsonb;

    -- Loop record for iterating unique roles (outer loop)
    role_record record;
    -- Loop record for iterating unique selected_columns within a role (inner loop)
    cols_record record;
    -- Subscription ids visible at the role level (before fanning out by selected_columns)
    visible_role_sub_ids uuid[] = '{}';

begin
    perform set_config('role', null, true);

    columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'columns') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    old_columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'identity') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    for role_record in
        select claims_role
        from (select distinct claims_role from unnest(subscriptions)) t
        order by claims_role::text
    loop
        working_role := role_record.claims_role;

        -- Update `is_selectable` for columns and old_columns (once per role)
        columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(columns) c;

        old_columns =
                array_agg(
                    (
                        c.name,
                        c.type_name,
                        c.type_oid,
                        c.value,
                        c.is_pkey,
                        pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                    )::realtime.wal_column
                )
                from
                    unnest(old_columns) c;

        if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
            -- Fan out 400 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 400: Bad Request, no primary key']
                )::realtime.wal_rls;
            end loop;

        -- The claims role does not have SELECT permission to the primary key of entity
        elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
            -- Fan out 401 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 401: Unauthorized']
                )::realtime.wal_rls;
            end loop;

        else
            -- Create the prepared statement (once per role)
            if is_rls_enabled and action <> 'DELETE' then
                if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                    deallocate walrus_rls_stmt;
                end if;
                execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
            end if;

            -- Collect all visible subscription IDs for this role (filter check + RLS check)
            visible_role_sub_ids = '{}';

            for subscription_id, claims in (
                    select
                        subs.subscription_id,
                        subs.claims
                    from
                        unnest(subscriptions) subs
                    where
                        subs.entity = entity_
                        and subs.claims_role = working_role
                        and (
                            realtime.is_visible_through_filters(columns, subs.filters)
                            or (
                              action = 'DELETE'
                              and realtime.is_visible_through_filters(old_columns, subs.filters)
                            )
                        )
            ) loop

                if not is_rls_enabled or action = 'DELETE' then
                    visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                else
                    -- Check if RLS allows the role to see the record
                    perform
                        -- Trim leading and trailing quotes from working_role because set_config
                        -- doesn't recognize the role as valid if they are included
                        set_config('role', trim(both '"' from working_role::text), true),
                        set_config('request.jwt.claims', claims::text, true);

                    execute 'execute walrus_rls_stmt' into subscription_has_access;

                    -- Reset the role on every FOR..LOOP batch execution.
                    -- The first batch of 10 rows is pre-fetched using the current connection role (PG internal behaviour)
                    -- then we have to reset it again otherwise it would use the role defined in the `set_config` above
                    -- to fetch the remaining rows when rows>10, which could be a user-defined role that lacks execution grants.
                    -- The flow is:
                    --   1. run batch with conn role
                    --   2. set_config working_role
                    --   3. execute walrus
                    --   4. reset role (revert)
                    --   5. repeat
                    perform set_config('role', null, true);

                    if subscription_has_access then
                        visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                    end if;
                end if;
            end loop;

            perform set_config('role', null, true);

            -- Inner loop: per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;

                output = jsonb_build_object(
                    'schema', wal ->> 'schema',
                    'table', wal ->> 'table',
                    'type', action,
                    'commit_timestamp', to_char(
                        ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                        'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
                    ),
                    'columns', (
                        select
                            jsonb_agg(
                                jsonb_build_object(
                                    'name', pa.attname,
                                    'type', pt.typname
                                )
                                order by pa.attnum asc
                            )
                        from
                            pg_attribute pa
                            join pg_type pt
                                on pa.atttypid = pt.oid
                            left join (
                                select unnest(conkey) as pkey_attnum
                                from pg_constraint
                                where conrelid = entity_ and contype = 'p'
                            ) pk on pk.pkey_attnum = pa.attnum
                        where
                            attrelid = entity_
                            and attnum > 0
                            and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
                            and (working_selected_columns is null or pa.attname = any(working_selected_columns) or pk.pkey_attnum is not null)
                    )
                )
                -- Add "record" key for insert and update
                || case
                    when action in ('INSERT', 'UPDATE') then
                        jsonb_build_object(
                            'record',
                            (
                                select
                                    jsonb_object_agg(
                                        -- if unchanged toast, get column name and value from old record
                                        coalesce((c).name, (oc).name),
                                        case
                                            when (c).name is null then (oc).value
                                            else (c).value
                                        end
                                    )
                                from
                                    unnest(columns) c
                                    full outer join unnest(old_columns) oc
                                        on (c).name = (oc).name
                                where
                                    coalesce((c).is_selectable, (oc).is_selectable)
                                    and (working_selected_columns is null or coalesce((c).name, (oc).name) = any(working_selected_columns) or coalesce((c).is_pkey, (oc).is_pkey))
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            )
                        )
                    else '{}'::jsonb
                end
                -- Add "old_record" key for update and delete
                || case
                    when action = 'UPDATE' then
                        jsonb_build_object(
                                'old_record',
                                (
                                    select jsonb_object_agg((c).name, (c).value)
                                    from unnest(old_columns) c
                                    where
                                        (c).is_selectable
                                        and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                        and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                )
                            )
                    when action = 'DELETE' then
                        jsonb_build_object(
                            'old_record',
                            (
                                select jsonb_object_agg((c).name, (c).value)
                                from unnest(old_columns) c
                                where
                                    (c).is_selectable
                                    and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                    and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                            )
                        )
                    else '{}'::jsonb
                end;

                -- Filter visible_role_sub_ids to those matching the current selected_columns group
                visible_to_subscription_ids = coalesce(
                    (
                        select array_agg(s.subscription_id)
                        from unnest(subscriptions) s
                        where s.claims_role = working_role
                          and (s.selected_columns is not distinct from working_selected_columns)
                          and s.subscription_id = any(visible_role_sub_ids)
                    ),
                    '{}'::uuid[]
                );

                return next (
                    output,
                    is_rls_enabled,
                    visible_to_subscription_ids,
                    case
                        when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                        else '{}'
                    end
                )::realtime.wal_rls;
            end loop;

        end if;
    end loop;

    perform set_config('role', null, true);
end;
$$;


--
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


--
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


--
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
/*
Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
*/
declare
    op_symbol text = (
        case
            when op = 'eq' then '='
            when op = 'neq' then '!='
            when op = 'lt' then '<'
            when op = 'lte' then '<='
            when op = 'gt' then '>'
            when op = 'gte' then '>='
            when op = 'in' then '= any'
            else 'UNKNOWN OP'
        end
    );
    res boolean;
begin
    execute format(
        'select %L::'|| type_::text || ' ' || op_symbol
        || ' ( %L::'
        || (
            case
                when op = 'in' then type_::text || '[]'
                else type_::text end
        )
        || ')', val_1, val_2) into res;
    return res;
end;
$$;


--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) RETURNS boolean
    LANGUAGE plpgsql STABLE
    AS $$
declare
    op_symbol text;
    res boolean;
begin
    -- IS DISTINCT FROM / IS NOT DISTINCT FROM: infix, both sides typed literals
    if op = 'isdistinct' then
        execute format(
            'select %L::%s %s %L::%s',
            val_1,
            type_::text,
            case when negate then 'IS NOT DISTINCT FROM' else 'IS DISTINCT FROM' end,
            val_2,
            type_::text
        ) into res;
        return res;
    end if;

    -- IS requires a keyword RHS (NULL, TRUE, FALSE, UNKNOWN), not a typed literal
    if op = 'is' then
        if val_2 not in ('null', 'true', 'false', 'unknown') then
            raise exception 'invalid value for is filter: must be null, true, false, or unknown';
        end if;
        execute format(
            'select %L::%s %s %s',
            val_1,
            type_::text,
            case when negate then 'IS NOT' else 'IS' end,
            upper(val_2)
        ) into res;
        return res;
    end if;

    op_symbol = case
        when op = 'eq'    then '='
        when op = 'neq'   then '!='
        when op = 'lt'    then '<'
        when op = 'lte'   then '<='
        when op = 'gt'    then '>'
        when op = 'gte'   then '>='
        when op = 'in'    then '= any'
        when op = 'like'   then 'LIKE'
        when op = 'ilike'  then 'ILIKE'
        when op = 'match'  then '~'
        when op = 'imatch' then '~*'
        else null
    end;

    if op_symbol is null then
        raise exception 'unsupported equality operator: %', op::text;
    end if;

    execute format(
        'select %L::%s %s (%L::%s)',
        val_1,
        type_::text,
        op_symbol,
        val_2,
        case when op = 'in' then type_::text || '[]' else type_::text end
    ) into res;

    return case when negate then not res else res end;
end;
$$;


--
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
    select
        filters is null
        or array_length(filters, 1) is null
        or coalesce(
            count(col.name) = count(1)
            and sum(
                realtime.check_equality_op(
                    op:=f.op,
                    type_:=coalesce(col.type_oid::regtype, col.type_name::regtype),
                    val_1:=col.value #>> '{}',
                    val_2:=f.value,
                    negate:=coalesce(f.negate, false)
                )::int
            ) filter (where col.name is not null) = count(col.name),
            false
        )
    from
        unnest(filters) f
        left join unnest(columns) col
            on f.column_name = col.name;
$$;


--
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS TABLE(wal jsonb, is_rls_enabled boolean, subscription_ids uuid[], errors text[], slot_changes_count bigint)
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


--
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  SELECT
    realtime.wal2json_escape_identifier(nsp.nspname::text)
    || '.'
    || realtime.wal2json_escape_identifier(pc.relname::text)
  FROM pg_class pc
  JOIN pg_namespace nsp ON pc.relnamespace = nsp.oid
  WHERE pc.oid = entity
$$;


--
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- Name: send_binary(bytea, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, binary_payload, event, topic, private, extension)
    VALUES (generated_id, payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
    col_names text[] = coalesce(
            array_agg(a.attname order by a.attnum),
            '{}'::text[]
        )
        from
            pg_catalog.pg_attribute a
        where
            a.attrelid = new.entity
            and a.attnum > 0
            and not a.attisdropped
            and pg_catalog.has_column_privilege(
                (new.claims ->> 'role'),
                a.attrelid,
                a.attnum,
                'SELECT'
            );
    filter realtime.user_defined_filter;
    col_type regtype;
    in_val jsonb;
    selected_col text;
begin
    for filter in select * from unnest(new.filters) loop
        if not filter.column_name = any(col_names) then
            raise exception 'invalid column for filter %', filter.column_name;
        end if;

        col_type = (
            select atttypid::regtype
            from pg_catalog.pg_attribute
            where attrelid = new.entity
                  and attname = filter.column_name
        );
        if col_type is null then
            raise exception 'failed to lookup type for column %', filter.column_name;
        end if;

        if filter.op = 'in'::realtime.equality_op then
            in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
            if coalesce(jsonb_array_length(in_val), 0) > 100 then
                raise exception 'too many values for `in` filter. Maximum 100';
            end if;
        elsif filter.op = 'is'::realtime.equality_op then
            -- `is` requires a keyword RHS rather than a typed literal
            if filter.value not in ('null', 'true', 'false', 'unknown') then
                raise exception 'invalid value for is filter: must be null, true, false, or unknown';
            end if;
            -- IS NULL works for any type, but IS TRUE/FALSE/UNKNOWN require a boolean
            -- operand. Reject the non-null keywords on non-boolean columns here so they
            -- don't abort apply_rls at WAL time.
            if filter.value <> 'null' and col_type <> 'boolean'::regtype then
                raise exception 'is % filter requires a boolean column, got %', filter.value, col_type::text;
            end if;
        elsif filter.op in ('like'::realtime.equality_op, 'ilike'::realtime.equality_op) then
            -- like/ilike apply the text pattern operator (~~); reject column types that
            -- have no such operator instead of failing at WAL time
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = '~~' and oprleft = col_type
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
        elsif filter.op in ('match'::realtime.equality_op, 'imatch'::realtime.equality_op) then
            -- match/imatch apply the regex operators ~ / ~*; reject column types that have
            -- no such operator (e.g. integer) instead of failing at WAL time, mirroring the
            -- like/ilike guard above.
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = case when filter.op = 'imatch'::realtime.equality_op then '~*' else '~' end
                  and oprleft = col_type
                  and oprright = col_type
                  and oprresult = 'boolean'::regtype
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
            -- validate the regex eagerly so a bad pattern is rejected here, not inside
            -- apply_rls where it would abort the WAL stream for the entity
            begin
                perform '' ~ filter.value;
            exception when others then
                raise exception 'invalid regular expression for % filter: %', filter.op::text, sqlerrm;
            end;
        else
            -- eq/neq/lt/lte/gt/gte: value must be coercable to the type
            perform realtime.cast(filter.value, col_type);
        end if;
    end loop;

    if new.selected_columns is not null then
        for selected_col in select * from unnest(new.selected_columns) loop
            if not selected_col = any(col_names) then
                raise exception 'invalid column for select %', selected_col;
            end if;
        end loop;
    end if;

    -- Apply consistent order to filters so the unique constraint can't be tricked by a
    -- different filter order. negate is part of the sort key.
    new.filters = coalesce(
        array_agg(f order by f.column_name, f.op, f.value, f.negate),
        '{}'
    ) from unnest(new.filters) f;

    -- Normalize selected_columns order so ARRAY['a','b'] and ARRAY['b','a'] are treated
    -- as the same subscription group in apply_rls. Preserve an empty array as '{}'
    -- ("primary keys only") so it stays distinct from NULL ("all columns"); array_agg
    -- over an empty set would otherwise collapse '{}' back to NULL.
    if new.selected_columns is not null then
        new.selected_columns = coalesce(
            (
                select array_agg(c order by c)
                from unnest(new.selected_columns) c
            ),
            '{}'::text[]
        );
    end if;

    return new;
end;
$$;


--
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


--
-- Name: wal2json_escape_identifier(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.wal2json_escape_identifier(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  -- Prefix `\`, `,`, `.`, and any whitespace with `\`
  SELECT regexp_replace(name, '([\\,.[:space:]])', '\\\1', 'g')
$$;


--
-- Name: allow_any_operation(text[]); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.allow_any_operation(expected_operations text[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


--
-- Name: allow_only_operation(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.allow_only_operation(expected_operation text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    SELECT string_to_array(name, '/') INTO _parts;
    RETURN _parts[array_length(_parts, 1)];
END
$$;


--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


--
-- Name: get_common_prefix(text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


--
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


--
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.protect_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_prefix_len INT;
    v_prefix_start INT;
    v_combined_levels INT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_prefix_len := length(coalesce(prefix, ''));
    v_prefix_start := coalesce(array_length(string_to_array(coalesce(prefix, ''), v_delimiter), 1), 1);
    v_combined_levels := coalesce(array_length(string_to_array(v_prefix, v_delimiter), 1), 1);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT array_to_string(path_tokens[$1:$2], '/') AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $3 || '%%'
                  AND bucket_id = $4
                  AND array_length(objects.path_tokens, 1) <> $2
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT array_to_string(path_tokens[$1:$2], '/') AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $3 || '%%'
               AND bucket_id = $4
               AND array_length(objects.path_tokens, 1) = $2
             ORDER BY %I %s)
            LIMIT $5 OFFSET $6
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING v_prefix_start, v_combined_levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := substring(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter) from v_prefix_len + 1);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := substring(v_current.name from v_prefix_len + 1);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


--
-- Name: search_by_timestamp(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
    v_sort_order text;
    v_sort_column text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    -- Defense-in-depth: this function is independently reachable and must
    -- not trust p_sort_order/p_sort_column to already be validated by a
    -- caller. Normalize to the same strict allow-list storage.search_v2
    -- uses before interpolating anything into dynamic SQL below.
    v_sort_order := lower(coalesce(p_sort_order, 'asc'));
    IF v_sort_order NOT IN ('asc', 'desc') THEN
        v_sort_order := 'asc';
    END IF;

    v_sort_column := lower(coalesce(p_sort_column, 'updated_at'));
    IF v_sort_column NOT IN ('updated_at', 'created_at') THEN
        v_sort_column := 'updated_at';
    END IF;

    IF v_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        v_sort_column,
        v_cursor_op,
        v_sort_column,
        v_sort_order,
        v_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


--
-- Name: search_v2(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text, sort_column text DEFAULT 'name'::text, sort_column_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.custom_oauth_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_type text NOT NULL,
    identifier text NOT NULL,
    name text NOT NULL,
    client_id text NOT NULL,
    client_secret text NOT NULL,
    acceptable_client_ids text[] DEFAULT '{}'::text[] NOT NULL,
    scopes text[] DEFAULT '{}'::text[] NOT NULL,
    pkce_enabled boolean DEFAULT true NOT NULL,
    attribute_mapping jsonb DEFAULT '{}'::jsonb NOT NULL,
    authorization_params jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    email_optional boolean DEFAULT false NOT NULL,
    issuer text,
    discovery_url text,
    skip_nonce_check boolean DEFAULT false NOT NULL,
    cached_discovery jsonb,
    discovery_cached_at timestamp with time zone,
    authorization_url text,
    token_url text,
    userinfo_url text,
    jwks_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    custom_claims_allowlist text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT custom_oauth_providers_authorization_url_https CHECK (((authorization_url IS NULL) OR (authorization_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_authorization_url_length CHECK (((authorization_url IS NULL) OR (char_length(authorization_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_client_id_length CHECK (((char_length(client_id) >= 1) AND (char_length(client_id) <= 512))),
    CONSTRAINT custom_oauth_providers_discovery_url_length CHECK (((discovery_url IS NULL) OR (char_length(discovery_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_identifier_format CHECK ((identifier ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::text)),
    CONSTRAINT custom_oauth_providers_issuer_length CHECK (((issuer IS NULL) OR ((char_length(issuer) >= 1) AND (char_length(issuer) <= 2048)))),
    CONSTRAINT custom_oauth_providers_jwks_uri_https CHECK (((jwks_uri IS NULL) OR (jwks_uri ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_jwks_uri_length CHECK (((jwks_uri IS NULL) OR (char_length(jwks_uri) <= 2048))),
    CONSTRAINT custom_oauth_providers_name_length CHECK (((char_length(name) >= 1) AND (char_length(name) <= 100))),
    CONSTRAINT custom_oauth_providers_oauth2_requires_endpoints CHECK (((provider_type <> 'oauth2'::text) OR ((authorization_url IS NOT NULL) AND (token_url IS NOT NULL) AND (userinfo_url IS NOT NULL)))),
    CONSTRAINT custom_oauth_providers_oidc_discovery_url_https CHECK (((provider_type <> 'oidc'::text) OR (discovery_url IS NULL) OR (discovery_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_issuer_https CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NULL) OR (issuer ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_requires_issuer CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NOT NULL))),
    CONSTRAINT custom_oauth_providers_provider_type_check CHECK ((provider_type = ANY (ARRAY['oauth2'::text, 'oidc'::text]))),
    CONSTRAINT custom_oauth_providers_token_url_https CHECK (((token_url IS NULL) OR (token_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_token_url_length CHECK (((token_url IS NULL) OR (char_length(token_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_userinfo_url_https CHECK (((userinfo_url IS NULL) OR (userinfo_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_userinfo_url_length CHECK (((userinfo_url IS NULL) OR (char_length(userinfo_url) <= 2048)))
);


--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text,
    code_challenge_method auth.code_challenge_method,
    code_challenge text,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone,
    invite_token text,
    referrer text,
    oauth_client_state_id uuid,
    linking_target_id uuid,
    email_optional boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.flow_state IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid,
    last_webauthn_challenge_data jsonb
);


--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: COLUMN mfa_factors.last_webauthn_challenge_data; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.mfa_factors.last_webauthn_challenge_data IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: mfa_recovery_code_sets; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_recovery_code_sets (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    mfa_factor_id uuid NOT NULL,
    failed_verification_count integer DEFAULT 0 NOT NULL,
    verification_locked_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mfa_recovery_code_sets_failed_verification_count_check CHECK ((failed_verification_count >= 0))
);


--
-- Name: mfa_recovery_codes; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_recovery_codes (
    id uuid NOT NULL,
    mfa_recovery_code_set_id uuid NOT NULL,
    code_hash text NOT NULL,
    consumed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_authorizations (
    id uuid NOT NULL,
    authorization_id text NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid,
    redirect_uri text NOT NULL,
    scope text NOT NULL,
    state text,
    resource text,
    code_challenge text,
    code_challenge_method auth.code_challenge_method,
    response_type auth.oauth_response_type DEFAULT 'code'::auth.oauth_response_type NOT NULL,
    status auth.oauth_authorization_status DEFAULT 'pending'::auth.oauth_authorization_status NOT NULL,
    authorization_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:03:00'::interval) NOT NULL,
    approved_at timestamp with time zone,
    nonce text,
    CONSTRAINT oauth_authorizations_authorization_code_length CHECK ((char_length(authorization_code) <= 255)),
    CONSTRAINT oauth_authorizations_code_challenge_length CHECK ((char_length(code_challenge) <= 128)),
    CONSTRAINT oauth_authorizations_expires_at_future CHECK ((expires_at > created_at)),
    CONSTRAINT oauth_authorizations_nonce_length CHECK ((char_length(nonce) <= 255)),
    CONSTRAINT oauth_authorizations_redirect_uri_length CHECK ((char_length(redirect_uri) <= 2048)),
    CONSTRAINT oauth_authorizations_resource_length CHECK ((char_length(resource) <= 2048)),
    CONSTRAINT oauth_authorizations_scope_length CHECK ((char_length(scope) <= 4096)),
    CONSTRAINT oauth_authorizations_state_length CHECK ((char_length(state) <= 4096))
);


--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_client_states (
    id uuid NOT NULL,
    provider_type text NOT NULL,
    code_verifier text,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: TABLE oauth_client_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.oauth_client_states IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_secret_hash text,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    client_type auth.oauth_client_type DEFAULT 'confidential'::auth.oauth_client_type NOT NULL,
    token_endpoint_auth_method text NOT NULL,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048)),
    CONSTRAINT oauth_clients_token_endpoint_auth_method_check CHECK ((token_endpoint_auth_method = ANY (ARRAY['client_secret_basic'::text, 'client_secret_post'::text, 'none'::text])))
);


--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_consents (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    scopes text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT oauth_consents_revoked_after_granted CHECK (((revoked_at IS NULL) OR (revoked_at >= granted_at))),
    CONSTRAINT oauth_consents_scopes_length CHECK ((char_length(scopes) <= 2048)),
    CONSTRAINT oauth_consents_scopes_not_empty CHECK ((char_length(TRIM(BOTH FROM scopes)) > 0))
);


--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: -
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: -
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: scim_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.scim_tokens (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    token_hash text NOT NULL,
    prefix text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    revoked_at timestamp with time zone,
    last_used_at timestamp with time zone,
    CONSTRAINT scim_tokens_expires_at_future CHECK (((expires_at IS NULL) OR (expires_at > created_at))),
    CONSTRAINT scim_tokens_revoked_after_created CHECK (((revoked_at IS NULL) OR (revoked_at >= created_at))),
    CONSTRAINT scim_tokens_token_hash_check CHECK ((token_hash ~ '^[0-9a-f]{64}$'::text))
);


--
-- Name: scim_users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.scim_users (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    user_id uuid,
    resource jsonb NOT NULL,
    user_name text GENERATED ALWAYS AS (lower((resource ->> 'userName'::text))) STORED NOT NULL,
    external_id text GENERATED ALWAYS AS ((resource ->> 'externalId'::text)) STORED,
    active boolean GENERATED ALWAYS AS (COALESCE(((resource ->> 'active'::text))::boolean, true)) STORED NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text,
    oauth_client_id uuid,
    refresh_token_hmac_key text,
    refresh_token_counter bigint,
    scopes text,
    CONSTRAINT sessions_scopes_length CHECK ((char_length(scopes) <= 4096))
);


--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN sessions.refresh_token_hmac_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.refresh_token_hmac_key IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN sessions.refresh_token_counter; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.refresh_token_counter IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.webauthn_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    challenge_type text NOT NULL,
    session_data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT webauthn_challenges_challenge_type_check CHECK ((challenge_type = ANY (ARRAY['signup'::text, 'registration'::text, 'authentication'::text])))
);


--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.webauthn_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    credential_id bytea NOT NULL,
    public_key bytea NOT NULL,
    attestation_type text DEFAULT ''::text NOT NULL,
    aaguid uuid,
    sign_count bigint DEFAULT 0 NOT NULL,
    transports jsonb DEFAULT '[]'::jsonb NOT NULL,
    backup_eligible boolean DEFAULT false NOT NULL,
    backed_up boolean DEFAULT false NOT NULL,
    friendly_name text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone
);


--
-- Name: account; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ledger_id uuid DEFAULT public.my_ledger() NOT NULL,
    name text NOT NULL,
    kind text NOT NULL,
    valuation text NOT NULL,
    unit text NOT NULL,
    instrument_id uuid,
    is_spendable boolean DEFAULT true NOT NULL,
    fx_source text,
    matures_on date,
    expected_amount numeric(38,18),
    institution text,
    archived_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT account_fx_source_check CHECK ((fx_source = ANY (ARRAY['oficial'::text, 'mep'::text, 'blue'::text, 'ccl'::text, 'manual'::text]))),
    CONSTRAINT account_kind_check CHECK ((kind = ANY (ARRAY['asset'::text, 'liability'::text]))),
    CONSTRAINT account_valuation_check CHECK ((valuation = ANY (ARRAY['balance'::text, 'accrual'::text, 'market'::text]))),
    CONSTRAINT accrual_needs_maturity CHECK (((valuation <> 'accrual'::text) OR (matures_on IS NOT NULL))),
    CONSTRAINT market_needs_instrument CHECK (((valuation = 'market'::text) = (instrument_id IS NOT NULL)))
);

ALTER TABLE ONLY public.account FORCE ROW LEVEL SECURITY;


--
-- Name: COLUMN account.valuation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account.valuation IS 'ADR-012: las cuentas se clasifican por COMO SE VALUAN, no por como las llama el banco. Por eso una cuenta remunerada es balance (ADR-013) y no una inversion.';


--
-- Name: COLUMN account.is_spendable; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account.is_spendable IS 'Responde "cuanto tengo disponible" del punto 8 del brief: efectivo y remunerada si, plazo fijo y posiciones no.';


--
-- Name: account_balance; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.account_balance AS
SELECT
    NULL::uuid AS account_id,
    NULL::uuid AS ledger_id,
    NULL::text AS name,
    NULL::text AS kind,
    NULL::text AS valuation,
    NULL::text AS unit,
    NULL::boolean AS is_spendable,
    NULL::text AS institution,
    NULL::numeric AS balance,
    NULL::bigint AS movimientos;


--
-- Name: VIEW account_balance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.account_balance IS 'Saldo en la UNIDAD de la cuenta, mas cuantos movimientos la usan. Para valuation=market el saldo son unidades, no plata.';


--
-- Name: active_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.active_ledger (
    user_id uuid NOT NULL,
    ledger_id uuid NOT NULL,
    set_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.active_ledger FORCE ROW LEVEL SECURITY;


--
-- Name: budget; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budget (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ledger_id uuid DEFAULT public.my_ledger() NOT NULL,
    category_id uuid NOT NULL,
    period date NOT NULL,
    amount numeric(38,18) NOT NULL,
    currency text NOT NULL,
    CONSTRAINT budget_amount_check CHECK ((amount >= (0)::numeric))
);

ALTER TABLE ONLY public.budget FORCE ROW LEVEL SECURITY;


--
-- Name: category; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.category (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ledger_id uuid DEFAULT public.my_ledger() NOT NULL,
    parent_id uuid,
    name text NOT NULL,
    kind text NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    archived_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    system_role text,
    CONSTRAINT category_kind_check CHECK ((kind = ANY (ARRAY['income'::text, 'expense'::text]))),
    CONSTRAINT category_system_role_check CHECK ((system_role = ANY (ARRAY['ajuste'::text, 'interes'::text, 'aporte_enviado'::text, 'aporte_recibido'::text])))
);

ALTER TABLE ONLY public.category FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE category; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.category IS 'ADR-012: "Ahorros" e "Inversiones" NO son categorias. Son cuentas. Sembrarlas aca seria reintroducir el error 1 del analisis, que restaba el ahorro del resultado del mes.';


--
-- Name: COLUMN category.system_role; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.category.system_role IS 'Para que sirve una categoria de sistema. Antes se deducia de is_system + kind, que alcanzaba con dos roles y se rompe con cuatro.';


--
-- Name: entry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.entry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    transaction_id uuid NOT NULL,
    ledger_id uuid DEFAULT public.my_ledger() NOT NULL,
    account_id uuid,
    category_id uuid,
    amount numeric(38,18) NOT NULL,
    unit text NOT NULL,
    CONSTRAINT entry_targets_exactly_one CHECK ((num_nonnulls(account_id, category_id) = 1))
);

ALTER TABLE ONLY public.entry FORCE ROW LEVEL SECURITY;


--
-- Name: COLUMN entry.amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.entry.amount IS 'El signo es SIEMPRE desde la perspectiva del patrimonio. En un pasivo, positivo = debes MENOS. En una categoria de ingreso, negativo. Es lo que hace que la suma de cero y que Resultado del mes = -SUM(entries de categorias).';


--
-- Name: category_usage; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.category_usage WITH (security_invoker='on') AS
 SELECT c.id AS category_id,
    c.ledger_id,
    c.name,
    c.kind,
    c.parent_id,
    c.is_system,
    c.sort_order,
    COALESCE(propio.n, (0)::bigint) AS movimientos,
    (COALESCE(propio.n, (0)::bigint) + COALESCE(abajo.n, (0)::bigint)) AS movimientos_arbol,
    COALESCE(abajo.hijas, (0)::bigint) AS hijas
   FROM ((public.category c
     LEFT JOIN LATERAL ( SELECT count(*) AS n
           FROM public.entry e
          WHERE (e.category_id = c.id)) propio ON (true))
     LEFT JOIN LATERAL ( SELECT count(*) FILTER (WHERE (e.id IS NOT NULL)) AS n,
            count(DISTINCT h.id) AS hijas
           FROM (public.category h
             LEFT JOIN public.entry e ON ((e.category_id = h.id)))
          WHERE ((h.parent_id = c.id) AND (h.archived_at IS NULL))) abajo ON (true))
  WHERE (c.archived_at IS NULL);


--
-- Name: VIEW category_usage; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.category_usage IS 'movimientos = lo imputado a ella. movimientos_arbol = con sus hijas incluidas, que es lo que decide si se puede borrar. hijas = por que a veces no se puede aunque no haya un solo movimiento.';


--
-- Name: transaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transaction (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ledger_id uuid DEFAULT public.my_ledger() NOT NULL,
    occurred_on date NOT NULL,
    description text,
    kind text NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    scheduled_event_id uuid,
    installments integer,
    cross_ref uuid,
    CONSTRAINT transaction_installments_check CHECK (((installments IS NULL) OR ((installments >= 2) AND (installments <= 60)))),
    CONSTRAINT transaction_kind_check CHECK ((kind = ANY (ARRAY['expense'::text, 'income'::text, 'transfer'::text, 'exchange'::text, 'trade'::text, 'adjustment'::text])))
);

ALTER TABLE ONLY public.transaction FORCE ROW LEVEL SECURITY;


--
-- Name: COLUMN transaction.installments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.transaction.installments IS 'En cuantas cuotas se pago. null = de una. No cambia la contabilidad -la deuda ya esta entera desde el dia 1- solo permite proyectar cuando cae. OD-23.';


--
-- Name: COLUMN transaction.cross_ref; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.transaction.cross_ref IS 'Une las dos mitades de un aporte entre libros. No es una clave foranea: las dos mitades viven en libros distintos a proposito. ADR-032.';


--
-- Name: cuota; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.cuota WITH (security_invoker='on') AS
 SELECT t.id AS transaction_id,
    t.ledger_id,
    t.description,
    t.occurred_on AS comprado_el,
    a.id AS account_id,
    a.name AS tarjeta,
    n.n AS numero,
    t.installments AS total,
    ((date_trunc('month'::text, (t.occurred_on)::timestamp with time zone) + ((n.n || ' month'::text))::interval))::date AS mes,
    round((abs(e.amount) / (t.installments)::numeric), 2) AS monto,
    e.unit
   FROM (((public.transaction t
     JOIN public.entry e ON (((e.transaction_id = t.id) AND (e.account_id IS NOT NULL))))
     JOIN public.account a ON (((a.id = e.account_id) AND (a.kind = 'liability'::text))))
     CROSS JOIN LATERAL generate_series(1, t.installments) n(n))
  WHERE (t.installments IS NOT NULL);


--
-- Name: entry_detail; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.entry_detail WITH (security_invoker='on') AS
 SELECT e.id,
    e.transaction_id,
    e.ledger_id,
    e.amount,
    e.unit,
    e.account_id,
    a.name AS account_name,
    a.kind AS account_kind,
    a.valuation AS account_valuation,
    a.institution AS account_institution,
    e.category_id,
    c.name AS category_name,
    c.kind AS category_kind,
    c.is_system AS category_is_system,
    c.system_role AS category_role,
    p.name AS category_parent,
    t.occurred_on,
    t.description,
    t.kind AS tx_kind,
    t.installments,
    t.created_at
   FROM ((((public.entry e
     JOIN public.transaction t ON ((t.id = e.transaction_id)))
     LEFT JOIN public.account a ON ((a.id = e.account_id)))
     LEFT JOIN public.category c ON ((c.id = e.category_id)))
     LEFT JOIN public.category p ON ((p.id = c.parent_id)));


--
-- Name: flujo_inversion; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.flujo_inversion WITH (security_invoker='on') AS
 SELECT a.id AS account_id,
    a.valuation,
    t.occurred_on AS fecha,
    c.amount AS monto,
    c.unit AS unidad,
    public.convertir(c.amount, c.unit, t.occurred_on, 'USD'::text, a.fx_source) AS usd,
    public.convertir(c.amount, c.unit, t.occurred_on, 'UVA'::text, a.fx_source) AS uva
   FROM (((public.entry pe
     JOIN public.account a ON (((a.id = pe.account_id) AND (a.valuation = ANY (ARRAY['market'::text, 'accrual'::text])))))
     JOIN public.transaction t ON ((t.id = pe.transaction_id)))
     JOIN public.entry c ON (((c.transaction_id = pe.transaction_id) AND (c.account_id IS NOT NULL) AND (c.account_id <> a.id))));


--
-- Name: portfolio; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.portfolio (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ledger_id uuid DEFAULT public.my_ledger() NOT NULL,
    name text NOT NULL,
    fx_source text,
    archived_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.portfolio FORCE ROW LEVEL SECURITY;


--
-- Name: portfolio_account; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.portfolio_account (
    portfolio_id uuid NOT NULL,
    account_id uuid NOT NULL,
    ledger_id uuid NOT NULL,
    added_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.portfolio_account FORCE ROW LEVEL SECURITY;


--
-- Name: flujo_portafolio; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.flujo_portafolio WITH (security_invoker='on') AS
 WITH participa AS (
         SELECT DISTINCT pa.portfolio_id,
            e.transaction_id
           FROM (public.entry e
             JOIN public.portfolio_account pa ON ((pa.account_id = e.account_id)))
        )
 SELECT pp.portfolio_id,
    t.occurred_on AS fecha,
    c.unit AS unidad,
    sum(c.amount) AS monto,
    public.convertir(sum(c.amount), c.unit, t.occurred_on, 'USD'::text, pf.fx_source) AS usd,
    public.convertir(sum(c.amount), c.unit, t.occurred_on, 'UVA'::text, pf.fx_source) AS uva
   FROM (((participa pp
     JOIN public.portfolio pf ON ((pf.id = pp.portfolio_id)))
     JOIN public.transaction t ON ((t.id = pp.transaction_id)))
     JOIN public.entry c ON (((c.transaction_id = t.id) AND (c.account_id IS NOT NULL))))
  WHERE (NOT (EXISTS ( SELECT 1
           FROM public.portfolio_account x
          WHERE ((x.portfolio_id = pp.portfolio_id) AND (x.account_id = c.account_id)))))
  GROUP BY pp.portfolio_id, t.id, t.occurred_on, c.unit, pf.fx_source;


--
-- Name: VIEW flujo_portafolio; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.flujo_portafolio IS 'Solo lo que cruza el borde de cada cartera. Con carteras que se solapan, la misma operacion puede cruzar una y no otra: los bordes son distintos y las dos lecturas son ciertas. ADR-026 / OD-40.';


--
-- Name: fx_rate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fx_rate (
    ledger_id uuid DEFAULT public.my_ledger() NOT NULL,
    on_date date NOT NULL,
    base text NOT NULL,
    quote text NOT NULL,
    rate numeric(38,18) NOT NULL,
    source text NOT NULL,
    CONSTRAINT fx_rate_rate_check CHECK ((rate > (0)::numeric)),
    CONSTRAINT fx_rate_source_check CHECK ((source = ANY (ARRAY['oficial'::text, 'mep'::text, 'blue'::text, 'ccl'::text, 'cripto'::text, 'mayorista'::text, 'uva'::text, 'manual'::text])))
);

ALTER TABLE ONLY public.fx_rate FORCE ROW LEVEL SECURITY;


--
-- Name: instrument; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.instrument (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ledger_id uuid DEFAULT public.my_ledger() NOT NULL,
    symbol text NOT NULL,
    name text NOT NULL,
    kind text NOT NULL,
    quote_currency text NOT NULL,
    decimals integer DEFAULT 2 NOT NULL,
    ratio numeric(38,18),
    underlying_symbol text,
    archived_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    quote_size numeric(38,18) DEFAULT 1 NOT NULL,
    CONSTRAINT instrument_kind_check CHECK ((kind = ANY (ARRAY['cedear'::text, 'crypto'::text, 'stock'::text, 'etf'::text, 'fund'::text, 'bond'::text, 'other'::text]))),
    CONSTRAINT instrument_quote_size_check CHECK ((quote_size > (0)::numeric))
);

ALTER TABLE ONLY public.instrument FORCE ROW LEVEL SECURITY;


--
-- Name: COLUMN instrument.ratio; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.instrument.ratio IS 'Cuantos CEDEARs equivalen a una accion. Informativo: ADR-024 mide al CCL, y esa division no necesita el ratio.';


--
-- Name: COLUMN instrument.underlying_symbol; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.instrument.underlying_symbol IS 'El simbolo del activo en la fuente de precios. Para un CEDEAR es la accion que representa (AAPL), que es como lo publica BYMA. Sin esto no hay precio automatico: ADR-025.';


--
-- Name: COLUMN instrument.quote_size; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.instrument.quote_size IS 'A cuantas unidades corresponde el precio cotizado. 1 para acciones, CEDEARs y cripto; 100 para bonos y obligaciones negociables, que cotizan por cada 100 nominales. El valor de una posicion es saldo * precio / quote_size.';


--
-- Name: ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ledger (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    registry_currency text DEFAULT 'ARS'::text NOT NULL,
    measurement_currency text DEFAULT 'USD'::text NOT NULL,
    default_fx_source text DEFAULT 'mep'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    archived_at timestamp with time zone
);

ALTER TABLE ONLY public.ledger FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE ledger; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ledger IS 'El libro. ADR-003: toda fila del dominio le pertenece a uno, nunca a un usuario directo. Hoy cada usuario tiene exactamente uno y NO aparece en la interfaz.';


--
-- Name: COLUMN ledger.archived_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ledger.archived_at IS 'Un libro archivado deja de aparecer y deja de poder ser el activo, pero su historia queda entera.';


--
-- Name: ledger_invite; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ledger_invite (
    code text NOT NULL,
    ledger_id uuid NOT NULL,
    role text DEFAULT 'member'::text NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '7 days'::interval) NOT NULL,
    used_by uuid,
    used_at timestamp with time zone,
    CONSTRAINT ledger_invite_role_check CHECK ((role = ANY (ARRAY['owner'::text, 'member'::text])))
);

ALTER TABLE ONLY public.ledger_invite FORCE ROW LEVEL SECURITY;


--
-- Name: ledger_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ledger_member (
    ledger_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role text DEFAULT 'owner'::text NOT NULL,
    joined_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ledger_member_role_check CHECK ((role = ANY (ARRAY['owner'::text, 'member'::text])))
);

ALTER TABLE ONLY public.ledger_member FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE ledger_member; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ledger_member IS 'ADR-002 mantiene a los usuarios aislados. El día que eso cambie, compartir es un INSERT acá y ninguna politica de RLS se toca.';


--
-- Name: medicion_faltante; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.medicion_faltante WITH (security_invoker='on') AS
 WITH fechas AS (
         SELECT DISTINCT t.occurred_on AS fecha
           FROM ((public.entry e
             JOIN public.account a ON ((a.id = e.account_id)))
             JOIN public.transaction t ON ((t.id = e.transaction_id)))
          WHERE (a.valuation = ANY (ARRAY['market'::text, 'accrual'::text]))
        UNION
         SELECT CURRENT_DATE AS "current_date"
        ), evaluada AS (
         SELECT f.fecha,
            public.cotizacion_al(f.fecha, public.my_fx_source()) AS dolar_al,
            public.cotizacion_al(f.fecha, 'uva'::text, 'UVA'::text, 'ARS'::text) AS uva_al
           FROM fechas f
        )
 SELECT fecha,
    dolar_al,
    uva_al,
    (dolar_al IS NULL) AS sin_dolar,
    (uva_al IS NULL) AS sin_uva,
    ((dolar_al IS NOT NULL) AND ((fecha - dolar_al) > 7)) AS dolar_viejo,
    ((uva_al IS NOT NULL) AND ((fecha - uva_al) > 7)) AS uva_viejo
   FROM evaluada
  WHERE ((dolar_al IS NULL) OR (uva_al IS NULL) OR ((fecha - dolar_al) > 7) OR ((fecha - uva_al) > 7));


--
-- Name: mi_libro; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.mi_libro WITH (security_invoker=off) AS
 SELECT l.id AS ledger_id,
    l.name,
    m.role,
    (l.id = public.my_ledger()) AS activo,
    ( SELECT count(*) AS count
           FROM public.ledger_member x
          WHERE (x.ledger_id = l.id)) AS miembros,
    ( SELECT count(*) AS count
           FROM public.transaction t
          WHERE (t.ledger_id = l.id)) AS movimientos,
    m.joined_at
   FROM (public.ledger l
     JOIN public.ledger_member m ON ((m.ledger_id = l.id)))
  WHERE ((m.user_id = auth.uid()) AND (l.archived_at IS NULL));


--
-- Name: price; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price (
    instrument_id uuid NOT NULL,
    ledger_id uuid DEFAULT public.my_ledger() NOT NULL,
    on_date date NOT NULL,
    price numeric(38,18) NOT NULL,
    currency text NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    CONSTRAINT price_price_check CHECK ((price >= (0)::numeric))
);

ALTER TABLE ONLY public.price FORCE ROW LEVEL SECURITY;


--
-- Name: posicion; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.posicion WITH (security_invoker='on') AS
 SELECT a.id AS account_id,
    a.ledger_id,
    a.name,
    a.institution,
    a.fx_source,
    i.id AS instrument_id,
    i.symbol,
    i.name AS instrument_name,
    i.kind,
    i.quote_currency,
    i.decimals,
    i.ratio,
    i.underlying_symbol,
    i.quote_size,
    COALESCE(u.unidades, (0)::numeric) AS unidades,
    p.price AS precio,
    p.on_date AS precio_al,
    p.source AS precio_fuente,
    ((COALESCE(u.unidades, (0)::numeric) * p.price) / COALESCE(i.quote_size, (1)::numeric)) AS valor,
    COALESCE(f.invertido, (0)::numeric) AS invertido,
    (((COALESCE(u.unidades, (0)::numeric) * p.price) / COALESCE(i.quote_size, (1)::numeric)) - COALESCE(f.invertido, (0)::numeric)) AS ganancia
   FROM ((((public.account a
     JOIN public.instrument i ON ((i.id = a.instrument_id)))
     LEFT JOIN LATERAL ( SELECT sum(e.amount) AS unidades
           FROM public.entry e
          WHERE (e.account_id = a.id)) u ON (true))
     LEFT JOIN LATERAL ( SELECT (- sum(c.amount)) AS invertido
           FROM (public.entry pe
             JOIN public.entry c ON (((c.transaction_id = pe.transaction_id) AND (c.account_id IS NOT NULL) AND (c.account_id <> a.id))))
          WHERE (pe.account_id = a.id)) f ON (true))
     LEFT JOIN LATERAL ( SELECT pr.price,
            pr.on_date,
            pr.source
           FROM public.price pr
          WHERE (pr.instrument_id = i.id)
          ORDER BY pr.on_date DESC
         LIMIT 1) p ON (true))
  WHERE ((a.valuation = 'market'::text) AND (a.archived_at IS NULL));


--
-- Name: resumen_tarjeta; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.resumen_tarjeta WITH (security_invoker='on') AS
 SELECT account_id,
    tarjeta,
    ledger_id,
    mes,
    unit,
    sum(monto) AS total,
    count(*) AS cuotas
   FROM public.cuota
  WHERE (mes >= date_trunc('month'::text, (CURRENT_DATE)::timestamp with time zone))
  GROUP BY account_id, tarjeta, ledger_id, mes, unit;


--
-- Name: VIEW resumen_tarjeta; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.resumen_tarjeta IS 'Lo que cae en cada resumen futuro por compras en cuotas. NO incluye los consumos de una sola cuota: esos ya estan en el saldo y se pagan enseguida.';


--
-- Name: scheduled_event; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scheduled_event (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ledger_id uuid DEFAULT public.my_ledger() NOT NULL,
    kind text NOT NULL,
    description text NOT NULL,
    category_id uuid,
    account_id uuid,
    amount numeric(38,18),
    currency text NOT NULL,
    frequency text,
    next_on date NOT NULL,
    ends_on date,
    archived_at timestamp with time zone,
    counter_account_id uuid,
    month_end boolean DEFAULT false NOT NULL,
    CONSTRAINT recurring_needs_frequency CHECK (((kind <> 'recurring'::text) OR (frequency IS NOT NULL))),
    CONSTRAINT scheduled_event_frequency_check CHECK ((frequency = ANY (ARRAY['weekly'::text, 'monthly'::text, 'bimonthly'::text, 'quarterly'::text, 'biannual'::text, 'yearly'::text]))),
    CONSTRAINT scheduled_event_kind_check CHECK ((kind = ANY (ARRAY['recurring'::text, 'maturity'::text])))
);

ALTER TABLE ONLY public.scheduled_event FORCE ROW LEVEL SECURITY;


--
-- Name: COLUMN scheduled_event.month_end; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.scheduled_event.month_end IS 'true = vence el ULTIMO dia del mes, sea 28, 30 o 31. Sin esto la fecha se degrada al 28 tras el primer febrero y no vuelve. OD-38.';


--
-- Name: upcoming; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.upcoming WITH (security_invoker='on') AS
 SELECT s.id,
    s.ledger_id,
    s.kind,
    s.description,
    s.amount,
    s.currency,
    s.frequency,
    s.next_on,
    s.ends_on,
    s.category_id,
    c.name AS category_name,
    p.name AS category_parent,
    s.account_id,
    a.name AS account_name,
    s.counter_account_id,
    d.name AS counter_account_name,
        CASE
            WHEN (s.kind = 'maturity'::text) THEN ( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
               FROM public.entry e
              WHERE (e.account_id = s.account_id))
            ELSE NULL::numeric
        END AS capital,
    (s.next_on - CURRENT_DATE) AS dias,
    (s.next_on < CURRENT_DATE) AS vencido
   FROM ((((public.scheduled_event s
     LEFT JOIN public.category c ON ((c.id = s.category_id)))
     LEFT JOIN public.category p ON ((p.id = c.parent_id)))
     LEFT JOIN public.account a ON ((a.id = s.account_id)))
     LEFT JOIN public.account d ON ((d.id = s.counter_account_id)))
  WHERE ((s.archived_at IS NULL) AND ((s.ends_on IS NULL) OR (s.ends_on >= CURRENT_DATE)));


--
-- Name: valor_cuenta; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.valor_cuenta WITH (security_invoker='on') AS
 SELECT a.id AS account_id,
    a.ledger_id,
    a.name,
    a.kind AS account_kind,
    a.valuation,
    a.unit,
    a.institution,
    a.matures_on,
    (a.archived_at IS NOT NULL) AS cerrada,
    a.fx_source,
    i.symbol,
    i.kind,
    i.quote_currency,
    i.ratio,
    i.underlying_symbol,
    i.quote_size,
    COALESCE(sal.saldo, (0)::numeric) AS saldo,
    COALESCE(car.n, (0)::bigint) AS carteras,
    v.valor_nativo,
        CASE
            WHEN (a.valuation = 'market'::text) THEN i.quote_currency
            ELSE a.unit
        END AS moneda,
    pr.on_date AS precio_al,
    public.convertir(v.valor_nativo,
        CASE
            WHEN (a.valuation = 'market'::text) THEN i.quote_currency
            ELSE a.unit
        END, CURRENT_DATE, 'USD'::text, a.fx_source) AS usd,
    public.convertir(v.valor_nativo,
        CASE
            WHEN (a.valuation = 'market'::text) THEN i.quote_currency
            ELSE a.unit
        END, CURRENT_DATE, 'UVA'::text, a.fx_source) AS uva
   FROM (((((public.account a
     LEFT JOIN public.instrument i ON ((i.id = a.instrument_id)))
     LEFT JOIN LATERAL ( SELECT sum(e.amount) AS saldo
           FROM public.entry e
          WHERE (e.account_id = a.id)) sal ON (true))
     LEFT JOIN LATERAL ( SELECT count(*) AS n
           FROM public.portfolio_account pa
          WHERE (pa.account_id = a.id)) car ON (true))
     LEFT JOIN LATERAL ( SELECT p.price,
            p.on_date
           FROM public.price p
          WHERE (p.instrument_id = a.instrument_id)
          ORDER BY p.on_date DESC
         LIMIT 1) pr ON (true))
     LEFT JOIN LATERAL ( SELECT
                CASE
                    WHEN (COALESCE(sal.saldo, (0)::numeric) = (0)::numeric) THEN (0)::numeric
                    WHEN (a.valuation = 'market'::text) THEN ((sal.saldo * pr.price) / COALESCE(i.quote_size, (1)::numeric))
                    ELSE sal.saldo
                END AS valor_nativo) v ON (true));


--
-- Name: valor_inversion; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.valor_inversion WITH (security_invoker='on') AS
 SELECT account_id,
    ledger_id,
    name,
    account_kind,
    valuation,
    unit,
    institution,
    matures_on,
    cerrada,
    fx_source,
    symbol,
    kind,
    quote_currency,
    ratio,
    underlying_symbol,
    quote_size,
    saldo,
    carteras,
    valor_nativo,
    moneda,
    precio_al,
    usd,
    uva
   FROM public.valor_cuenta
  WHERE (valuation = ANY (ARRAY['market'::text, 'accrual'::text]));


--
-- Name: valor_portafolio; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.valor_portafolio WITH (security_invoker='on') AS
 SELECT p.id AS portfolio_id,
    p.ledger_id,
    p.name,
    p.fx_source,
    (p.archived_at IS NOT NULL) AS cerrado,
    count(v.account_id) AS cuentas,
    count(*) FILTER (WHERE ((v.account_id IS NOT NULL) AND (public.convertir(v.valor_nativo, v.moneda, CURRENT_DATE, 'USD'::text, COALESCE(v.fx_source, p.fx_source)) IS NULL))) AS sin_valuar,
    sum(public.convertir(v.valor_nativo, v.moneda, CURRENT_DATE, 'USD'::text, COALESCE(v.fx_source, p.fx_source))) AS usd,
    sum(public.convertir(v.valor_nativo, v.moneda, CURRENT_DATE, 'UVA'::text, COALESCE(v.fx_source, p.fx_source))) AS uva
   FROM ((public.portfolio p
     LEFT JOIN public.portfolio_account pa ON ((pa.portfolio_id = p.id)))
     LEFT JOIN public.valor_cuenta v ON ((v.account_id = pa.account_id)))
  GROUP BY p.id, p.ledger_id, p.name, p.fx_source, p.archived_at;


--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    binary_payload bytea,
    skip_broadcast boolean DEFAULT false NOT NULL
)
PARTITION BY RANGE (inserted_at);


--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone DEFAULT now()
);


--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    action_filter text DEFAULT '*'::text,
    selected_columns text[],
    CONSTRAINT subscription_action_filter_check CHECK ((action_filter = ANY (ARRAY['*'::text, 'INSERT'::text, 'UPDATE'::text, 'DELETE'::text])))
);


--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: -
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL,
    versioning_status text DEFAULT 'DISABLED'::text NOT NULL,
    CONSTRAINT buckets_versioning_dark_check CHECK ((versioning_status = 'DISABLED'::text)),
    CONSTRAINT buckets_versioning_standard_only_check CHECK (((type = 'STANDARD'::storage.buckettype) OR (versioning_status = 'DISABLED'::text))),
    CONSTRAINT buckets_versioning_status_check CHECK ((versioning_status = ANY (ARRAY['DISABLED'::text, 'ENABLED'::text, 'SUSPENDED'::text])))
);


--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_analytics (
    name text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_vectors (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'VECTOR'::storage.buckettype NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: objects; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb,
    archived_at timestamp with time zone,
    is_delete_marker boolean DEFAULT false NOT NULL,
    is_versioned boolean DEFAULT false NOT NULL
);


--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb,
    metadata jsonb
);


--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.vector_indexes (
    id text DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    bucket_id text NOT NULL,
    data_type text NOT NULL,
    dimension integer NOT NULL,
    distance_metric text NOT NULL,
    metadata_configuration jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: schema_migrations; Type: TABLE; Schema: supabase_migrations; Owner: -
--

CREATE TABLE supabase_migrations.schema_migrations (
    version text NOT NULL,
    statements text[],
    name text
);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.custom_oauth_providers (id, provider_type, identifier, name, client_id, client_secret, acceptable_client_ids, scopes, pkce_enabled, attribute_mapping, authorization_params, enabled, email_optional, issuer, discovery_url, skip_nonce_check, cached_discovery, discovery_cached_at, authorization_url, token_url, userinfo_url, jwks_uri, created_at, updated_at, custom_claims_allowlist) FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at, invite_token, referrer, oauth_client_state_id, linking_target_id, email_optional) FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
3999a016-1304-4a55-84e3-0201bff58969	3999a016-1304-4a55-84e3-0201bff58969	{"sub": "3999a016-1304-4a55-84e3-0201bff58969", "email": "marinejuanluis@gmail.com", "email_verified": false, "phone_verified": false}	email	2026-09-15 16:18:23.630337+00	2026-09-15 16:18:23.630393+00	2026-09-15 16:18:23.630393+00	92b9577f-c165-4194-8500-5c9a383f783e
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
8d66315e-7705-4818-9cfb-2ab5d649e4fe	2026-09-18 21:15:40.953549+00	2026-09-18 21:15:40.953549+00	password	f05b5f7f-8104-40de-8646-b0d537146941
48a966d4-b46e-40ae-ae5f-080893992c62	2026-09-19 12:42:28.624915+00	2026-09-19 12:42:28.624915+00	password	adb18f7a-eeee-4e0b-ad50-0953b20bfe18
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid, last_webauthn_challenge_data) FROM stdin;
\.


--
-- Data for Name: mfa_recovery_code_sets; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_recovery_code_sets (id, user_id, mfa_factor_id, failed_verification_count, verification_locked_until, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_recovery_codes; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_recovery_codes (id, mfa_recovery_code_set_id, code_hash, consumed_at, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_authorizations (id, authorization_id, client_id, user_id, redirect_uri, scope, state, resource, code_challenge, code_challenge_method, response_type, status, authorization_code, created_at, expires_at, approved_at, nonce) FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_client_states (id, provider_type, code_verifier, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_clients (id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at, client_type, token_endpoint_auth_method) FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_consents (id, user_id, client_id, scopes, granted_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at, expires_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
00000000-0000-0000-0000-000000000000	54	bmkdad5vpw6d	3999a016-1304-4a55-84e3-0201bff58969	t	2026-09-18 21:15:40.947587+00	2026-09-19 01:36:45.508069+00	\N	8d66315e-7705-4818-9cfb-2ab5d649e4fe
00000000-0000-0000-0000-000000000000	55	2466awhhv6k3	3999a016-1304-4a55-84e3-0201bff58969	t	2026-09-19 01:36:45.525667+00	2026-09-19 10:49:50.997905+00	bmkdad5vpw6d	8d66315e-7705-4818-9cfb-2ab5d649e4fe
00000000-0000-0000-0000-000000000000	57	jwkqaju6ys2b	3999a016-1304-4a55-84e3-0201bff58969	t	2026-09-19 12:42:28.581839+00	2026-09-19 13:40:30.867559+00	\N	48a966d4-b46e-40ae-ae5f-080893992c62
00000000-0000-0000-0000-000000000000	56	umoms2l72xht	3999a016-1304-4a55-84e3-0201bff58969	t	2026-09-19 10:49:51.019696+00	2026-09-19 19:14:03.012895+00	2466awhhv6k3	8d66315e-7705-4818-9cfb-2ab5d649e4fe
00000000-0000-0000-0000-000000000000	58	j3xpfaqyubdw	3999a016-1304-4a55-84e3-0201bff58969	t	2026-09-19 13:40:30.880208+00	2026-09-20 08:07:46.40628+00	jwkqaju6ys2b	48a966d4-b46e-40ae-ae5f-080893992c62
00000000-0000-0000-0000-000000000000	60	ftjxr6mw7coq	3999a016-1304-4a55-84e3-0201bff58969	f	2026-09-20 08:07:46.425813+00	2026-09-20 08:07:46.425813+00	j3xpfaqyubdw	48a966d4-b46e-40ae-ae5f-080893992c62
00000000-0000-0000-0000-000000000000	59	c37kfqho7qh4	3999a016-1304-4a55-84e3-0201bff58969	t	2026-09-19 19:14:03.033392+00	2026-09-20 12:05:05.794691+00	umoms2l72xht	8d66315e-7705-4818-9cfb-2ab5d649e4fe
00000000-0000-0000-0000-000000000000	61	ta3cvblnmg6x	3999a016-1304-4a55-84e3-0201bff58969	t	2026-09-20 12:05:05.816214+00	2026-09-20 16:44:13.009617+00	c37kfqho7qh4	8d66315e-7705-4818-9cfb-2ab5d649e4fe
00000000-0000-0000-0000-000000000000	62	k36lw4446n3z	3999a016-1304-4a55-84e3-0201bff58969	f	2026-09-20 16:44:13.029304+00	2026-09-20 16:44:13.029304+00	ta3cvblnmg6x	8d66315e-7705-4818-9cfb-2ab5d649e4fe
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
20260625000000
20260821000000
20260821010000
20260824000000
20260824000001
20260831180000
\.


--
-- Data for Name: scim_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.scim_tokens (id, sso_provider_id, token_hash, prefix, created_at, expires_at, revoked_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: scim_users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.scim_users (id, sso_provider_id, user_id, resource, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) FROM stdin;
48a966d4-b46e-40ae-ae5f-080893992c62	3999a016-1304-4a55-84e3-0201bff58969	2026-09-19 12:42:28.54045+00	2026-09-20 08:07:46.45851+00	\N	aal1	\N	2026-09-20 08:07:46.458379	Mozilla/5.0 (Linux; Android 8.0.0; SM-G955U Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Mobile Safari/537.36	181.84.160.79	\N	\N	\N	\N	\N
8d66315e-7705-4818-9cfb-2ab5d649e4fe	3999a016-1304-4a55-84e3-0201bff58969	2026-09-18 21:15:40.928362+00	2026-09-20 16:44:13.05905+00	\N	aal1	\N	2026-09-20 16:44:13.058961	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Mobile Safari/537.36	181.9.206.251	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
00000000-0000-0000-0000-000000000000	3999a016-1304-4a55-84e3-0201bff58969	authenticated	authenticated	marinejuanluis@gmail.com	$2a$10$oHF90NeJk4UN8X6s9ePaiuOQJizwVvSMtDxHogA88hGj6PhiVLSsy	2026-09-15 16:18:23.63579+00	\N		\N		\N			\N	2026-09-19 12:42:28.539725+00	{"provider": "email", "providers": ["email"]}	{"email_verified": true}	\N	2026-09-15 16:18:23.613532+00	2026-09-20 16:44:13.038687+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.webauthn_challenges (id, user_id, challenge_type, session_data, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.webauthn_credentials (id, user_id, credential_id, public_key, attestation_type, aaguid, sign_count, transports, backup_eligible, backed_up, friendly_name, created_at, updated_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.account (id, ledger_id, name, kind, valuation, unit, instrument_id, is_spendable, fx_source, matures_on, expected_amount, institution, archived_at, created_at) FROM stdin;
c3f72011-ab5c-4bd4-8f5b-edb744286b51	313c86c6-73bd-42b6-ae57-d040c6b77521	Banco	asset	balance	ARS	\N	t	\N	\N	\N	Macro	\N	2026-09-18 17:49:53.19407+00
2288db15-b76f-4c4b-8998-3e48a6815094	313c86c6-73bd-42b6-ae57-d040c6b77521	Plazo fijo 90 días	asset	accrual	ARS	\N	f	\N	2026-09-30	19000.000000000000000000	Macro	2026-09-18 19:33:04.495871+00	2026-09-18 18:35:46.935255+00
\.


--
-- Data for Name: active_ledger; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.active_ledger (user_id, ledger_id, set_at) FROM stdin;
3999a016-1304-4a55-84e3-0201bff58969	313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-19 19:15:04.942708+00
\.


--
-- Data for Name: budget; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budget (id, ledger_id, category_id, period, amount, currency) FROM stdin;
\.


--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.category (id, ledger_id, parent_id, name, kind, is_system, sort_order, archived_at, created_at, system_role) FROM stdin;
111a1a56-4920-4fcb-8c2a-090d59d3989e	313c86c6-73bd-42b6-ae57-d040c6b77521	\N	Aporte a otro libro	expense	t	95	\N	2026-09-18 17:54:33.806883+00	aporte_enviado
f0b5a911-7214-44f8-9c8e-64c24ba78626	313c86c6-73bd-42b6-ae57-d040c6b77521	59a2c5b4-fbff-41f8-a5a1-5ca8ad29b3c5	Servicios	expense	f	0	\N	2026-09-18 18:31:02.015192+00	\N
94c62636-89a9-4c18-a41f-3fc8dc5a64ae	313c86c6-73bd-42b6-ae57-d040c6b77521	59a2c5b4-fbff-41f8-a5a1-5ca8ad29b3c5	lala	expense	f	0	\N	2026-09-19 13:26:38.68518+00	\N
a5ddc2ae-5097-4ba7-a4f1-5d8d25e24f31	313c86c6-73bd-42b6-ae57-d040c6b77521	59a2c5b4-fbff-41f8-a5a1-5ca8ad29b3c5	lele	expense	f	0	\N	2026-09-19 13:26:44.368364+00	\N
4d7710f8-cff8-4919-aa4e-a31339df587a	313c86c6-73bd-42b6-ae57-d040c6b77521	59a2c5b4-fbff-41f8-a5a1-5ca8ad29b3c5	lili	expense	f	0	\N	2026-09-19 13:26:51.156546+00	\N
03cf38d7-84ee-4fc2-9656-db0ea5f295dc	313c86c6-73bd-42b6-ae57-d040c6b77521	59a2c5b4-fbff-41f8-a5a1-5ca8ad29b3c5	lolo	expense	f	0	\N	2026-09-19 13:26:56.646719+00	\N
bd389a03-39fb-4888-b835-d70a810c17e7	313c86c6-73bd-42b6-ae57-d040c6b77521	59a2c5b4-fbff-41f8-a5a1-5ca8ad29b3c5	lulu	expense	f	0	\N	2026-09-19 13:27:02.620632+00	\N
cceba37a-f693-42e1-b347-8889317244fd	313c86c6-73bd-42b6-ae57-d040c6b77521	\N	Sueldo	income	f	10	\N	2026-09-18 17:48:44.887245+00	\N
db760432-ea43-48ea-82b7-845ae940d761	313c86c6-73bd-42b6-ae57-d040c6b77521	\N	Intereses	income	t	20	\N	2026-09-18 17:48:44.887245+00	interes
24f77fd4-d2cb-4da2-ac29-5c67d2dec44b	313c86c6-73bd-42b6-ae57-d040c6b77521	\N	Otros ingresos	income	f	30	\N	2026-09-18 17:48:44.887245+00	\N
59a2c5b4-fbff-41f8-a5a1-5ca8ad29b3c5	313c86c6-73bd-42b6-ae57-d040c6b77521	\N	Gastos fijos	expense	f	10	\N	2026-09-18 17:48:44.887245+00	\N
4c091b1f-0d84-4d9f-89a0-4c92540367b9	313c86c6-73bd-42b6-ae57-d040c6b77521	\N	Gastos variables	expense	f	20	\N	2026-09-18 17:48:44.887245+00	\N
bb42d3fc-64b4-4502-9c39-39c32ace6c8e	313c86c6-73bd-42b6-ae57-d040c6b77521	\N	Ajuste de saldo	expense	t	90	\N	2026-09-18 17:48:44.887245+00	ajuste
\.


--
-- Data for Name: entry; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.entry (id, transaction_id, ledger_id, account_id, category_id, amount, unit) FROM stdin;
\.


--
-- Data for Name: fx_rate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fx_rate (ledger_id, on_date, base, quote, rate, source) FROM stdin;
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-16	USD	ARS	1505.000000000000000000	oficial
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-16	USD	ARS	1550.000000000000000000	blue
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-16	USD	ARS	1531.950000000000000000	mep
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-16	USD	ARS	1593.949999999999800000	ccl
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-16	USD	ARS	1591.645000000000000000	cripto
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-16	USD	ARS	1502.000000000000000000	mayorista
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-16	UVA	ARS	2121.720000000000000000	uva
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-17	USD	ARS	1510.000000000000000000	oficial
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-17	USD	ARS	1550.000000000000000000	blue
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-17	USD	ARS	1538.100000000000000000	mep
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-17	USD	ARS	1599.050000000000200000	ccl
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-17	USD	ARS	1590.180000000000000000	cripto
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-17	USD	ARS	1509.000000000000000000	mayorista
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-17	UVA	ARS	2122.910000000000000000	uva
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-18	USD	ARS	1510.000000000000000000	oficial
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-18	USD	ARS	1545.000000000000000000	blue
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-18	USD	ARS	1531.550000000000200000	mep
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-18	USD	ARS	1592.550000000000200000	ccl
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-18	USD	ARS	1591.545000000000000000	cripto
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-18	USD	ARS	1505.500000000000000000	mayorista
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-18	UVA	ARS	2124.100000000000000000	uva
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-21	USD	ARS	1510.000000000000000000	oficial
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-21	USD	ARS	1540.000000000000000000	blue
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-21	USD	ARS	1535.150000000000000000	mep
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-21	USD	ARS	1597.300000000000000000	ccl
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-21	USD	ARS	1591.420000000000000000	cripto
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-21	USD	ARS	1510.000000000000000000	mayorista
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-21	UVA	ARS	2125.300000000000000000	uva
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-22	USD	ARS	1510.000000000000000000	oficial
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-22	USD	ARS	1540.000000000000000000	blue
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-22	USD	ARS	1534.050000000000000000	mep
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-22	USD	ARS	1595.700000000000000000	ccl
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-22	USD	ARS	1592.625000000000000000	cripto
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-22	USD	ARS	1509.500000000000000000	mayorista
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-22	UVA	ARS	2128.880000000000000000	uva
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-23	USD	ARS	1510.000000000000000000	oficial
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-23	USD	ARS	1545.000000000000000000	blue
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-23	USD	ARS	1533.500000000000000000	mep
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-23	USD	ARS	1596.449999999999800000	ccl
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-23	USD	ARS	1591.530000000000000000	cripto
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-23	USD	ARS	1510.500000000000000000	mayorista
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-23	UVA	ARS	2130.080000000000000000	uva
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-24	USD	ARS	1510.000000000000000000	oficial
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-24	USD	ARS	1550.000000000000000000	blue
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-24	USD	ARS	1540.250000000000000000	mep
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-24	USD	ARS	1606.449999999999800000	ccl
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-24	USD	ARS	1602.510000000000000000	cripto
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-24	USD	ARS	1511.500000000000000000	mayorista
313c86c6-73bd-42b6-ae57-d040c6b77521	2026-09-24	UVA	ARS	2131.280000000000000000	uva
\.


--
-- Data for Name: instrument; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.instrument (id, ledger_id, symbol, name, kind, quote_currency, decimals, ratio, underlying_symbol, archived_at, created_at, quote_size) FROM stdin;
\.


--
-- Data for Name: ledger; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ledger (id, name, registry_currency, measurement_currency, default_fx_source, created_at, archived_at) FROM stdin;
313c86c6-73bd-42b6-ae57-d040c6b77521	Personal	ARS	USD	mep	2026-09-15 16:18:23.612495+00	\N
\.


--
-- Data for Name: ledger_invite; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ledger_invite (code, ledger_id, role, created_by, created_at, expires_at, used_by, used_at) FROM stdin;
\.


--
-- Data for Name: ledger_member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ledger_member (ledger_id, user_id, role, joined_at) FROM stdin;
313c86c6-73bd-42b6-ae57-d040c6b77521	3999a016-1304-4a55-84e3-0201bff58969	owner	2026-09-15 16:18:23.612495+00
\.


--
-- Data for Name: portfolio; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.portfolio (id, ledger_id, name, fx_source, archived_at, created_at) FROM stdin;
3ca478d4-9ee7-4492-b604-fa5ef4a14c6e	313c86c6-73bd-42b6-ae57-d040c6b77521	Macro	\N	\N	2026-09-18 17:50:15.417524+00
cb7ed4bf-334d-4a06-a839-6ed700112af1	313c86c6-73bd-42b6-ae57-d040c6b77521	Balanz	\N	\N	2026-09-18 19:41:52.396251+00
4c1cc7c6-43fb-46b5-8007-588eebe186b8	313c86c6-73bd-42b6-ae57-d040c6b77521	Santander	\N	\N	2026-09-19 13:28:57.682027+00
\.


--
-- Data for Name: portfolio_account; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.portfolio_account (portfolio_id, account_id, ledger_id, added_at) FROM stdin;
\.


--
-- Data for Name: price; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price (instrument_id, ledger_id, on_date, price, currency, source) FROM stdin;
\.


--
-- Data for Name: scheduled_event; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scheduled_event (id, ledger_id, kind, description, category_id, account_id, amount, currency, frequency, next_on, ends_on, archived_at, counter_account_id, month_end) FROM stdin;
c0cdd731-2300-44fe-bac1-627f56fc32e7	313c86c6-73bd-42b6-ae57-d040c6b77521	recurring	Servicios	f0b5a911-7214-44f8-9c8e-64c24ba78626	c3f72011-ab5c-4bd4-8f5b-edb744286b51	2000.000000000000000000	ARS	monthly	2026-10-18	\N	\N	\N	f
8ee48bde-8a48-4a1a-afe8-466b5fc337e8	313c86c6-73bd-42b6-ae57-d040c6b77521	recurring	Servicios	f0b5a911-7214-44f8-9c8e-64c24ba78626	c3f72011-ab5c-4bd4-8f5b-edb744286b51	\N	ARS	monthly	2026-10-18	\N	\N	\N	f
1eea3838-b804-4b5f-a53e-f6438cfedcdb	313c86c6-73bd-42b6-ae57-d040c6b77521	recurring	Gastos variables	4c091b1f-0d84-4d9f-89a0-4c92540367b9	c3f72011-ab5c-4bd4-8f5b-edb744286b51	20000.000000000000000000	ARS	monthly	2026-10-18	\N	\N	\N	f
5ea5a48c-73fc-4e6a-993b-18f76fc16f27	313c86c6-73bd-42b6-ae57-d040c6b77521	recurring	Gastos variables	4c091b1f-0d84-4d9f-89a0-4c92540367b9	c3f72011-ab5c-4bd4-8f5b-edb744286b51	2500.000000000000000000	ARS	bimonthly	2026-11-18	\N	\N	\N	f
39a25d66-a83e-4e55-9d2e-ab29ade9f318	313c86c6-73bd-42b6-ae57-d040c6b77521	maturity	Vence Plazo fijo 90 días	\N	2288db15-b76f-4c4b-8998-3e48a6815094	19000.000000000000000000	ARS	\N	2026-09-30	\N	2026-09-18 19:33:04.495871+00	c3f72011-ab5c-4bd4-8f5b-edb744286b51	f
f727246c-af8d-4bea-9b87-893cbd55c293	313c86c6-73bd-42b6-ae57-d040c6b77521	recurring	Servicios	f0b5a911-7214-44f8-9c8e-64c24ba78626	c3f72011-ab5c-4bd4-8f5b-edb744286b51	800.000000000000000000	ARS	monthly	2026-10-31	\N	\N	\N	t
bd70611e-ce06-4e0d-ab99-300ce472d433	313c86c6-73bd-42b6-ae57-d040c6b77521	recurring	Servicios	f0b5a911-7214-44f8-9c8e-64c24ba78626	c3f72011-ab5c-4bd4-8f5b-edb744286b51	2000.000000000000000000	ARS	monthly	2026-10-19	\N	\N	\N	f
\.


--
-- Data for Name: transaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transaction (id, ledger_id, occurred_on, description, kind, created_by, created_at, updated_at, scheduled_event_id, installments, cross_ref) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2026-09-15 16:07:42
20211116045059	2026-09-15 16:07:42
20211116050929	2026-09-15 16:07:42
20211116051442	2026-09-15 16:07:42
20211116212300	2026-09-15 16:07:42
20211116213355	2026-09-15 16:07:42
20211116213934	2026-09-15 16:07:42
20211116214523	2026-09-15 16:07:42
20211122062447	2026-09-15 16:07:42
20211124070109	2026-09-15 16:07:42
20211202204204	2026-09-15 16:07:42
20211202204605	2026-09-15 16:07:42
20211210212804	2026-09-15 16:07:42
20211228014915	2026-09-15 16:07:42
20220107221237	2026-09-15 16:07:42
20220228202821	2026-09-15 16:07:42
20220312004840	2026-09-15 16:07:42
20220603231003	2026-09-15 16:07:42
20220603232444	2026-09-15 16:07:42
20220615214548	2026-09-15 16:07:42
20220712093339	2026-09-15 16:07:42
20220908172859	2026-09-15 16:07:42
20220916233421	2026-09-15 16:07:42
20230119133233	2026-09-15 16:07:42
20230128025114	2026-09-15 16:07:42
20230128025212	2026-09-15 16:07:42
20230227211149	2026-09-15 16:07:42
20230228184745	2026-09-15 16:07:42
20230308225145	2026-09-15 16:07:42
20230328144023	2026-09-15 16:07:42
20231018144023	2026-09-15 16:07:42
20231204144023	2026-09-15 16:07:42
20231204144024	2026-09-15 16:07:42
20231204144025	2026-09-15 16:07:42
20240108234812	2026-09-15 16:07:42
20240109165339	2026-09-15 16:07:42
20240227174441	2026-09-15 16:07:42
20240311171622	2026-09-15 16:07:42
20240321100241	2026-09-15 16:07:42
20240401105812	2026-09-15 16:07:42
20240418121054	2026-09-15 16:07:42
20240523004032	2026-09-15 16:07:42
20240618124746	2026-09-15 16:07:42
20240801235015	2026-09-15 16:07:42
20240805133720	2026-09-15 16:07:42
20240827160934	2026-09-15 16:07:42
20240919163303	2026-09-15 16:07:42
20240919163305	2026-09-15 16:07:42
20241019105805	2026-09-15 16:07:42
20241030150047	2026-09-15 16:07:42
20241108114728	2026-09-15 16:07:42
20241121104152	2026-09-15 16:07:42
20241130184212	2026-09-15 16:07:42
20241220035512	2026-09-15 16:07:42
20241220123912	2026-09-15 16:07:42
20241224161212	2026-09-15 16:07:42
20250107150512	2026-09-15 16:07:42
20250110162412	2026-09-15 16:07:42
20250123174212	2026-09-15 16:07:42
20250128220012	2026-09-15 16:07:42
20250506224012	2026-09-15 16:07:42
20250523164012	2026-09-15 16:07:42
20250714121412	2026-09-15 16:07:42
20250905041441	2026-09-15 16:07:42
20251103001201	2026-09-15 16:07:42
20251120212548	2026-09-15 16:07:42
20251120215549	2026-09-15 16:07:42
20260218120000	2026-09-15 16:07:42
20260326120000	2026-09-15 16:07:42
20260514120000	2026-09-15 16:07:42
20260527120000	2026-09-15 16:07:42
20260528120000	2026-09-15 16:07:42
20260603120000	2026-09-15 16:07:42
20260605120000	2026-09-15 16:07:42
20260606110000	2026-09-15 16:07:42
20260616120000	2026-09-15 16:07:42
20260624120000	2026-09-15 16:07:42
20260626120000	2026-09-15 16:07:42
20260706120000	2026-09-15 16:07:42
20260707120000	2026-09-15 16:07:42
20260709120000	2026-09-15 16:07:42
20260714120000	2026-09-15 16:07:42
20260827120000	2026-09-18 15:55:22
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at, action_filter, selected_columns) FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type, versioning_status) FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_analytics (name, type, format, created_at, updated_at, id, deleted_at) FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_vectors (id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-09-15 15:04:53.574707
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-09-15 15:04:53.617406
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-09-15 15:04:53.62558
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-09-15 15:04:53.658428
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-09-15 15:04:53.678823
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-09-15 15:04:53.686389
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-09-15 15:04:53.695136
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-09-15 15:04:53.702995
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-09-15 15:04:53.710349
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-09-15 15:04:53.718066
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-09-15 15:04:53.725979
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-09-15 15:04:53.734198
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-09-15 15:04:53.742361
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-09-15 15:04:53.750002
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-09-15 15:04:53.758129
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-09-15 15:04:53.788715
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-09-15 15:04:53.796335
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-09-15 15:04:53.804827
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-09-15 15:04:53.812955
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-09-15 15:04:53.822646
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-09-15 15:04:53.831135
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-09-15 15:04:53.840651
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-09-15 15:04:53.858023
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-09-15 15:04:53.873093
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-09-15 15:04:53.880919
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-09-15 15:04:53.888783
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-09-15 15:04:53.89646
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-09-15 15:04:53.903752
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-09-15 15:04:53.911163
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-09-15 15:04:53.918207
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-09-15 15:04:53.92545
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-09-15 15:04:53.932607
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-09-15 15:04:53.939696
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-09-15 15:04:53.947986
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-09-15 15:04:53.955802
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-09-15 15:04:53.963387
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-09-15 15:04:53.970428
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-09-15 15:04:53.978368
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-09-15 15:04:53.986364
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-09-15 15:04:54.001241
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-09-15 15:04:54.009237
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-09-15 15:04:54.016315
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-09-15 15:04:54.023304
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-09-15 15:04:54.030757
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-09-15 15:04:54.037837
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-09-15 15:04:54.045802
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-09-15 15:04:54.061315
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-09-15 15:04:54.06897
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-09-15 15:04:54.076072
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-09-15 15:04:54.095133
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-09-15 15:04:54.102967
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-09-15 15:04:54.129142
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-09-15 15:04:54.131726
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-09-15 15:04:54.143365
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-09-15 15:04:54.147829
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-09-15 15:04:54.150545
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-09-15 15:04:54.159035
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-09-15 15:04:54.167981
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-09-15 15:04:54.175648
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-09-15 15:04:54.18365
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-09-15 15:04:54.191651
61	mark-filename-immutable	fe0096517ae9d60aaec1d110172ba9036dc66bb7	2026-09-15 15:04:54.20616
62	object-versioning-core	0b855f00ff3be0bfca91efee02a9858912491a9a	2026-09-15 15:04:54.214944
63	fix-search-name-relative-to-prefix	c7485e417624f795ce8bb2da21927f48e088904d	2026-09-15 15:04:54.227246
64	fix-search-by-timestamp-sqli	0af424ecd388a39bb1645184b222185a12149675	2026-09-15 15:04:54.236266
65	objects-key-version-index	603c1c55658e982d35839001e2c2b59a50703904	2026-09-15 15:04:54.295678
66	objects-current-version-index	191466c93aa2c46a00e36505577c5fcab8d7cb4b	2026-09-15 15:04:54.306593
67	objects-null-version-index	15bfe8c35b66642b6c78ba60060fa8793bd2207a	2026-09-15 15:04:54.317267
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata, archived_at, is_delete_marker, is_versioned) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata, metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.vector_indexes (id, name, bucket_id, data_type, dimension, distance_metric, metadata_configuration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: supabase_migrations; Owner: -
--

COPY supabase_migrations.schema_migrations (version, statements, name) FROM stdin;
20260915100000	{"-- kipo · esquema base\n-- Deriva de docs/modelo-de-datos.md §2. Si algo acá contradice a docs/ADRs.md, ganan los ADRs.\n\n-- ---------------------------------------------------------------------------\n-- Libro y miembros — ADR-003\n-- ---------------------------------------------------------------------------\n\ncreate table ledger (\n  id                   uuid primary key default gen_random_uuid(),\n  name                 text not null,\n  registry_currency    text not null default 'ARS',\n  measurement_currency text not null default 'USD',   -- ADR-009\n  default_fx_source    text not null default 'mep',   -- ADR-011\n  created_at           timestamptz not null default now()\n)","comment on table ledger is\n  'El libro. ADR-003: toda fila del dominio le pertenece a uno, nunca a un usuario directo. '\n  'Hoy cada usuario tiene exactamente uno y NO aparece en la interfaz.'","create table ledger_member (\n  ledger_id uuid not null references ledger(id) on delete cascade,\n  user_id   uuid not null references auth.users(id) on delete cascade,\n  role      text not null default 'owner' check (role in ('owner','member')),\n  joined_at timestamptz not null default now(),\n  primary key (ledger_id, user_id)\n)","comment on table ledger_member is\n  'ADR-002 mantiene a los usuarios aislados. El día que eso cambie, compartir es un INSERT acá '\n  'y ninguna politica de RLS se toca.'","-- ---------------------------------------------------------------------------\n-- Activos y cotizaciones\n-- ---------------------------------------------------------------------------\n\ncreate table instrument (\n  id                uuid primary key default gen_random_uuid(),\n  ledger_id         uuid not null references ledger(id) on delete cascade,\n  symbol            text not null,\n  name              text not null,\n  kind              text not null check (kind in\n                      ('cedear','crypto','stock','etf','fund','bond','other')),\n  quote_currency    text not null,\n  decimals          int  not null default 2,\n  -- OD-17: un CEDEAR representa una fraccion de la accion de afuera. Previsto, sin usar.\n  ratio             numeric(38,18),\n  underlying_symbol text,\n  archived_at       timestamptz,\n  created_at        timestamptz not null default now(),\n  unique (ledger_id, symbol),\n  unique (id, ledger_id)          -- habilita las claves foraneas compuestas de abajo\n)","create table price (\n  instrument_id uuid not null references instrument(id) on delete cascade,\n  ledger_id     uuid not null references ledger(id) on delete cascade,\n  on_date       date not null,\n  price         numeric(38,18) not null check (price >= 0),\n  currency      text not null,\n  source        text not null default 'manual',\n  primary key (instrument_id, on_date, source)\n)","-- ADR-011: la misma fecha puede tener varias cotizaciones validas a la vez, porque lo son.\ncreate table fx_rate (\n  ledger_id uuid not null references ledger(id) on delete cascade,\n  on_date   date not null,\n  base      text not null,\n  quote     text not null,\n  rate      numeric(38,18) not null check (rate > 0),\n  source    text not null check (source in ('oficial','mep','blue','ccl','manual')),\n  primary key (ledger_id, on_date, base, quote, source)\n)","-- ---------------------------------------------------------------------------\n-- Cuentas — ADR-012, el corazon del modelo\n-- ---------------------------------------------------------------------------\n\ncreate table account (\n  id              uuid primary key default gen_random_uuid(),\n  ledger_id       uuid not null references ledger(id) on delete cascade,\n  name            text not null,\n\n  kind            text not null check (kind in ('asset','liability')),\n\n  -- LAS TRES FAMILIAS DE ADR-012: como se responde \\"cuanto vale hoy\\"\n  --   balance : lo que dice el saldo        (efectivo, banco, remunerada, tarjeta)\n  --   accrual : saldo + lo devengado        (plazo fijo)        -- ADR-014\n  --   market  : unidades x precio           (CEDEARs, cripto)\n  valuation       text not null check (valuation in ('balance','accrual','market')),\n\n  unit            text not null,\n  instrument_id   uuid,\n\n  is_spendable    boolean not null default true,\n  fx_source       text check (fx_source in ('oficial','mep','blue','ccl','manual')),\n\n  matures_on      date,                    -- solo accrual\n  expected_amount numeric(38,18),          -- solo accrual\n\n  institution     text,\n  archived_at     timestamptz,\n  created_at      timestamptz not null default now(),\n\n  constraint market_needs_instrument\n    check ((valuation = 'market') = (instrument_id is not null)),\n  constraint accrual_needs_maturity\n    check (valuation <> 'accrual' or matures_on is not null),\n  constraint instrument_same_ledger\n    foreign key (instrument_id, ledger_id) references instrument(id, ledger_id),\n  unique (id, ledger_id)\n)","comment on column account.valuation is\n  'ADR-012: las cuentas se clasifican por COMO SE VALUAN, no por como las llama el banco. '\n  'Por eso una cuenta remunerada es balance (ADR-013) y no una inversion.'","comment on column account.is_spendable is\n  'Responde \\"cuanto tengo disponible\\" del punto 8 del brief: efectivo y remunerada si, '\n  'plazo fijo y posiciones no.'","-- ---------------------------------------------------------------------------\n-- Categorias\n-- ---------------------------------------------------------------------------\n\ncreate table category (\n  id          uuid primary key default gen_random_uuid(),\n  ledger_id   uuid not null references ledger(id) on delete cascade,\n  parent_id   uuid references category(id),\n  name        text not null,\n  kind        text not null check (kind in ('income','expense')),\n  is_system   boolean not null default false,   -- 'Ajustes' (ADR-005), 'Intereses' (ADR-013)\n  sort_order  int not null default 0,\n  archived_at timestamptz,\n  created_at  timestamptz not null default now(),\n  unique (id, ledger_id)\n)","comment on table category is\n  'ADR-012: \\"Ahorros\\" e \\"Inversiones\\" NO son categorias. Son cuentas. Sembrarlas aca seria '\n  'reintroducir el error 1 del analisis, que restaba el ahorro del resultado del mes.'","-- ---------------------------------------------------------------------------\n-- Transacciones y lineas — ADR-001\n-- ---------------------------------------------------------------------------\n\ncreate table transaction (\n  id          uuid primary key default gen_random_uuid(),\n  ledger_id   uuid not null references ledger(id) on delete cascade,\n  occurred_on date not null,\n  description text,\n  -- la INTENCION con la que se cargo, para reabrir el formulario correcto al editar.\n  -- las entries son la verdad; esto es una pista de interfaz.\n  kind        text not null check (kind in\n                ('expense','income','transfer','exchange','trade','adjustment')),\n  created_by  uuid not null references auth.users(id),\n  created_at  timestamptz not null default now(),\n  updated_at  timestamptz not null default now(),\n  unique (id, ledger_id)\n)","create table entry (\n  id             uuid primary key default gen_random_uuid(),\n  transaction_id uuid not null,\n  ledger_id      uuid not null references ledger(id) on delete cascade,\n\n  account_id     uuid,\n  category_id    uuid,\n\n  amount         numeric(38,18) not null,   -- con signo, desde la perspectiva del patrimonio\n  unit           text not null,             -- 'ARS','USD','BTC','AAPL-CEDEAR'\n\n  constraint entry_targets_exactly_one\n    check (num_nonnulls(account_id, category_id) = 1),\n\n  -- claves foraneas compuestas: la base garantiza que todo pertenece al MISMO libro.\n  -- con account_id/category_id en null no se aplica, que es justo lo que queremos.\n  constraint entry_tx_same_ledger\n    foreign key (transaction_id, ledger_id) references transaction(id, ledger_id) on delete cascade,\n  constraint entry_account_same_ledger\n    foreign key (account_id, ledger_id) references account(id, ledger_id),\n  constraint entry_category_same_ledger\n    foreign key (category_id, ledger_id) references category(id, ledger_id)\n)","comment on column entry.amount is\n  'El signo es SIEMPRE desde la perspectiva del patrimonio. En un pasivo, positivo = debes MENOS. '\n  'En una categoria de ingreso, negativo. Es lo que hace que la suma de cero y que '\n  'Resultado del mes = -SUM(entries de categorias).'","create index entry_ledger_account_idx  on entry (ledger_id, account_id)","create index entry_ledger_category_idx on entry (ledger_id, category_id)","create index entry_transaction_idx     on entry (transaction_id)","create index transaction_ledger_date_idx on transaction (ledger_id, occurred_on desc)","-- ---------------------------------------------------------------------------\n-- Presupuestos y eventos futuros — etapas 2 y 3, previstos desde el dia uno\n-- ---------------------------------------------------------------------------\n\ncreate table budget (\n  id          uuid primary key default gen_random_uuid(),\n  ledger_id   uuid not null references ledger(id) on delete cascade,\n  category_id uuid not null,\n  period      date not null,\n  amount      numeric(38,18) not null check (amount >= 0),\n  currency    text not null,\n  unique (ledger_id, category_id, period),\n  constraint budget_category_same_ledger\n    foreign key (category_id, ledger_id) references category(id, ledger_id)\n)","-- ADR-016: un gasto recurrente y el vencimiento de un plazo fijo son el mismo objeto.\ncreate table scheduled_event (\n  id          uuid primary key default gen_random_uuid(),\n  ledger_id   uuid not null references ledger(id) on delete cascade,\n  kind        text not null check (kind in ('recurring','maturity')),\n  description text not null,\n  category_id uuid,\n  account_id  uuid,\n  amount      numeric(38,18),          -- null si el importe cambia cada periodo\n  currency    text not null,\n  frequency   text check (frequency in\n                ('weekly','monthly','bimonthly','quarterly','biannual','yearly')),\n  next_on     date not null,\n  ends_on     date,\n  archived_at timestamptz,\n  constraint recurring_needs_frequency\n    check (kind <> 'recurring' or frequency is not null),\n  constraint sched_category_same_ledger\n    foreign key (category_id, ledger_id) references category(id, ledger_id),\n  constraint sched_account_same_ledger\n    foreign key (account_id, ledger_id) references account(id, ledger_id)\n)"}	schema
20260915100100	{"-- kipo · invariantes del modelo\n-- ADR-010 hecha codigo. Lo que esta aca es lo que hace IMPOSIBLE registrar algo inconsistente.\n\n-- ---------------------------------------------------------------------------\n-- La invariante central — ADR-010\n--   suma cero por unidad, salvo en transacciones de intercambio, donde las dos\n--   unidades quedan relacionadas por el cociente de sus montos.\n-- ---------------------------------------------------------------------------\n\ncreate or replace function check_transaction_balances() returns trigger\nlanguage plpgsql\nset search_path = public, pg_temp\nas $$\ndeclare\n  v_tx    uuid := coalesce(new.transaction_id, old.transaction_id);\n  v_units int;\n  v_bad   text;\nbegin\n  select count(*) into v_units\n    from (select unit from entry where transaction_id = v_tx group by unit) t;\n\n  -- la transaccion fue borrada entera: nada que validar\n  if v_units = 0 then\n    return null;\n  end if;\n\n  if v_units = 1 then\n    select unit into v_bad\n      from entry where transaction_id = v_tx\n     group by unit having sum(amount) <> 0;\n    if v_bad is not null then\n      raise exception 'La transaccion % no balancea en %', v_tx, v_bad\n        using errcode = 'check_violation';\n    end if;\n\n  elsif v_units = 2 then\n    -- intercambio (compra de dolares, compra/venta de un activo).\n    -- el tipo de cambio o el precio unitario es el COCIENTE y NO SE GUARDA.\n    -- lo unico verificable sin una cotizacion externa es que ninguna pata sea neutra.\n    if exists (\n      select 1 from entry where transaction_id = v_tx\n       group by unit having sum(amount) = 0\n    ) then\n      raise exception\n        'En un intercambio ninguna unidad puede tener saldo neto cero (transaccion %)', v_tx\n        using errcode = 'check_violation';\n    end if;\n\n  else\n    -- ADR-010 dice explicitamente RECHAZAR, no suponer que no pasa.\n    raise exception\n      'Una transaccion no puede mezclar mas de dos unidades (transaccion %, % unidades)',\n      v_tx, v_units\n      using errcode = 'check_violation';\n  end if;\n\n  return null;\nend $$","-- DEFERRABLE INITIALLY DEFERRED es lo que permite insertar las lineas de a una:\n-- la validacion corre recien al confirmar, cuando ya estan todas.\ncreate constraint trigger transaction_balances\n  after insert or update or delete on entry\n  deferrable initially deferred\n  for each row execute function check_transaction_balances()","-- ---------------------------------------------------------------------------\n-- La unidad de la linea debe coincidir con la de su cuenta.\n-- entry.unit esta desnormalizado a proposito (hace barata la validacion de arriba);\n-- este trigger es lo que evita que mienta.\n-- ---------------------------------------------------------------------------\n\ncreate or replace function check_entry_unit() returns trigger\nlanguage plpgsql\nset search_path = public, pg_temp\nas $$\ndeclare v_unit text;\nbegin\n  if new.account_id is not null then\n    select unit into v_unit from account where id = new.account_id;\n    if v_unit is distinct from new.unit then\n      raise exception 'La linea usa la unidad % pero la cuenta tiene %', new.unit, v_unit\n        using errcode = 'check_violation';\n    end if;\n  end if;\n  return new;\nend $$","create trigger entry_unit_matches_account\n  before insert or update on entry\n  for each row execute function check_entry_unit()","-- ---------------------------------------------------------------------------\n-- Dos niveles de categoria, no tres.\n-- ---------------------------------------------------------------------------\n\ncreate or replace function check_category_depth() returns trigger\nlanguage plpgsql\nset search_path = public, pg_temp\nas $$\nbegin\n  if new.parent_id is not null and exists (\n    select 1 from category where id = new.parent_id and parent_id is not null\n  ) then\n    raise exception 'Solo se admiten dos niveles de categoria'\n      using errcode = 'check_violation';\n  end if;\n  if new.parent_id = new.id then\n    raise exception 'Una categoria no puede ser su propio padre'\n      using errcode = 'check_violation';\n  end if;\n  return new;\nend $$","create trigger category_two_levels\n  before insert or update on category\n  for each row execute function check_category_depth()","-- ---------------------------------------------------------------------------\n-- updated_at\n-- ---------------------------------------------------------------------------\n\ncreate or replace function touch_updated_at() returns trigger\nlanguage plpgsql set search_path = public, pg_temp as $$\nbegin new.updated_at := now(); return new; end $$","create trigger transaction_touch\n  before update on transaction\n  for each row execute function touch_updated_at()","-- ---------------------------------------------------------------------------\n-- Saldos — modelo-de-datos.md §6\n-- ---------------------------------------------------------------------------\n\ncreate view account_balance as\n  select a.id            as account_id,\n         a.ledger_id,\n         a.name,\n         a.kind,\n         a.valuation,\n         a.unit,\n         a.is_spendable,\n         coalesce(sum(e.amount), 0) as balance\n    from account a\n    left join entry e on e.account_id = a.id\n   where a.archived_at is null\n   group by a.id, a.ledger_id, a.name, a.kind, a.valuation, a.unit, a.is_spendable","comment on view account_balance is\n  'Saldo en la UNIDAD de la cuenta. Para valuation=market son unidades, no plata: '\n  'convertirlas a valor requiere price, y a moneda de medicion requiere fx_rate '\n  'con la fx_source de la cuenta (ADR-011).'"}	invariants
20260915100200	{"-- kipo · aislamiento entre usuarios — ADR-002, ADR-003, ADR-007\n-- El aislamiento vive EN LA BASE, no en el codigo de la aplicacion.\n-- Un bug del frontend no puede mostrarle a alguien las finanzas de otro.\n\n-- SECURITY DEFINER a proposito: la funcion corre como su duena (postgres), que no esta\n-- sujeta a RLS, y por eso leer ledger_member aca NO dispara la politica de ledger_member.\n-- Sin esto habria recursion infinita.\ncreate or replace function my_ledgers() returns setof uuid\nlanguage sql\nstable\nsecurity definer\nset search_path = public, pg_temp\nas $$\n  select ledger_id from ledger_member where user_id = auth.uid()\n$$","revoke all on function my_ledgers() from public","grant execute on function my_ledgers() to authenticated","-- Todas las tablas del dominio llevan ledger_id, asi que la politica es LA MISMA en\n-- todas y no necesita joins. La lista es explicita para que sea auditable de un vistazo.\ndo $$\ndeclare t text;\nbegin\n  foreach t in array array[\n    'account','category','instrument','price','fx_rate',\n    'transaction','entry','budget','scheduled_event'\n  ] loop\n    execute format('alter table %I enable row level security', t);\n    execute format('alter table %I force row level security', t);\n    execute format($p$\n      create policy %1$I_member_rw on %1$I for all to authenticated\n        using      (ledger_id in (select my_ledgers()))\n        with check (ledger_id in (select my_ledgers()))\n    $p$, t);\n  end loop;\nend $$","-- ledger y ledger_member no tienen columna ledger_id: van aparte.\nalter table ledger enable row level security","alter table ledger force row level security","create policy ledger_member_rw on ledger for all to authenticated\n  using      (id in (select my_ledgers()))\n  with check (id in (select my_ledgers()))","alter table ledger_member enable row level security","alter table ledger_member force row level security","create policy ledger_member_self on ledger_member for all to authenticated\n  using      (ledger_id in (select my_ledgers()))\n  with check (ledger_id in (select my_ledgers()))","-- La vista hereda el RLS de sus tablas base (security_invoker).\nalter view account_balance set (security_invoker = on)"}	rls
20260915100300	{"-- kipo · alta de usuario\n-- ADR-003: al registrarse, cada usuario obtiene su libro automaticamente.\n-- Si el usuario llega a ver la palabra \\"libro\\" en la interfaz, esta decision fallo.\n\ncreate or replace function handle_new_user() returns trigger\nlanguage plpgsql\nsecurity definer\nset search_path = public, pg_temp\nas $$\ndeclare\n  v_ledger uuid;\n  v_parent uuid;\nbegin\n  insert into ledger (name) values ('Personal') returning id into v_ledger;\n  insert into ledger_member (ledger_id, user_id, role) values (v_ledger, new.id, 'owner');\n\n  -- ------------------------------------------------------------------\n  -- Categorias de ingreso\n  -- ------------------------------------------------------------------\n  insert into category (ledger_id, name, kind, is_system, sort_order) values\n    (v_ledger, 'Sueldo',         'income', false, 10),\n    -- ADR-013 (interes de cuenta remunerada) y ADR-014 (vencimiento de plazo fijo)\n    -- dependen de que esta categoria exista: por eso is_system.\n    (v_ledger, 'Intereses',      'income', true,  20),\n    (v_ledger, 'Dividendos',     'income', false, 30),\n    (v_ledger, 'Otros ingresos', 'income', false, 40);\n\n  -- ------------------------------------------------------------------\n  -- Categorias de gasto\n  -- ------------------------------------------------------------------\n  insert into category (ledger_id, name, kind, sort_order)\n    values (v_ledger, 'Gastos fijos', 'expense', 10) returning id into v_parent;\n  insert into category (ledger_id, parent_id, name, kind, sort_order) values\n    (v_ledger, v_parent, 'Alquiler / Expensas', 'expense', 11),\n    (v_ledger, v_parent, 'Servicios',           'expense', 12),\n    (v_ledger, v_parent, 'Seguros',             'expense', 13),\n    (v_ledger, v_parent, 'Impuestos',           'expense', 14),\n    (v_ledger, v_parent, 'Suscripciones',       'expense', 15);\n\n  insert into category (ledger_id, name, kind, sort_order)\n    values (v_ledger, 'Gastos variables', 'expense', 20) returning id into v_parent;\n  insert into category (ledger_id, parent_id, name, kind, sort_order) values\n    (v_ledger, v_parent, 'Supermercado',    'expense', 21),\n    (v_ledger, v_parent, 'Restaurantes',    'expense', 22),\n    (v_ledger, v_parent, 'Transporte',      'expense', 23),\n    (v_ledger, v_parent, 'Entretenimiento', 'expense', 24),\n    (v_ledger, v_parent, 'Compras',         'expense', 25),\n    (v_ledger, v_parent, 'Salud',           'expense', 26);\n\n  insert into category (ledger_id, name, kind, sort_order)\n    values (v_ledger, 'Caridad', 'expense', 30) returning id into v_parent;\n  insert into category (ledger_id, parent_id, name, kind, sort_order) values\n    (v_ledger, v_parent, 'Donaciones', 'expense', 31);\n\n  -- ADR-005: la valvula de escape de los saldos aproximados. Si esta categoria crece\n  -- mes a mes, es senal de que algo se esta cargando mal — la deriva queda MEDIDA.\n  insert into category (ledger_id, name, kind, is_system, sort_order)\n    values (v_ledger, 'Ajustes', 'expense', true, 90);\n\n  -- ------------------------------------------------------------------\n  -- NO se siembran \\"Ahorros\\" ni \\"Inversiones\\" como categorias.\n  -- ADR-012: son CUENTAS. Sembrarlas aca reintroduciria el error 1 del analisis,\n  -- que restaba el ahorro del resultado del mes y castigaba ahorrar.\n  -- ------------------------------------------------------------------\n\n  -- Una cuenta minima para que el primer gasto se pueda cargar sin configurar nada:\n  -- el MVP se mide en que registrar un gasto lleve menos de diez segundos.\n  insert into account (ledger_id, name, kind, valuation, unit, is_spendable)\n    values (v_ledger, 'Efectivo ARS', 'asset', 'balance', 'ARS', true);\n\n  return new;\nend $$","create trigger on_auth_user_created\n  after insert on auth.users\n  for each row execute function handle_new_user()"}	bootstrap
20260915110000	{"-- kipo · escritura atomica de movimientos\n--\n-- Problema: registrar un movimiento significa insertar en 'transaction' y en 'entry'.\n-- Desde el navegador eso son dos llamadas, y si la segunda falla queda un movimiento\n-- huerfano. Ademas son dos viajes de red en un flujo que debe cerrarse en 10 segundos.\n--\n-- Esta funcion hace las dos cosas en UNA transaccion de base y UN viaje.\n\n-- El libro del usuario. ADR-003 dice que el libro NO existe para la interfaz:\n-- esta funcion es lo que lo hace cierto, porque el cliente nunca tiene que nombrarlo.\ncreate or replace function my_ledger() returns uuid\nlanguage sql\nstable\nset search_path = public, pg_temp\nas $$ select * from my_ledgers() limit 1 $$","grant execute on function my_ledger() to authenticated","-- Con esto el cliente jamas envia ledger_id: lo pone la base y RLS lo verifica.\n-- El dia que ADR-002 cambie y haya libros compartidos, el cliente empezara a enviarlo\n-- explicitamente y estos defaults se quitan.\nalter table account         alter column ledger_id set default my_ledger()","alter table category        alter column ledger_id set default my_ledger()","alter table instrument      alter column ledger_id set default my_ledger()","alter table price           alter column ledger_id set default my_ledger()","alter table fx_rate         alter column ledger_id set default my_ledger()","alter table transaction     alter column ledger_id set default my_ledger()","alter table entry           alter column ledger_id set default my_ledger()","alter table budget          alter column ledger_id set default my_ledger()","alter table scheduled_event alter column ledger_id set default my_ledger()","-- SECURITY INVOKER (el default, explicito a proposito): la funcion corre con los\n-- permisos de QUIEN LA LLAMA, asi que RLS sigue aplicando. Con SECURITY DEFINER\n-- seria un agujero que saltearia todo el aislamiento de ADR-002.\ncreate or replace function create_transaction(\n  p_occurred_on date,\n  p_kind        text,\n  p_entries     jsonb,      -- [{account_id|category_id, amount, unit}, ...]\n  p_description text default null\n) returns uuid\nlanguage plpgsql\nsecurity invoker\nset search_path = public, pg_temp\nas $$\ndeclare\n  v_ledger uuid := my_ledger();\n  v_tx     uuid;\n  v_n      int;\nbegin\n  if v_ledger is null then\n    raise exception 'El usuario no pertenece a ningun libro';\n  end if;\n\n  v_n := jsonb_array_length(p_entries);\n  if v_n is null or v_n < 2 then\n    raise exception 'Un movimiento necesita al menos dos lineas (recibio %)', coalesce(v_n, 0);\n  end if;\n\n  insert into transaction (ledger_id, occurred_on, description, kind, created_by)\n       values (v_ledger, p_occurred_on, nullif(trim(p_description), ''), p_kind, auth.uid())\n    returning id into v_tx;\n\n  insert into entry (transaction_id, ledger_id, account_id, category_id, amount, unit)\n  select v_tx,\n         v_ledger,\n         nullif(e->>'account_id', '')::uuid,\n         nullif(e->>'category_id', '')::uuid,\n         (e->>'amount')::numeric,\n         e->>'unit'\n    from jsonb_array_elements(p_entries) e;\n\n  -- Al salir de la funcion se confirma la transaccion de base y recien ahi dispara\n  -- el trigger diferido de ADR-010. Si no balancea, no queda NADA: ni el movimiento\n  -- ni las lineas. Esa es la atomicidad que se buscaba.\n  return v_tx;\nend $$","grant execute on function create_transaction(date, text, jsonb, text) to authenticated","comment on function create_transaction(date, text, jsonb, text) is\n  'Registra un movimiento con sus lineas en una sola transaccion de base. '\n  'SECURITY INVOKER: RLS sigue aplicando. Si las lineas no balancean segun ADR-010, '\n  'se revierte todo.'"}	rpc
20260915110100	{"-- kipo · vistas de lectura\n--\n-- Las claves foraneas de 'entry' hacia account/category son COMPUESTAS\n-- (account_id, ledger_id) -> account(id, ledger_id), porque asi la base garantiza\n-- que todo pertenece al mismo libro sin triggers. El costo es que el inferidor de\n-- relaciones de PostgREST puede no resolver el embebido automatico.\n--\n-- En vez de apostar a que lo resuelva, se expone la union ya hecha: un viaje,\n-- sin sintaxis de embebido, y el join lo hace la base que es donde es barato.\n\ncreate view entry_detail as\n  select e.id,\n         e.transaction_id,\n         e.ledger_id,\n         e.amount,\n         e.unit,\n         e.account_id,\n         a.name       as account_name,\n         a.kind       as account_kind,\n         a.valuation  as account_valuation,\n         e.category_id,\n         c.name       as category_name,\n         c.kind       as category_kind,\n         p.name       as category_parent,\n         t.occurred_on,\n         t.description,\n         t.kind       as tx_kind,\n         t.created_at\n    from entry e\n    join transaction t on t.id = e.transaction_id\n    left join account  a on a.id = e.account_id\n    left join category c on c.id = e.category_id\n    left join category p on p.id = c.parent_id","-- security_invoker: la vista se evalua con los permisos de quien consulta,\n-- asi que RLS de las tablas base sigue aplicando. Sin esto seria un agujero.\nalter view entry_detail set (security_invoker = on)","comment on view entry_detail is\n  'Lineas con el nombre de su cuenta o categoria y los datos de su movimiento. '\n  'Evita depender del embebido de PostgREST sobre claves foraneas compuestas.'"}	views
20260915120000	{"-- kipo · permisos explicitos del Data API\n--\n-- Pensada para tener DESACTIVADO \\"Automatically expose new tables\\".\n-- Con esa opcion activada, Supabase otorga privilegios a anon, authenticated y\n-- service_role sobre toda tabla nueva, y lo unico que separa a un desconocido de\n-- los datos es RLS. Un solo candado.\n--\n-- Aca hay DOS candados:\n--   1. 'anon' (sin autenticar) no tiene ningun privilegio: no llega ni a la tabla.\n--   2. 'authenticated' llega a la tabla, y ahi RLS decide que filas ve.\n--\n-- Para una app privada de tres personas, que un pedido sin autenticar ni siquiera\n-- alcance la tabla es gratis y elimina una clase entera de error.\n\n-- Por si el proyecto se creo con la exposicion automatica activada.\nrevoke all on all tables    in schema public from anon","revoke all on all sequences in schema public from anon","revoke all on all functions in schema public from anon","revoke usage on schema public from anon","-- Y que las tablas futuras tampoco lleguen a anon por defecto.\nalter default privileges in schema public revoke all on tables from anon","grant usage on schema public to authenticated","-- Las nueve tablas del dominio. Sin 'ledger' ni 'ledger_member' a proposito:\n-- el cliente nunca las consulta (ADR-003 dice que el libro no existe para la\n-- interfaz) y my_ledgers() las lee como SECURITY DEFINER, sin necesitar permisos\n-- de quien llama. Menos superficie.\ngrant select, insert, update, delete on\n  account, category, instrument, price, fx_rate,\n  transaction, entry, budget, scheduled_event\n  to authenticated","-- Las vistas son de lectura. Heredan RLS por security_invoker.\ngrant select on account_balance, entry_detail to authenticated","comment on schema public is\n  'anon no tiene privilegios: esta app es privada. Ver 20260915120000_grants.sql'"}	grants
20260915130000	{"-- Expone si la categoria es de sistema, para poder mostrar los AJUSTES separados\n-- de los gastos reales en el resumen del mes.\n--\n-- Un ajuste (ADR-005) resta del resultado igual que un gasto —esa plata se fue de\n-- verdad, aunque no sepamos en que— pero mezclarlo con \\"Gastos\\" miente sobre en que\n-- gastaste. Se muestra en su propia linea.\n\ndrop view if exists entry_detail","create view entry_detail as\n  select e.id,\n         e.transaction_id,\n         e.ledger_id,\n         e.amount,\n         e.unit,\n         e.account_id,\n         a.name       as account_name,\n         a.kind       as account_kind,\n         a.valuation  as account_valuation,\n         e.category_id,\n         c.name       as category_name,\n         c.kind       as category_kind,\n         c.is_system  as category_is_system,\n         p.name       as category_parent,\n         t.occurred_on,\n         t.description,\n         t.kind       as tx_kind,\n         t.created_at\n    from entry e\n    join transaction t on t.id = e.transaction_id\n    left join account  a on a.id = e.account_id\n    left join category c on c.id = e.category_id\n    left join category p on p.id = c.parent_id","alter view entry_detail set (security_invoker = on)","grant select on entry_detail to authenticated","comment on view entry_detail is\n  'Lineas con el nombre de su cuenta o categoria y los datos de su movimiento. '\n  'Evita depender del embebido de PostgREST sobre claves foraneas compuestas.'"}	entry_detail_is_system
20260916100000	{"-- Cuantos movimientos usan cada cuenta y cada categoria.\n--\n-- La base ya IMPIDE borrar algo con movimientos: la clave foranea de entry no\n-- tiene `on delete`, asi que salta foreign_key_violation. Pero la interfaz no\n-- puede enterarse recien al fallar: necesita saberlo ANTES para ofrecer \\"borrar\\"\n-- o \\"archivar\\" segun corresponda.\n\ndrop view if exists account_balance","create view account_balance as\n  select a.id           as account_id,\n         a.ledger_id,\n         a.name,\n         a.kind,\n         a.valuation,\n         a.unit,\n         a.is_spendable,\n         a.institution,\n         coalesce(sum(e.amount), 0) as balance,\n         count(e.id)                as movimientos\n    from account a\n    left join entry e on e.account_id = a.id\n   where a.archived_at is null\n   group by a.id","alter view account_balance set (security_invoker = on)","grant select on account_balance to authenticated","comment on view account_balance is\n  'Saldo en la UNIDAD de la cuenta, mas cuantos movimientos la usan. '\n  'Para valuation=market el saldo son unidades, no plata.'","create view category_usage as\n  select c.id  as category_id,\n         c.ledger_id,\n         c.name,\n         c.kind,\n         c.parent_id,\n         c.is_system,\n         c.sort_order,\n         count(e.id) as movimientos\n    from category c\n    left join entry e on e.category_id = c.id\n   where c.archived_at is null\n   group by c.id","alter view category_usage set (security_invoker = on)","grant select on category_usage to authenticated"}	uso
20260916110000	{"-- Gastos recurrentes y vencimientos — brief §10, sobre la tabla de ADR-016.\n--\n-- El brief es explicito: \\"no necesariamente quiero que el sistema ejecute pagos\n-- automaticamente; inicialmente alcanza con que recuerde y proyecte\\". Asi que el\n-- sistema NUNCA crea un movimiento solo: lo propone, y recien cuando el usuario\n-- confirma se registra y se adelanta la fecha.\n\n-- De que regla salio un movimiento. Sirve para dos cosas concretas:\n--   ver el historial de un gasto recurrente (\\"todos los pagos del seguro\\")\n--   saber si el periodo actual YA se registro, y no ofrecerlo dos veces\n-- Primero la unicidad del lado referenciado: sin ella, la clave foranea\n-- compuesta de abajo no tiene a que apuntar.\nalter table scheduled_event add constraint scheduled_event_id_ledger_uk\n  unique (id, ledger_id)","alter table transaction\n  add column scheduled_event_id uuid,\n  add constraint transaction_sched_same_ledger\n    foreign key (scheduled_event_id, ledger_id)\n    references scheduled_event(id, ledger_id) on delete set null","create index transaction_sched_idx on transaction (scheduled_event_id)\n  where scheduled_event_id is not null","-- ---------------------------------------------------------------------------\n-- Aritmetica de fechas\n-- ---------------------------------------------------------------------------\n\ncreate or replace function avanzar_fecha(p_desde date, p_frecuencia text)\nreturns date\nlanguage sql\nimmutable\nset search_path = public, pg_temp\nas $$\n  select p_desde + case p_frecuencia\n    when 'weekly'    then interval '1 week'\n    when 'monthly'   then interval '1 month'\n    when 'bimonthly' then interval '2 months'\n    when 'quarterly' then interval '3 months'\n    when 'biannual'  then interval '6 months'\n    when 'yearly'    then interval '1 year'\n  end\n$$","comment on function avanzar_fecha(date, text) is\n  'Postgres ya resuelve bien el caso incomodo: 31 de enero + 1 mes da 28 de '\n  'febrero, y no se rompe en anios bisiestos.'","-- ---------------------------------------------------------------------------\n-- Registrar una ocurrencia: crea el movimiento Y adelanta la fecha, atomico.\n--\n-- Mismo criterio que create_transaction (ADR-019): si algo falla no puede quedar\n-- el movimiento sin adelantar la fecha, ni la fecha adelantada sin movimiento.\n-- SECURITY INVOKER explicito: RLS sigue aplicando.\n-- ---------------------------------------------------------------------------\n\ncreate or replace function register_scheduled(\n  p_event    uuid,\n  p_amount   numeric,\n  p_on       date default null,   -- null = la fecha prevista de la regla\n  p_account  uuid default null    -- null = la cuenta que tenga la regla\n) returns uuid\nlanguage plpgsql\nsecurity invoker\nset search_path = public, pg_temp\nas $$\ndeclare\n  ev       scheduled_event%rowtype;\n  v_cuenta uuid;\n  v_fecha  date;\n  v_tx     uuid;\n  v_monto  numeric;\nbegin\n  select * into ev from scheduled_event where id = p_event;\n  if not found then\n    raise exception 'No existe ese evento programado';\n  end if;\n  if ev.archived_at is not null then\n    raise exception 'Ese evento esta archivado';\n  end if;\n\n  v_cuenta := coalesce(p_account, ev.account_id);\n  v_fecha  := coalesce(p_on, ev.next_on);\n  v_monto  := abs(coalesce(p_amount, ev.amount));\n\n  if v_cuenta is null then\n    raise exception 'Hace falta indicar con que cuenta se paga';\n  end if;\n  if v_monto is null or v_monto = 0 then\n    raise exception 'Hace falta indicar el importe';\n  end if;\n\n  if ev.kind = 'recurring' then\n    if ev.category_id is null then\n      raise exception 'La regla no tiene categoria';\n    end if;\n    -- Un gasto normal: sale de la cuenta hacia la categoria. El convenio de\n    -- signos es el mismo de siempre (modelo-de-datos §1).\n    insert into transaction (ledger_id, occurred_on, description, kind, created_by,\n                             scheduled_event_id)\n         values (ev.ledger_id, v_fecha, ev.description, 'expense', auth.uid(), ev.id)\n      returning id into v_tx;\n\n    insert into entry (transaction_id, ledger_id, account_id, category_id, amount, unit)\n    values (v_tx, ev.ledger_id, v_cuenta, null, -v_monto, ev.currency),\n           (v_tx, ev.ledger_id, null, ev.category_id, v_monto, ev.currency);\n\n    -- Se adelanta hasta pasar la fecha registrada: si estuvo vencido varios\n    -- periodos, un solo registro no deberia dejarlo vencido otra vez.\n    update scheduled_event\n       set next_on = avanzar_fecha(next_on, frequency)\n     where id = ev.id;\n\n  else\n    -- 'maturity': el vencimiento de un plazo fijo. Se resuelve en la etapa de\n    -- inversiones; por ahora se rechaza en vez de inventar un asiento.\n    raise exception 'Los vencimientos se registran desde la seccion de inversiones';\n  end if;\n\n  return v_tx;\nend $$","grant execute on function register_scheduled(uuid, numeric, date, uuid) to authenticated","grant execute on function avanzar_fecha(date, text) to authenticated","-- ---------------------------------------------------------------------------\n-- Lo que se viene\n-- ---------------------------------------------------------------------------\n\ncreate view upcoming as\n  select s.id,\n         s.ledger_id,\n         s.kind,\n         s.description,\n         s.amount,\n         s.currency,\n         s.frequency,\n         s.next_on,\n         s.ends_on,\n         s.category_id,\n         c.name        as category_name,\n         p.name        as category_parent,\n         s.account_id,\n         a.name        as account_name,\n         (s.next_on - current_date) as dias,\n         -- ya paso la fecha y nadie lo registro\n         (s.next_on < current_date) as vencido\n    from scheduled_event s\n    left join category c on c.id = s.category_id\n    left join category p on p.id = c.parent_id\n    left join account  a on a.id = s.account_id\n   where s.archived_at is null\n     and (s.ends_on is null or s.ends_on >= current_date)","alter view upcoming set (security_invoker = on)","grant select on upcoming to authenticated","comment on view upcoming is\n  'Eventos programados vigentes, con cuantos dias faltan y si ya vencieron. '\n  'No incluye los archivados ni los terminados.'","-- ---------------------------------------------------------------------------\n-- Saltear un periodo sin registrar nada.\n--\n-- Hace falta de verdad: un impuesto que este bimestre no vino, una suscripcion\n-- que se pauso. Sin esto el unico camino seria registrar un movimiento falso o\n-- editar la fecha a mano, y las dos cosas ensucian los datos.\n--\n-- La aritmetica vive aca y no en el cliente: una sola definicion de \\"el proximo\n-- periodo\\" evita que dos lugares del codigo no coincidan.\n-- ---------------------------------------------------------------------------\n\ncreate or replace function skip_scheduled(p_event uuid)\nreturns date\nlanguage plpgsql\nsecurity invoker\nset search_path = public, pg_temp\nas $$\ndeclare v_next date;\nbegin\n  update scheduled_event\n     set next_on = avanzar_fecha(next_on, frequency)\n   where id = p_event and archived_at is null and kind = 'recurring'\nreturning next_on into v_next;\n\n  if v_next is null then\n    raise exception 'No se pudo saltear: el evento no existe, esta archivado o no es recurrente';\n  end if;\n  return v_next;\nend $$","grant execute on function skip_scheduled(uuid) to authenticated"}	recurrentes
20260916120000	{"-- Plazos fijos — brief §12, sobre ADR-014.\n--\n-- Un plazo fijo es la familia 'accrual' de ADR-012: no cotiza, devenga. Su valor\n-- final se conoce el dia que se constituye, asi que no hace falta ninguna fuente\n-- de precios: hace falta una FECHA.\n--\n-- Por eso reusa el motor de eventos futuros de ADR-016: un vencimiento y un gasto\n-- recurrente son el mismo objeto, un hecho futuro con fecha y monto conocidos.\n\n-- A donde vuelve la plata al vencer. Para un recurrente no aplica; para un\n-- vencimiento es la otra punta del movimiento.\nalter table scheduled_event add column counter_account_id uuid","alter table scheduled_event add constraint sched_counter_same_ledger\n  foreign key (counter_account_id, ledger_id) references account(id, ledger_id)","-- ---------------------------------------------------------------------------\n-- Constituirlo: crea la cuenta, mueve la plata y agenda el vencimiento.\n-- Las tres cosas en una transaccion: una cuenta sin su transferencia seria una\n-- cuenta fantasma, y una transferencia sin su vencimiento agendado es plata que\n-- se olvida.\n-- ---------------------------------------------------------------------------\n\ncreate or replace function create_plazo_fijo(\n  p_nombre      text,\n  p_desde       uuid,      -- cuenta de origen\n  p_capital     numeric,\n  p_vence       date,\n  p_esperado    numeric,   -- cuanto vuelve al vencimiento, capital incluido\n  p_institucion text default null,\n  p_on          date default null   -- fecha de constitucion\n) returns uuid\nlanguage plpgsql\nsecurity invoker\nset search_path = public, pg_temp\nas $$\ndeclare\n  v_ledger  uuid := my_ledger();\n  v_origen  account%rowtype;\n  v_cuenta  uuid;\n  v_tx      uuid;\n  v_fecha   date := coalesce(p_on, current_date);\nbegin\n  select * into v_origen from account where id = p_desde;\n  if not found then raise exception 'No existe la cuenta de origen'; end if;\n  if p_capital is null or p_capital <= 0 then\n    raise exception 'El capital tiene que ser mayor que cero';\n  end if;\n  if p_esperado is null or p_esperado < p_capital then\n    raise exception 'Lo que vuelve al vencimiento no puede ser menor que el capital';\n  end if;\n  if p_vence <= v_fecha then\n    raise exception 'El vencimiento tiene que ser posterior a la constitucion';\n  end if;\n\n  insert into account (ledger_id, name, kind, valuation, unit, is_spendable,\n                       matures_on, expected_amount, institution)\n       values (v_ledger, p_nombre, 'asset', 'accrual', v_origen.unit, false,\n               p_vence, p_esperado, coalesce(p_institucion, v_origen.institution))\n    returning id into v_cuenta;\n\n  -- Constituirlo no es un gasto: la plata cambia de lugar, el patrimonio no se\n  -- mueve. Por eso ninguna categoria participa.\n  insert into transaction (ledger_id, occurred_on, description, kind, created_by)\n       values (v_ledger, v_fecha, 'Constitución de ' || p_nombre, 'transfer', auth.uid())\n    returning id into v_tx;\n\n  insert into entry (transaction_id, ledger_id, account_id, amount, unit) values\n    (v_tx, v_ledger, p_desde,  -p_capital, v_origen.unit),\n    (v_tx, v_ledger, v_cuenta,  p_capital, v_origen.unit);\n\n  insert into scheduled_event (ledger_id, kind, description, account_id,\n                               counter_account_id, amount, currency, next_on)\n       values (v_ledger, 'maturity', 'Vence ' || p_nombre, v_cuenta,\n               p_desde, p_esperado, v_origen.unit, p_vence);\n\n  return v_cuenta;\nend $$","grant execute on function create_plazo_fijo(text, uuid, numeric, date, numeric, text, date) to authenticated","-- ---------------------------------------------------------------------------\n-- Vencerlo: el capital vuelve y el interes se reconoce como ingreso.\n-- Es el caso 5.12 de modelo-de-datos: tres lineas, una sola unidad, suma cero.\n--\n-- El interes se calcula, NO se pide: es lo que volvio menos lo que habia. Pedirlo\n-- por separado abriria la puerta a que los dos numeros no coincidan.\n-- ---------------------------------------------------------------------------\n\ncreate or replace function register_maturity(\n  p_event uuid,\n  p_total numeric default null,   -- lo que efectivamente volvio\n  p_to    uuid    default null,   -- a que cuenta\n  p_on    date    default null\n) returns uuid\nlanguage plpgsql\nsecurity invoker\nset search_path = public, pg_temp\nas $$\ndeclare\n  ev        scheduled_event%rowtype;\n  v_capital numeric;\n  v_total   numeric;\n  v_interes numeric;\n  v_destino uuid;\n  v_fecha   date;\n  v_cat     uuid;\n  v_tx      uuid;\nbegin\n  select * into ev from scheduled_event where id = p_event and kind = 'maturity';\n  if not found then raise exception 'No existe ese vencimiento'; end if;\n  if ev.archived_at is not null then raise exception 'Ese vencimiento ya se registro'; end if;\n\n  v_destino := coalesce(p_to, ev.counter_account_id);\n  if v_destino is null then raise exception 'Hace falta indicar a que cuenta vuelve'; end if;\n\n  v_fecha := coalesce(p_on, ev.next_on);\n  v_total := coalesce(p_total, ev.amount);\n  if v_total is null or v_total <= 0 then\n    raise exception 'Hace falta indicar cuanto volvio';\n  end if;\n\n  select coalesce(sum(amount), 0) into v_capital from entry where account_id = ev.account_id;\n  if v_capital <= 0 then raise exception 'El plazo fijo no tiene capital'; end if;\n\n  v_interes := v_total - v_capital;\n\n  -- La categoria de intereses se busca por lo que ES, no por su nombre: quien la\n  -- renombre no deberia romper esto.\n  select id into v_cat from category\n   where ledger_id = ev.ledger_id and is_system and kind = 'income'\n   limit 1;\n  if v_cat is null then raise exception 'Falta la categoria de sistema de ingresos'; end if;\n\n  insert into transaction (ledger_id, occurred_on, description, kind, created_by,\n                           scheduled_event_id)\n       values (ev.ledger_id, v_fecha, ev.description, 'income', auth.uid(), ev.id)\n    returning id into v_tx;\n\n  insert into entry (transaction_id, ledger_id, account_id, amount, unit) values\n    (v_tx, ev.ledger_id, ev.account_id, -v_capital, ev.currency),\n    (v_tx, ev.ledger_id, v_destino,      v_total,   ev.currency);\n\n  -- Solo si hubo interes. Una linea en cero seria ruido en el historial.\n  if v_interes <> 0 then\n    insert into entry (transaction_id, ledger_id, category_id, amount, unit)\n    values (v_tx, ev.ledger_id, v_cat, -v_interes, ev.currency);\n  end if;\n\n  -- El plazo fijo cumplio su ciclo: se archiva, no se borra. Sus movimientos\n  -- siguen explicando de donde salio y a donde fue.\n  update account set archived_at = now() where id = ev.account_id;\n  update scheduled_event set archived_at = now() where id = ev.id;\n\n  return v_tx;\nend $$","grant execute on function register_maturity(uuid, numeric, uuid, date) to authenticated","-- ---------------------------------------------------------------------------\n-- La vista de lo que viene ahora tambien dice a donde vuelve y cuanto hay puesto\n-- ---------------------------------------------------------------------------\n\ndrop view if exists upcoming","create view upcoming as\n  select s.id,\n         s.ledger_id,\n         s.kind,\n         s.description,\n         s.amount,\n         s.currency,\n         s.frequency,\n         s.next_on,\n         s.ends_on,\n         s.category_id,\n         c.name  as category_name,\n         p.name  as category_parent,\n         s.account_id,\n         a.name  as account_name,\n         s.counter_account_id,\n         d.name  as counter_account_name,\n         -- cuanto hay puesto: solo tiene sentido para un vencimiento\n         case when s.kind = 'maturity'\n              then (select coalesce(sum(e.amount), 0) from entry e where e.account_id = s.account_id)\n         end as capital,\n         (s.next_on - current_date) as dias,\n         (s.next_on < current_date) as vencido\n    from scheduled_event s\n    left join category c on c.id = s.category_id\n    left join category p on p.id = c.parent_id\n    left join account  a on a.id = s.account_id\n    left join account  d on d.id = s.counter_account_id\n   where s.archived_at is null\n     and (s.ends_on is null or s.ends_on >= current_date)","alter view upcoming set (security_invoker = on)","grant select on upcoming to authenticated"}	plazos_fijos
20260916130000	{"-- Posiciones: la familia 'market' de ADR-012 — unidades x precio.\n--\n-- Comprar un activo NO es un caso nuevo: es un intercambio de dos unidades, igual\n-- que comprar dolares (ADR-010). Sale plata, entran unidades, y el precio unitario\n-- es el cociente. Por eso no hace falta ningun asiento especial.\n--\n-- Lo nuevo es la VALUACION: para saber cuanto vale hoy hace falta un precio, y ese\n-- si viene de afuera.\n\n-- ---------------------------------------------------------------------------\n-- Comprar. Crea el instrumento y la posicion si es la primera vez, asi el usuario\n-- no tiene que darlos de alta por separado antes de poder comprar.\n-- ---------------------------------------------------------------------------\n\ncreate or replace function comprar_activo(\n  p_symbol   text,\n  p_nombre   text,\n  p_kind     text,\n  p_moneda   text,      -- en que se cotiza\n  p_decimals int,\n  p_desde    uuid,      -- de que cuenta sale la plata\n  p_monto    numeric,   -- cuanto se pago\n  p_unidades numeric,   -- cuantas unidades entraron\n  p_broker   text default null,\n  p_on       date default null\n) returns uuid           -- la cuenta de la posicion\nlanguage plpgsql\nsecurity invoker\nset search_path = public, pg_temp\nas $$\ndeclare\n  v_ledger uuid := my_ledger();\n  v_origen account%rowtype;\n  v_inst   uuid;\n  v_pos    uuid;\n  v_tx     uuid;\n  v_fecha  date := coalesce(p_on, current_date);\nbegin\n  if p_monto is null or p_monto <= 0 then raise exception 'El monto tiene que ser mayor que cero'; end if;\n  if p_unidades is null or p_unidades <= 0 then raise exception 'Las unidades tienen que ser mayores que cero'; end if;\n\n  select * into v_origen from account where id = p_desde;\n  if not found then raise exception 'No existe la cuenta de origen'; end if;\n\n  -- el instrumento, si no estaba\n  select id into v_inst from instrument\n   where ledger_id = v_ledger and symbol = upper(trim(p_symbol));\n  if v_inst is null then\n    insert into instrument (ledger_id, symbol, name, kind, quote_currency, decimals)\n         values (v_ledger, upper(trim(p_symbol)), p_nombre, p_kind, p_moneda, p_decimals)\n      returning id into v_inst;\n  end if;\n\n  -- la posicion, si no estaba. Es una CUENTA cuya unidad es el activo: tener 0,05\n  -- BTC es lo mismo que tener 1000 USD, solo cambia la unidad.\n  select id into v_pos from account\n   where ledger_id = v_ledger and instrument_id = v_inst and archived_at is null;\n  if v_pos is null then\n    insert into account (ledger_id, name, kind, valuation, unit, instrument_id,\n                         is_spendable, institution)\n         values (v_ledger,\n                 coalesce(p_broker || ' · ', '') || upper(trim(p_symbol)),\n                 'asset', 'market', upper(trim(p_symbol)), v_inst,\n                 false, coalesce(p_broker, v_origen.institution))\n      returning id into v_pos;\n  end if;\n\n  insert into transaction (ledger_id, occurred_on, description, kind, created_by)\n       values (v_ledger, v_fecha,\n               'Compra de ' || upper(trim(p_symbol)), 'trade', auth.uid())\n    returning id into v_tx;\n\n  -- dos unidades distintas: el precio unitario es el cociente (ADR-010)\n  insert into entry (transaction_id, ledger_id, account_id, amount, unit) values\n    (v_tx, v_ledger, p_desde, -p_monto,    v_origen.unit),\n    (v_tx, v_ledger, v_pos,    p_unidades, upper(trim(p_symbol)));\n\n  return v_pos;\nend $$","grant execute on function comprar_activo(text, text, text, text, int, uuid, numeric, numeric, text, date) to authenticated","-- ---------------------------------------------------------------------------\n-- Vender. El patrimonio NO cambia: cambia de forma.\n-- La ganancia ya estaba reconocida mientras el precio subia; vender solo la pasa\n-- de no realizada a realizada. Por eso ninguna categoria de ingreso participa.\n-- ---------------------------------------------------------------------------\n\ncreate or replace function vender_activo(\n  p_pos      uuid,\n  p_unidades numeric,\n  p_hacia    uuid,\n  p_monto    numeric,\n  p_on       date default null\n) returns uuid\nlanguage plpgsql\nsecurity invoker\nset search_path = public, pg_temp\nas $$\ndeclare\n  v_pos     account%rowtype;\n  v_destino account%rowtype;\n  v_tengo   numeric;\n  v_tx      uuid;\nbegin\n  select * into v_pos from account where id = p_pos and valuation = 'market';\n  if not found then raise exception 'No existe esa posicion'; end if;\n  select * into v_destino from account where id = p_hacia;\n  if not found then raise exception 'No existe la cuenta de destino'; end if;\n  if p_unidades is null or p_unidades <= 0 then raise exception 'Las unidades tienen que ser mayores que cero'; end if;\n  if p_monto is null or p_monto <= 0 then raise exception 'El monto tiene que ser mayor que cero'; end if;\n\n  select coalesce(sum(amount), 0) into v_tengo from entry where account_id = p_pos;\n  if p_unidades > v_tengo then\n    raise exception 'No tenes tantas unidades: hay % y queres vender %', v_tengo, p_unidades;\n  end if;\n\n  insert into transaction (ledger_id, occurred_on, description, kind, created_by)\n       values (v_pos.ledger_id, coalesce(p_on, current_date),\n               'Venta de ' || v_pos.unit, 'trade', auth.uid())\n    returning id into v_tx;\n\n  insert into entry (transaction_id, ledger_id, account_id, amount, unit) values\n    (v_tx, v_pos.ledger_id, p_pos,   -p_unidades, v_pos.unit),\n    (v_tx, v_pos.ledger_id, p_hacia,  p_monto,    v_destino.unit);\n\n  -- Si se vendio todo, la posicion cumplio su ciclo. Se archiva, no se borra:\n  -- sus movimientos siguen explicando que paso.\n  if v_tengo - p_unidades = 0 then\n    update account set archived_at = now() where id = p_pos;\n  end if;\n\n  return v_tx;\nend $$","grant execute on function vender_activo(uuid, numeric, uuid, numeric, date) to authenticated","-- ---------------------------------------------------------------------------\n-- Cuanto vale y cuanto gane.\n--\n-- La ganancia se calcula sin necesidad de FIFO ni promedio ponderado:\n--\n--     invertido = plata que salio  -  plata que volvio\n--     ganancia  = valor actual     -  invertido\n--\n-- Eso es correcto incluso con ventas parciales, y es exactamente la \\"ganancia\n-- absoluta\\" que pide el brief §13: la unica metrica que se explica sola. El\n-- metodo de costo (OD-20) recien hace falta para separar realizada de no\n-- realizada, que es otra pregunta.\n-- ---------------------------------------------------------------------------\n\ncreate view posicion as\n  select a.id           as account_id,\n         a.ledger_id,\n         a.name,\n         a.institution,\n         i.id           as instrument_id,\n         i.symbol,\n         i.name         as instrument_name,\n         i.kind,\n         i.quote_currency,\n         i.decimals,\n         coalesce(u.unidades, 0)                as unidades,\n         p.price                                as precio,\n         p.on_date                              as precio_al,\n         p.source                               as precio_fuente,\n         coalesce(u.unidades, 0) * p.price      as valor,\n         coalesce(f.invertido, 0)               as invertido,\n         coalesce(u.unidades, 0) * p.price - coalesce(f.invertido, 0) as ganancia\n    from account a\n    join instrument i on i.id = a.instrument_id\n    left join lateral (\n      select sum(e.amount) as unidades from entry e where e.account_id = a.id\n    ) u on true\n    left join lateral (\n      -- la otra pata de cada operacion: lo que salio menos lo que volvio\n      select -sum(c.amount) as invertido\n        from entry pe\n        join entry c on c.transaction_id = pe.transaction_id\n                    and c.account_id is not null\n                    and c.account_id <> a.id\n       where pe.account_id = a.id\n    ) f on true\n    left join lateral (\n      select pr.price, pr.on_date, pr.source\n        from price pr\n       where pr.instrument_id = i.id\n       order by pr.on_date desc\n       limit 1\n    ) p on true\n   where a.valuation = 'market'\n     and a.archived_at is null","alter view posicion set (security_invoker = on)","grant select on posicion to authenticated","comment on view posicion is\n  'Posiciones vivas con su valuacion al ultimo precio cargado. Si nunca se cargo '\n  'un precio, valor y ganancia quedan nulos: la app tiene que decir que no sabe, '\n  'no mostrar cero.'"}	posiciones
20260916140000	{"-- Medir en dolares o en poder adquisitivo — ADR-009 generalizada.\n--\n-- Sin esto la pregunta central del proyecto -\\"¿mis inversiones rinden 10% anual\n-- en dolares?\\"- no tiene respuesta, porque nada se puede expresar en dolares\n-- salvo lo que ya esta en dolares.\n--\n-- LA IDEA: la unidad de medida es apenas un DIVISOR.\n--\n--   en dolares            -> dividir por la cotizacion de ese dia\n--   en poder adquisitivo  -> dividir por la UVA de ese dia\n--\n-- Es la misma maquinaria, asi que la medida es un parametro y no una constante.\n-- Eso permite responder dos preguntas distintas con el mismo codigo:\n--\n--   \\"¿le gano al dolar?\\"      medir en USD\n--   \\"¿le gano a la inflacion?\\" medir en UVA\n--\n-- Y no son la misma pregunta: si el dolar sube menos que los precios -atraso\n-- cambiario- se puede tener +0% en dolares y estar perdiendo poder adquisitivo.\n\n-- La UVA entra como una cotizacion mas: \\"cuantos pesos vale una UVA\\". No hace\n-- falta una tabla nueva porque es exactamente la misma forma de dato.\nalter table fx_rate drop constraint if exists fx_rate_source_check","alter table fx_rate add constraint fx_rate_source_check\n  check (source in ('oficial','mep','blue','ccl','cripto','mayorista','uva','manual'))","-- Que dolar usa el libro por defecto.\n--\n-- SECURITY DEFINER por la misma razon que my_ledger(): ADR-020 le niega al\n-- cliente todo acceso a la tabla 'ledger', asi que una funcion SECURITY INVOKER\n-- que la consulte falla con permiso denegado. Se expone el DATO, no la tabla.\ncreate or replace function my_fx_source() returns text\nlanguage sql\nstable\nsecurity definer\nset search_path = public, pg_temp\nas $$\n  select l.default_fx_source\n    from ledger l\n    join ledger_member m on m.ledger_id = l.id\n   where m.user_id = auth.uid()\n   limit 1\n$$","revoke all on function my_fx_source() from public","grant execute on function my_fx_source() to authenticated","-- ---------------------------------------------------------------------------\n-- La cotizacion vigente para una fecha.\n--\n-- Usa la ULTIMA anterior o igual, no la mas cercana: un sabado no cotiza, y el\n-- valor que regia ese dia es el del viernes, no el del lunes siguiente. Tomar el\n-- lunes seria usar informacion que en ese momento no existia.\n-- ---------------------------------------------------------------------------\n\ncreate or replace function cotizacion(\n  p_fecha  date,\n  p_fuente text,\n  p_base   text default 'USD',\n  p_quote  text default 'ARS'\n) returns numeric\nlanguage sql\nstable\nset search_path = public, pg_temp\nas $$\n  select rate from fx_rate\n   where ledger_id = my_ledger()\n     and base = p_base and quote = p_quote and source = p_fuente\n     and on_date <= p_fecha\n   order by on_date desc\n   limit 1\n$$","grant execute on function cotizacion(date, text, text, text) to authenticated","-- De que dia es el dato que se esta usando.\n--\n-- Hace falta porque \\"hay una cotizacion\\" NO es lo mismo que \\"hay una cotizacion\n-- reciente\\": con la regla de la ultima anterior o igual, un dato de marzo cubre\n-- formalmente a septiembre, y valuar septiembre con el dolar de marzo no es\n-- medir, es inventar. La pantalla tiene que poder avisarlo.\ncreate or replace function cotizacion_al(\n  p_fecha  date,\n  p_fuente text,\n  p_base   text default 'USD',\n  p_quote  text default 'ARS'\n) returns date\nlanguage sql\nstable\nset search_path = public, pg_temp\nas $$\n  select on_date from fx_rate\n   where ledger_id = my_ledger()\n     and base = p_base and quote = p_quote and source = p_fuente\n     and on_date <= p_fecha\n   order by on_date desc\n   limit 1\n$$","grant execute on function cotizacion_al(date, text, text, text) to authenticated","-- ---------------------------------------------------------------------------\n-- Cuanto vale un monto en la medida elegida, a la vara de SU fecha.\n--\n-- Devuelve NULL si falta el dato. A proposito: es preferible que la pantalla\n-- diga \\"no se\\" a que muestre un numero calculado con una cotizacion inventada.\n-- Brief §20, transparencia.\n-- ---------------------------------------------------------------------------\n\ncreate or replace function convertir(\n  p_monto  numeric,\n  p_unidad text,\n  p_fecha  date,\n  p_medida text default 'USD',   -- 'USD' o 'UVA'\n  p_fuente text default null     -- que dolar; null = el del libro\n) returns numeric\nlanguage plpgsql\nstable\nset search_path = public, pg_temp\nas $$\ndeclare\n  v_fuente text;\n  v_usd    numeric;\n  v_ars    numeric;\n  v_uva    numeric;\nbegin\n  if p_monto is null then return null; end if;\n\n  -- Una unidad que no es moneda -BTC, un CEDEAR- no se convierte aca: primero\n  -- hay que valuarla con su precio.\n  if p_unidad not in ('ARS','USD','USDT','USDC','DAI') then\n    return null;\n  end if;\n\n  v_fuente := coalesce(p_fuente, my_fx_source());\n\n  if p_medida = 'USD' then\n    -- USDT, USDC y DAI se toman como dolar. Es una aproximacion deliberada: se\n    -- despegan unas centesimas y esa diferencia es ruido frente a lo que se mide.\n    if p_unidad <> 'ARS' then return p_monto; end if;\n    v_usd := cotizacion(p_fecha, v_fuente);\n    if v_usd is null or v_usd = 0 then return null; end if;\n    return p_monto / v_usd;\n\n  elsif p_medida = 'UVA' then\n    v_uva := cotizacion(p_fecha, 'uva', 'UVA', 'ARS');\n    if v_uva is null or v_uva = 0 then return null; end if;\n\n    if p_unidad = 'ARS' then\n      v_ars := p_monto;\n    else\n      -- primero a pesos de ese dia, despues a UVAs\n      v_usd := cotizacion(p_fecha, v_fuente);\n      if v_usd is null then return null; end if;\n      v_ars := p_monto * v_usd;\n    end if;\n    return v_ars / v_uva;\n  end if;\n\n  raise exception 'Medida desconocida: %. Se admiten USD y UVA', p_medida;\nend $$","grant execute on function convertir(numeric, text, date, text, text) to authenticated","-- ---------------------------------------------------------------------------\n-- Que datos faltan para poder medir.\n-- La pantalla necesita poder decir \\"no puedo calcularlo y esto es lo que falta\\",\n-- no simplemente mostrar un hueco.\n-- ---------------------------------------------------------------------------\n\ncreate view medicion_faltante as\n  with fechas as (\n    select distinct t.occurred_on as fecha\n      from entry e\n      join account a on a.id = e.account_id\n      join transaction t on t.id = e.transaction_id\n     where a.valuation in ('market','accrual')\n    union\n    select current_date\n  ),\n  evaluada as (\n    select f.fecha,\n           cotizacion_al(f.fecha, my_fx_source())       as dolar_al,\n           cotizacion_al(f.fecha, 'uva', 'UVA', 'ARS')  as uva_al\n      from fechas f\n  )\n  select fecha,\n         dolar_al,\n         uva_al,\n         (dolar_al is null) as sin_dolar,\n         (uva_al   is null) as sin_uva,\n         -- Mas de una semana de desfasaje ya no es una cotizacion: es una\n         -- suposicion. Con el dolar moviendose como se mueve, usar el dato de\n         -- hace un mes distorsiona mas que no mostrar nada.\n         (dolar_al is not null and fecha - dolar_al > 7) as dolar_viejo,\n         (uva_al   is not null and fecha - uva_al   > 7) as uva_viejo\n    from evaluada\n   where dolar_al is null\n      or uva_al   is null\n      or fecha - dolar_al > 7\n      or fecha - uva_al   > 7","alter view medicion_faltante set (security_invoker = on)","grant select on medicion_faltante to authenticated"}	medicion
20260916150000	{"-- Los flujos de cada inversion, ya convertidos a la vara de SU fecha.\n--\n-- Con esto el cliente puede calcular XIRR sin saber nada de cotizaciones: pide\n-- los flujos y el valor de hoy, y aplica la formula.\n\n-- ---------------------------------------------------------------------------\n-- Cada movimiento de plata que entro o salio de una inversion.\n--\n-- La pata que importa es la de la CUENTA contraria, no la de la categoria: en el\n-- vencimiento de un plazo fijo hay tres lineas -capital que sale, total que\n-- vuelve, interes que se imputa- y sumarlas todas daria el capital en vez del\n-- total. El flujo real es lo que entro a tu bolsillo.\n--\n-- El signo ya viene bien de la partida doble: cuando comprás, la cuenta de\n-- efectivo va en negativo, que es exactamente lo que XIRR espera de un aporte.\n-- ---------------------------------------------------------------------------\n\ncreate view flujo_inversion as\n  select a.id                                   as account_id,\n         a.valuation,\n         t.occurred_on                          as fecha,\n         c.amount                               as monto,\n         c.unit                                 as unidad,\n         convertir(c.amount, c.unit, t.occurred_on, 'USD') as usd,\n         convertir(c.amount, c.unit, t.occurred_on, 'UVA') as uva\n    from entry pe\n    join account a on a.id = pe.account_id\n                  and a.valuation in ('market', 'accrual')\n    join transaction t on t.id = pe.transaction_id\n    join entry c on c.transaction_id = pe.transaction_id\n                and c.account_id is not null\n                and c.account_id <> a.id","alter view flujo_inversion set (security_invoker = on)","grant select on flujo_inversion to authenticated","-- ---------------------------------------------------------------------------\n-- Cuanto vale hoy cada inversion, en cada vara.\n--\n-- Entra al calculo como un flujo POSITIVO con fecha de hoy: es lo que recibirias\n-- si vendieras todo ahora.\n-- ---------------------------------------------------------------------------\n\ncreate view valor_inversion as\n  select a.id            as account_id,\n         a.name,\n         a.valuation,\n         a.institution,\n         a.matures_on,\n         i.symbol,\n         i.kind,\n         i.quote_currency,\n         coalesce(sal.saldo, 0) as saldo,\n         case\n           -- una posicion vale unidades por precio, y sin precio no vale \\"cero\\":\n           -- vale desconocido\n           when a.valuation = 'market' then coalesce(sal.saldo, 0) * pr.price\n           -- un plazo fijo vale su capital hasta que vence (ADR-014)\n           else coalesce(sal.saldo, 0)\n         end as valor_nativo,\n         case when a.valuation = 'market' then i.quote_currency else a.unit end as moneda,\n         pr.on_date as precio_al,\n         convertir(\n           case when a.valuation = 'market' then coalesce(sal.saldo, 0) * pr.price\n                else coalesce(sal.saldo, 0) end,\n           case when a.valuation = 'market' then i.quote_currency else a.unit end,\n           current_date, 'USD') as usd,\n         convertir(\n           case when a.valuation = 'market' then coalesce(sal.saldo, 0) * pr.price\n                else coalesce(sal.saldo, 0) end,\n           case when a.valuation = 'market' then i.quote_currency else a.unit end,\n           current_date, 'UVA') as uva\n    from account a\n    left join instrument i on i.id = a.instrument_id\n    left join lateral (\n      select sum(e.amount) as saldo from entry e where e.account_id = a.id\n    ) sal on true\n    left join lateral (\n      select p.price, p.on_date from price p\n       where p.instrument_id = a.instrument_id\n       order by p.on_date desc limit 1\n    ) pr on true\n   where a.valuation in ('market', 'accrual')\n     and a.archived_at is null","alter view valor_inversion set (security_invoker = on)","grant select on valor_inversion to authenticated","comment on view valor_inversion is\n  'Valor actual de cada inversion en su moneda nativa y en las dos varas de '\n  'medicion. NULL cuando falta el precio o la cotizacion: la pantalla dice que '\n  'no sabe, no muestra cero.'"}	cartera
20260916160000	{"-- Las inversiones cerradas siguen contando.\n--\n-- Una posicion vendida entera se archiva, y la vista de valuacion la excluia. El\n-- efecto era que DESAPARECIA del calculo con todos sus flujos: si comprabas,\n-- duplicabas y vendias, tu mejor operacion se borraba de tu rendimiento. Y una\n-- venta con perdida tambien.\n--\n-- Lo correcto es que valga CERO, no que no exista: los flujos -lo que pusiste y\n-- lo que sacaste- son parte de tu historial de inversion y XIRR los necesita.\n--\n-- Eso mide \\"como me fue invirtiendo\\", que es la pregunta. La plata que despues\n-- quedo quieta en una cuenta no forma parte de la cartera, y con razon: no esta\n-- invertida.\n\ndrop view if exists valor_inversion","create view valor_inversion as\n  select a.id            as account_id,\n         a.name,\n         a.valuation,\n         a.institution,\n         a.matures_on,\n         (a.archived_at is not null) as cerrada,\n         i.symbol,\n         i.kind,\n         i.quote_currency,\n         coalesce(sal.saldo, 0) as saldo,\n         v.valor_nativo,\n         case when a.valuation = 'market' then i.quote_currency else a.unit end as moneda,\n         pr.on_date as precio_al,\n         convertir(v.valor_nativo,\n                   case when a.valuation = 'market' then i.quote_currency else a.unit end,\n                   current_date, 'USD') as usd,\n         convertir(v.valor_nativo,\n                   case when a.valuation = 'market' then i.quote_currency else a.unit end,\n                   current_date, 'UVA') as uva\n    from account a\n    left join instrument i on i.id = a.instrument_id\n    left join lateral (\n      select sum(e.amount) as saldo from entry e where e.account_id = a.id\n    ) sal on true\n    left join lateral (\n      select p.price, p.on_date from price p\n       where p.instrument_id = a.instrument_id\n       order by p.on_date desc limit 1\n    ) pr on true\n    left join lateral (\n      select case\n               -- Sin unidades no hace falta precio para saber que vale cero.\n               -- Antes esto daba NULL -0 por un precio ausente- y dejaba la\n               -- posicion cerrada afuera del calculo.\n               when coalesce(sal.saldo, 0) = 0 then 0\n               when a.valuation = 'market'     then sal.saldo * pr.price\n               else sal.saldo\n             end as valor_nativo\n    ) v on true\n   where a.valuation in ('market', 'accrual')","alter view valor_inversion set (security_invoker = on)","grant select on valor_inversion to authenticated","comment on view valor_inversion is\n  'Valor actual de cada inversion, viva o cerrada, en su moneda nativa y en las '\n  'dos varas. Las cerradas valen cero pero siguen en la lista: sus flujos son '\n  'parte del historial y el rendimiento los necesita.'"}	cerradas
20260916170000	{"-- CEDEARs: separar el rendimiento del activo del movimiento del dolar.  OD-17.\n--\n-- EL PROBLEMA. Un CEDEAR cotiza en pesos y su precio ya lleva el CCL adentro:\n--\n--     precio_cedear_ARS = (precio_accion_USD / ratio) x CCL\n--\n-- Asi que sube por dos motivos que el precio mezcla: porque subio la accion en\n-- dolares, o porque subio el CCL. Valuarlo en pesos y convertir al MEP -o a\n-- cualquier otro dolar- arrastra esa mezcla.\n--\n-- LA SOLUCION. Convertir al CCL. El CCL se cancela y queda:\n--\n--     valor_USD = precio_cedear_ARS x unidades / CCL\n--               = (precio_accion_USD / ratio) x unidades\n--\n-- o sea el valor en dolares de la accion subyacente. Sin necesitar el ratio ni\n-- traer el precio del exterior: alcanza con usar la vara correcta.\n--\n-- Convertir al MEP responde otra pregunta, tambien legitima: \\"cuantos dolares\n-- saco si vendo y extraigo por MEP\\". Por eso la fuente es una propiedad de la\n-- CUENTA (ADR-011) y no una constante del sistema.\n--\n-- Lo que faltaba era que las vistas de medicion la respetaran: la declaraban y\n-- no la usaban.\n\n-- ---------------------------------------------------------------------------\n-- Los flujos, con la vara de su cuenta\n-- ---------------------------------------------------------------------------\n\ndrop view if exists flujo_inversion","create view flujo_inversion as\n  select a.id                                   as account_id,\n         a.valuation,\n         t.occurred_on                          as fecha,\n         c.amount                               as monto,\n         c.unit                                 as unidad,\n         -- a.fx_source, no el del libro: un CEDEAR se mide al CCL aunque el\n         -- resto de la aplicacion use MEP\n         convertir(c.amount, c.unit, t.occurred_on, 'USD', a.fx_source) as usd,\n         convertir(c.amount, c.unit, t.occurred_on, 'UVA', a.fx_source) as uva\n    from entry pe\n    join account a on a.id = pe.account_id\n                  and a.valuation in ('market', 'accrual')\n    join transaction t on t.id = pe.transaction_id\n    join entry c on c.transaction_id = pe.transaction_id\n                and c.account_id is not null\n                and c.account_id <> a.id","alter view flujo_inversion set (security_invoker = on)","grant select on flujo_inversion to authenticated","-- ---------------------------------------------------------------------------\n-- La valuacion, con la misma vara.\n-- Tiene que ser LA MISMA que la de los flujos: medir lo que pusiste con un dolar\n-- y lo que vale con otro daria un rendimiento inventado.\n-- ---------------------------------------------------------------------------\n\ndrop view if exists valor_inversion","create view valor_inversion as\n  select a.id            as account_id,\n         a.name,\n         a.valuation,\n         a.institution,\n         a.matures_on,\n         (a.archived_at is not null) as cerrada,\n         a.fx_source,\n         i.symbol,\n         i.kind,\n         i.quote_currency,\n         i.ratio,\n         i.underlying_symbol,\n         coalesce(sal.saldo, 0) as saldo,\n         v.valor_nativo,\n         case when a.valuation = 'market' then i.quote_currency else a.unit end as moneda,\n         pr.on_date as precio_al,\n         convertir(v.valor_nativo,\n                   case when a.valuation = 'market' then i.quote_currency else a.unit end,\n                   current_date, 'USD', a.fx_source) as usd,\n         convertir(v.valor_nativo,\n                   case when a.valuation = 'market' then i.quote_currency else a.unit end,\n                   current_date, 'UVA', a.fx_source) as uva\n    from account a\n    left join instrument i on i.id = a.instrument_id\n    left join lateral (\n      select sum(e.amount) as saldo from entry e where e.account_id = a.id\n    ) sal on true\n    left join lateral (\n      select p.price, p.on_date from price p\n       where p.instrument_id = a.instrument_id\n       order by p.on_date desc limit 1\n    ) pr on true\n    left join lateral (\n      select case\n               when coalesce(sal.saldo, 0) = 0 then 0\n               when a.valuation = 'market'     then sal.saldo * pr.price\n               else sal.saldo\n             end as valor_nativo\n    ) v on true\n   where a.valuation in ('market', 'accrual')","alter view valor_inversion set (security_invoker = on)","grant select on valor_inversion to authenticated","-- ---------------------------------------------------------------------------\n-- Al comprar un CEDEAR, la cuenta nace midiendose al CCL.\n-- Es lo correcto por defecto y se puede cambiar despues: es una propiedad de la\n-- cuenta, no una regla del sistema.\n-- ---------------------------------------------------------------------------\n\n-- OJO: agregar un parametro -aunque tenga valor por defecto- NO reemplaza la\n-- funcion, crea una SOBRECARGA. Las dos quedan vivas y toda llamada con la\n-- cantidad vieja de argumentos se vuelve ambigua. Hay que borrar la anterior.\ndrop function if exists comprar_activo(text, text, text, text, int, uuid, numeric, numeric, text, date)","create or replace function comprar_activo(\n  p_symbol   text,\n  p_nombre   text,\n  p_kind     text,\n  p_moneda   text,\n  p_decimals int,\n  p_desde    uuid,\n  p_monto    numeric,\n  p_unidades numeric,\n  p_broker   text default null,\n  p_on       date default null,\n  p_ratio    numeric default null,   -- cuantos CEDEARs equivalen a una accion\n  p_subyacente text default null     -- el simbolo de esa accion\n) returns uuid\nlanguage plpgsql\nsecurity invoker\nset search_path = public, pg_temp\nas $$\ndeclare\n  v_ledger uuid := my_ledger();\n  v_origen account%rowtype;\n  v_inst   uuid;\n  v_pos    uuid;\n  v_tx     uuid;\n  v_fecha  date := coalesce(p_on, current_date);\n  v_fuente text;\nbegin\n  if p_monto is null or p_monto <= 0 then raise exception 'El monto tiene que ser mayor que cero'; end if;\n  if p_unidades is null or p_unidades <= 0 then raise exception 'Las unidades tienen que ser mayores que cero'; end if;\n\n  select * into v_origen from account where id = p_desde;\n  if not found then raise exception 'No existe la cuenta de origen'; end if;\n\n  select id into v_inst from instrument\n   where ledger_id = v_ledger and symbol = upper(trim(p_symbol));\n  if v_inst is null then\n    insert into instrument (ledger_id, symbol, name, kind, quote_currency, decimals,\n                            ratio, underlying_symbol)\n         values (v_ledger, upper(trim(p_symbol)), p_nombre, p_kind, p_moneda, p_decimals,\n                 p_ratio, nullif(upper(trim(coalesce(p_subyacente,''))), ''))\n      returning id into v_inst;\n  end if;\n\n  -- Un CEDEAR lleva el CCL adentro de su precio: medirlo con ese mismo dolar es\n  -- lo que aisla el rendimiento de la accion del movimiento del tipo de cambio.\n  v_fuente := case when p_kind = 'cedear' then 'ccl' else null end;\n\n  select id into v_pos from account\n   where ledger_id = v_ledger and instrument_id = v_inst and archived_at is null;\n  if v_pos is null then\n    insert into account (ledger_id, name, kind, valuation, unit, instrument_id,\n                         is_spendable, institution, fx_source)\n         values (v_ledger,\n                 coalesce(p_broker || ' · ', '') || upper(trim(p_symbol)),\n                 'asset', 'market', upper(trim(p_symbol)), v_inst,\n                 false, coalesce(p_broker, v_origen.institution), v_fuente)\n      returning id into v_pos;\n  end if;\n\n  insert into transaction (ledger_id, occurred_on, description, kind, created_by)\n       values (v_ledger, v_fecha, 'Compra de ' || upper(trim(p_symbol)), 'trade', auth.uid())\n    returning id into v_tx;\n\n  insert into entry (transaction_id, ledger_id, account_id, amount, unit) values\n    (v_tx, v_ledger, p_desde, -p_monto,    v_origen.unit),\n    (v_tx, v_ledger, v_pos,    p_unidades, upper(trim(p_symbol)));\n\n  return v_pos;\nend $$","grant execute on function comprar_activo(text, text, text, text, int, uuid, numeric, numeric, text, date, numeric, text) to authenticated","-- La lista de posiciones tambien dice con que dolar se mide cada una: sin eso la\n-- pantalla no puede cumplir ADR-011, que exige decir con que vara se midio.\ndrop view if exists posicion","create view posicion as\n  select a.id           as account_id,\n         a.ledger_id,\n         a.name,\n         a.institution,\n         a.fx_source,\n         i.id           as instrument_id,\n         i.symbol,\n         i.name         as instrument_name,\n         i.kind,\n         i.quote_currency,\n         i.decimals,\n         i.ratio,\n         i.underlying_symbol,\n         coalesce(u.unidades, 0)                as unidades,\n         p.price                                as precio,\n         p.on_date                              as precio_al,\n         p.source                               as precio_fuente,\n         coalesce(u.unidades, 0) * p.price      as valor,\n         coalesce(f.invertido, 0)               as invertido,\n         coalesce(u.unidades, 0) * p.price - coalesce(f.invertido, 0) as ganancia\n    from account a\n    join instrument i on i.id = a.instrument_id\n    left join lateral (\n      select sum(e.amount) as unidades from entry e where e.account_id = a.id\n    ) u on true\n    left join lateral (\n      select -sum(c.amount) as invertido\n        from entry pe\n        join entry c on c.transaction_id = pe.transaction_id\n                    and c.account_id is not null\n                    and c.account_id <> a.id\n       where pe.account_id = a.id\n    ) f on true\n    left join lateral (\n      select pr.price, pr.on_date, pr.source\n        from price pr where pr.instrument_id = i.id\n       order by pr.on_date desc limit 1\n    ) p on true\n   where a.valuation = 'market'\n     and a.archived_at is null","alter view posicion set (security_invoker = on)","grant select on posicion to authenticated"}	cedears
20260916180000	{"-- Saca de la base lo que ADR-023 dejo sin uso.\n--\n-- `20260916140000_cotizaciones.sql` fue la primera version de la medicion: creaba\n-- `en_usd()` y `cotizacion_faltante`. El mismo dia, ADR-023 generalizo la idea -la\n-- unidad de medida es apenas un divisor- y esos dos objetos quedaron reemplazados\n-- por `convertir()` y `medicion_faltante`. Nadie en el repositorio los nombra.\n--\n-- Ademas ese archivo compartia timestamp con `..._medicion.sql`, y dos migraciones\n-- con la misma version es una bomba de tiempo: el orden pasa a depender del orden\n-- alfabetico del nombre, que hoy da bien de pura casualidad. Se borro el archivo.\n--\n-- Estos DROP son por si en alguna base llego a aplicarse antes de borrarse. Si\n-- nunca existieron, no hacen nada: para eso esta el `if exists`.\n\ndrop view if exists cotizacion_faltante","drop function if exists en_usd(numeric, text, date, text)"}	limpieza
20260916190000	{"-- `underlying_symbol` dejo de ser un dato informativo.\n--\n-- Nacio como \\"previsto, sin usar\\" (OD-17). ADR-024 lo dejo fuera de la cuenta\n-- del rendimiento -medir al CCL no lo necesita- y eso sigue siendo cierto. Pero\n-- ADR-025 le dio un segundo papel: es el simbolo con el que se le pide el precio\n-- a la fuente. Un CEDEAR se llama \\"AAPL-CEDEAR\\" en tu libro y \\"AAPL\\" en BYMA.\n--\n-- La consecuencia incomoda: un CEDEAR sin este campo NO recibe precio automatico\n-- y nada se rompe -simplemente se queda quieto, que es la peor forma de fallar-.\n-- Por eso queda dicho en la base y no solo en un formulario.\n\ncomment on column instrument.underlying_symbol is\n  'El simbolo del activo en la fuente de precios. Para un CEDEAR es la accion '\n  'que representa (AAPL), que es como lo publica BYMA. Sin esto no hay precio '\n  'automatico: ADR-025.'","comment on column instrument.ratio is\n  'Cuantos CEDEARs equivalen a una accion. Informativo: ADR-024 mide al CCL, y '\n  'esa division no necesita el ratio.'"}	llave_de_precio
20260916200000	{"-- El portafolio es el BORDE — ADR-026.\n--\n-- Hasta acá el rendimiento se medía por posición: `flujo_inversion` solo miraba\n-- cuentas `market` y `accrual`. Eso tiene tres agujeros, y los tres son el mismo:\n--\n--   1. El efectivo quieto en el broker no existía. Vendías ETH, dejabas los\n--      dólares ahí, y el portafolio marcaba cero.\n--   2. La plata depositada que espera no penalizaba. El aporte se fechaba en la\n--      COMPRA, no en el depósito, así que los meses ociosos no aparecían y el\n--      rendimiento salía mejor de lo que fue.\n--   3. Comprar adentro contaba como aporte nuevo, cuando es la misma plata\n--      cambiando de forma.\n--\n-- Con el portafolio como borde, una sola condición los cierra a los tres: es\n-- flujo solo lo que tiene la contraparte AFUERA.\n\ncreate table portfolio (\n  id          uuid primary key default gen_random_uuid(),\n  ledger_id   uuid not null default my_ledger() references ledger(id) on delete cascade,\n  name        text not null,\n  -- Con qué dólar se mide TODO lo de adentro, salvo que una cuenta diga otra\n  -- cosa. Balanz al CCL, Binance al cripto. Null = el del libro.\n  fx_source   text,\n  archived_at timestamptz,\n  created_at  timestamptz not null default now(),\n  unique (ledger_id, name),\n  unique (id, ledger_id)           -- habilita la clave foranea compuesta de abajo\n)","-- Pertenecer a un portafolio es OPCIONAL y esa es la diferencia con agrupar por\n-- institución: tu cuenta remunerada de Mercado Pago no tiene por qué entrar,\n-- aunque Mercado Pago también sea una institución. ADR-013 ya había decidido que\n-- una cuenta remunerada es un banco, no una inversión.\nalter table account add column portfolio_id uuid","-- Compuesta contra (id, ledger_id): garantiza en el esquema que una cuenta no\n-- pueda apuntar a un portafolio de OTRO libro. Sin triggers.\nalter table account add constraint account_portfolio_fk\n  foreign key (portfolio_id, ledger_id) references portfolio(id, ledger_id)\n  on delete set null","create index account_portfolio_idx on account (portfolio_id) where portfolio_id is not null","alter table portfolio enable row level security","alter table portfolio force row level security","create policy portfolio_member_rw on portfolio for all to authenticated\n  using      (ledger_id in (select my_ledgers()))\n  with check (ledger_id in (select my_ledgers()))","grant select, insert, update, delete on portfolio to authenticated","-- ---------------------------------------------------------------------------\n-- Cuánto vale UNA cuenta, la que sea.\n--\n-- `valor_inversion` sabía valuar posiciones y plazos fijos, pero no el efectivo.\n-- Ahora hay UNA sola definición de \\"cuánto vale una cuenta\\" y valor_inversion\n-- pasa a ser un recorte de ella. La lección ya apareció tres veces en este\n-- proyecto: cuando algo se define en seis lugares, los seis dejan de coincidir.\n-- ---------------------------------------------------------------------------\n\ndrop view if exists valor_inversion","create view valor_cuenta as\n  select a.id            as account_id,\n         a.ledger_id,\n         a.portfolio_id,\n         a.name,\n         a.kind          as account_kind,\n         a.valuation,\n         a.unit,\n         a.institution,\n         a.matures_on,\n         (a.archived_at is not null) as cerrada,\n         -- La cuenta manda sobre el portafolio, y el portafolio sobre el libro.\n         coalesce(a.fx_source, pf.fx_source) as fx_source,\n         i.symbol,\n         i.kind          as kind,\n         i.quote_currency,\n         i.ratio,\n         i.underlying_symbol,\n         coalesce(sal.saldo, 0) as saldo,\n         v.valor_nativo,\n         case when a.valuation = 'market' then i.quote_currency else a.unit end as moneda,\n         pr.on_date as precio_al,\n         convertir(v.valor_nativo,\n                   case when a.valuation = 'market' then i.quote_currency else a.unit end,\n                   current_date, 'USD', coalesce(a.fx_source, pf.fx_source)) as usd,\n         convertir(v.valor_nativo,\n                   case when a.valuation = 'market' then i.quote_currency else a.unit end,\n                   current_date, 'UVA', coalesce(a.fx_source, pf.fx_source)) as uva\n    from account a\n    left join portfolio pf on pf.id = a.portfolio_id\n    left join instrument i on i.id = a.instrument_id\n    left join lateral (\n      select sum(e.amount) as saldo from entry e where e.account_id = a.id\n    ) sal on true\n    left join lateral (\n      select p.price, p.on_date from price p\n       where p.instrument_id = a.instrument_id\n       order by p.on_date desc limit 1\n    ) pr on true\n    left join lateral (\n      select case\n               -- Saldo cero vale cero sin necesitar precio: una posición cerrada\n               -- no deja de existir por no tener cotización.\n               when coalesce(sal.saldo, 0) = 0 then 0\n               when a.valuation = 'market'     then sal.saldo * pr.price\n               else sal.saldo\n             end as valor_nativo\n    ) v on true","alter view valor_cuenta set (security_invoker = on)","grant select on valor_cuenta to authenticated","create view valor_inversion as\n  select * from valor_cuenta where valuation in ('market', 'accrual')","alter view valor_inversion set (security_invoker = on)","grant select on valor_inversion to authenticated","-- ---------------------------------------------------------------------------\n-- Cuánto vale un portafolio entero: posiciones MÁS efectivo quieto.\n--\n-- `sin_valuar` no es decorativo: sum() ignora los nulos, así que una posición\n-- sin precio desaparecería del total sin dejar rastro y el número se vería\n-- completo. La pantalla tiene que poder decir \\"no incluye 2 posiciones\\".\n-- ---------------------------------------------------------------------------\n\ncreate view valor_portafolio as\n  select p.id          as portfolio_id,\n         p.ledger_id,\n         p.name,\n         p.fx_source,\n         (p.archived_at is not null) as cerrado,\n         count(v.account_id)                                  as cuentas,\n         count(*) filter (where v.usd is null\n                            and v.account_id is not null)     as sin_valuar,\n         sum(v.usd)                                           as usd,\n         sum(v.uva)                                           as uva\n    from portfolio p\n    left join valor_cuenta v on v.portfolio_id = p.id\n   group by p.id, p.ledger_id, p.name, p.fx_source, p.archived_at","alter view valor_portafolio set (security_invoker = on)","grant select on valor_portafolio to authenticated","-- ---------------------------------------------------------------------------\n-- Qué cruzó el borde. LA vista de este ADR.\n--\n-- Se mide sobre la pata de AFUERA -igual que flujo_inversion- y no sobre la de\n-- adentro: cuando comprás un CEDEAR con pesos, lo que cruzó son los pesos, y los\n-- pesos se convierten a dólares con la cotización del día. Convertir la pata de\n-- adentro exigiría el precio del activo en esa fecha, que puede no existir.\n--\n-- Una contraparte con account_id NULL es una categoría, o sea un ingreso o un\n-- gasto: el interés que paga el broker NO es plata que aportaste, es rendimiento\n-- generado adentro. Por eso el join exige account_id not null.\n-- ---------------------------------------------------------------------------\n\ncreate view flujo_portafolio as\n  with participa as (\n    select distinct a.portfolio_id, e.transaction_id\n      from entry e\n      join account a on a.id = e.account_id\n     where a.portfolio_id is not null\n  )\n  select pa.portfolio_id,\n         t.occurred_on           as fecha,\n         c.unit                  as unidad,\n         sum(c.amount)           as monto,\n         convertir(sum(c.amount), c.unit, t.occurred_on, 'USD', pf.fx_source) as usd,\n         convertir(sum(c.amount), c.unit, t.occurred_on, 'UVA', pf.fx_source) as uva\n    from participa pa\n    join portfolio pf on pf.id = pa.portfolio_id\n    join transaction t on t.id = pa.transaction_id\n    join entry c on c.transaction_id = t.id\n                and c.account_id is not null\n    join account ca on ca.id = c.account_id\n   where ca.portfolio_id is distinct from pa.portfolio_id\n   group by pa.portfolio_id, t.id, t.occurred_on, c.unit, pf.fx_source","alter view flujo_portafolio set (security_invoker = on)","grant select on flujo_portafolio to authenticated","comment on view flujo_portafolio is\n  'Solo lo que cruza el borde del portafolio. Comprar adentro no es flujo: es la '\n  'misma plata cambiando de forma. ADR-026.'"}	portafolios
20260918100000	{"-- El alta deja de decidir por el usuario — ADR-027.\n--\n-- Sembraba 20 categorias y una cuenta \\"Efectivo ARS\\". La cuenta estaba ahi por\n-- una razon escrita y buena: el MVP se mide en que registrar un gasto lleve\n-- menos de diez segundos, y sin cuenta no se puede registrar nada.\n--\n-- Lo que se aprendio probandola con alguien que no la construyo: esas 20\n-- categorias no son un atajo, son una taxonomia ajena. Para cargar un cafe habia\n-- que leer doce opciones que nadie eligio.\n--\n-- LA DISTINCION: los padres son ESTRUCTURA, los hijos son OPINION.\n--\n--   'Gastos fijos' y 'Gastos variables' no son una preferencia: son la\n--   correccion del error 2 del analisis -la planilla mezclaba el TIPO de\n--   operacion con el CONCEPTO- y sin ellos el modelo no se entiende.\n--\n--   'Restaurantes' o 'Donaciones' son gustos de quien escribio esto metidos en\n--   el libro de otra persona.\n--\n-- 'Intereses' y 'Ajustes' se quedan y no son negociables: ADR-013, ADR-014 y\n-- ADR-005 dependen de que existan. Sin ellas el interes de una cuenta remunerada\n-- y el ajuste de saldo no tienen adonde ir.\n--\n-- Y la cuenta se va: no se puede registrar un gasto sin decir de donde salio,\n-- asi que preguntarlo UNA vez es mas honesto que inventar una respuesta. La\n-- puesta en marcha se encarga, y es la primera pantalla.\n\ncreate or replace function handle_new_user() returns trigger\nlanguage plpgsql\nsecurity definer\nset search_path = public, pg_temp\nas $$\ndeclare\n  v_ledger uuid;\nbegin\n  insert into ledger (name) values ('Personal') returning id into v_ledger;\n  insert into ledger_member (ledger_id, user_id, role) values (v_ledger, new.id, 'owner');\n\n  insert into category (ledger_id, name, kind, is_system, sort_order) values\n    (v_ledger, 'Sueldo',         'income',  false, 10),\n    (v_ledger, 'Intereses',      'income',  true,  20),   -- ADR-013, ADR-014\n    (v_ledger, 'Otros ingresos', 'income',  false, 30),\n    (v_ledger, 'Gastos fijos',   'expense', false, 10),\n    (v_ledger, 'Gastos variables','expense', false, 20),\n    (v_ledger, 'Ajustes',        'expense', true,  90);   -- ADR-005\n\n  -- NO se siembran \\"Ahorros\\" ni \\"Inversiones\\": son CUENTAS (ADR-012). Sembrarlas\n  -- reintroduciria el error 1, que restaba el ahorro del resultado del mes.\n  --\n  -- NO se siembra ninguna cuenta: lo hace la puesta en marcha.\n\n  return new;\nend $$"}	alta_minima
20260918110000	{"-- Una categoria madre tambien \\"usa\\" los movimientos de sus hijas.\n--\n-- `category_usage.movimientos` contaba solo las lineas imputadas a ESA categoria.\n-- Como a una madre casi nunca se le imputa nada directo, \\"Gastos fijos\\" marcaba\n-- CERO aunque abajo tuviera cientos de movimientos. La pantalla entonces ofrecia\n-- \\"Borrar\\", y la base lo rechazaba por la clave foranea de las hijas: el boton\n-- fallaba exitosamente.\n--\n-- Hay DOS motivos distintos por los que una madre no se puede borrar, y la\n-- pantalla necesita poder distinguirlos para decir cual:\n--   - tiene movimientos abajo  -> se archiva, no se borra\n--   - tiene hijas              -> primero hay que vaciarla\n--\n-- El arbol es de dos niveles como maximo (lo impone el invariante que rechaza el\n-- tercer nivel), asi que alcanza con mirar una generacion: no hace falta un CTE\n-- recursivo ni el costo de mantenerlo.\n\ndrop view if exists category_usage","create view category_usage as\n  select c.id  as category_id,\n         c.ledger_id,\n         c.name,\n         c.kind,\n         c.parent_id,\n         c.is_system,\n         c.sort_order,\n         coalesce(propio.n, 0)                        as movimientos,\n         coalesce(propio.n, 0) + coalesce(abajo.n, 0) as movimientos_arbol,\n         coalesce(abajo.hijas, 0)                     as hijas\n    from category c\n    left join lateral (\n      select count(*) as n from entry e where e.category_id = c.id\n    ) propio on true\n    left join lateral (\n      select count(*) filter (where e.id is not null) as n,\n             count(distinct h.id)                     as hijas\n        from category h\n        left join entry e on e.category_id = h.id\n       where h.parent_id = c.id and h.archived_at is null\n    ) abajo on true\n   where c.archived_at is null","alter view category_usage set (security_invoker = on)","grant select on category_usage to authenticated","comment on view category_usage is\n  'movimientos = lo imputado a ella. movimientos_arbol = con sus hijas incluidas, '\n  'que es lo que decide si se puede borrar. hijas = por que a veces no se puede '\n  'aunque no haya un solo movimiento.'"}	uso_arbol
20260918120000	{"-- \\"Ajustes\\" se llamaba igual que el menu de configuracion de cualquier app — OD-35.\n--\n-- La primera persona ajena al proyecto que uso kipo vio, en la pantalla principal,\n-- una palabra que conocia con OTRO significado. El codigo busca esta categoria por\n-- lo que ES (is_system + kind) y nunca por su nombre, asi que renombrarla es\n-- seguro: eso ya estaba previsto desde que se permitio renombrarlas.\n--\n-- Solo aplica a las altas nuevas. Los libros que ya existen conservan el nombre\n-- que tengan, y se puede cambiar desde la pantalla de categorias.\n--\n-- NOTA para el proximo que agregue una columna a una vista: `account_balance` YA\n-- expone `institution` desde 20260916100000_uso.sql. La primera version de esta\n-- migracion la \\"agregaba\\" recreando la vista desde su definicion ORIGINAL, y en\n-- el camino borraba `movimientos`, que esa misma migracion habia agregado. Las\n-- migraciones son acumulativas: la definicion vigente es la ULTIMA, no la primera.\n-- Lo atrapo el test 07, que consulta esa columna.\n\ncreate or replace function handle_new_user() returns trigger\nlanguage plpgsql\nsecurity definer\nset search_path = public, pg_temp\nas $$\ndeclare\n  v_ledger uuid;\nbegin\n  insert into ledger (name) values ('Personal') returning id into v_ledger;\n  insert into ledger_member (ledger_id, user_id, role) values (v_ledger, new.id, 'owner');\n\n  insert into category (ledger_id, name, kind, is_system, sort_order) values\n    (v_ledger, 'Sueldo',           'income',  false, 10),\n    (v_ledger, 'Intereses',        'income',  true,  20),   -- ADR-013, ADR-014\n    (v_ledger, 'Otros ingresos',   'income',  false, 30),\n    (v_ledger, 'Gastos fijos',     'expense', false, 10),\n    (v_ledger, 'Gastos variables', 'expense', false, 20),\n    (v_ledger, 'Ajuste de saldo',  'expense', true,  90);   -- ADR-005\n\n  return new;\nend $$"}	institucion
20260918130000	{"-- \\"Fin de mes\\" es una REGLA, no una fecha — OD-38.\n--\n-- Verificado contra PostgreSQL 16 el 2026-09-18:\n--\n--   31-ene + 1 mes = 2026-02-28\n--   28-feb + 1 mes = 2026-03-28\n--   28-mar + 1 mes = 2026-04-28\n--\n-- Un vencimiento a fin de mes se degrada al 28 en febrero y NO VUELVE NUNCA. Un\n-- atajo de interfaz que solo escribiera la fecha seria mentira desde el segundo\n-- mes, y de la peor manera: sin fallar.\n--\n-- POR QUE UNA BANDERA Y NO ADIVINARLO: si la fecha es 28-feb no hay forma de\n-- saber si alguien quiso \\"el 28\\" o \\"el ultimo dia\\" — febrero es justo donde las\n-- dos lecturas coinciden. Solo lo sabe quien lo cargo.\n--\n-- POR QUE UN TRIGGER Y NO TOCAR LAS FUNCIONES: `next_on` lo adelantan hoy dos\n-- funciones distintas (registrar una ocurrencia y saltear un periodo) y maniana\n-- podria hacerlo una tercera. Con el trigger la regla vale para todas, incluido\n-- un UPDATE a mano desde el panel. Reescribir las dos funciones habria dejado el\n-- invariante dependiendo de que nadie se olvide.\n\nalter table scheduled_event\n  add column month_end boolean not null default false","comment on column scheduled_event.month_end is\n  'true = vence el ULTIMO dia del mes, sea 28, 30 o 31. Sin esto la fecha se '\n  'degrada al 28 tras el primer febrero y no vuelve. OD-38.'","create or replace function ajustar_fin_de_mes() returns trigger\nlanguage plpgsql\nset search_path = public, pg_temp\nas $$\nbegin\n  if new.month_end then\n    new.next_on := (date_trunc('month', new.next_on) + interval '1 month - 1 day')::date;\n  end if;\n  return new;\nend $$","create trigger scheduled_event_fin_de_mes\n  before insert or update of next_on, month_end on scheduled_event\n  for each row execute function ajustar_fin_de_mes()","comment on function ajustar_fin_de_mes() is\n  'Lleva next_on al ultimo dia de su mes cuando la regla es de fin de mes. '\n  'Corre en INSERT y en cada UPDATE de next_on, asi ninguna funcion que adelante '\n  'la agenda necesita acordarse. OD-38.'"}	fin_de_mes
20260918140000	{"-- Cuantas cuotas y cuando caen — OD-23.\n--\n-- LO QUE NO SE HACE, Y POR QUE. El registro decia que una cuota futura \\"entra\n-- gratis en scheduled_event\\". No entra: un `scheduled_event` es algo que va a\n-- pasar y que vas a REGISTRAR, y registrarlo crea un movimiento. Una cuota no es\n-- eso. La compra en cuotas YA se registro entera el dia 1 contra la tarjeta\n-- (ADR-004): la deuda esta completa desde el primer momento. Agendar las cuotas\n-- como eventos contaria el gasto una vez por cuota.\n--\n-- Lo que falta no es agendar: es PROYECTAR. El saldo de la tarjeta dice cuanto\n-- debes; lo que no dice es CUANDO, y con dos o tres compras en cuotas se vuelve\n-- imposible anticipar el resumen del mes que viene.\n--\n-- Por eso alcanza con UN dato -en cuantas cuotas fue- y todo lo demas se deriva.\n-- El mes de la primera cuota no se pregunta: una compra con tarjeta cae en el\n-- resumen del mes siguiente. Preguntarlo seria friccion para precisar un dia que\n-- el modelo igual no usa, porque la proyeccion es por MES.\n\nalter table transaction\n  add column installments int\n  check (installments is null or installments between 2 and 60)","comment on column transaction.installments is\n  'En cuantas cuotas se pago. null = de una. No cambia la contabilidad -la deuda '\n  'ya esta entera desde el dia 1- solo permite proyectar cuando cae. OD-23.'","-- ---------------------------------------------------------------------------\n-- Una fila por cuota: que tarjeta, que mes, cuanto.\n--\n-- Se expande con generate_series en vez de guardar N filas: son datos derivados\n-- de dos columnas y guardarlos abriria la puerta a que discrepen del movimiento\n-- que los origino.\n-- ---------------------------------------------------------------------------\n\ncreate view cuota as\n  select t.id                     as transaction_id,\n         t.ledger_id,\n         t.description,\n         t.occurred_on            as comprado_el,\n         a.id                     as account_id,\n         a.name                   as tarjeta,\n         n                        as numero,\n         t.installments           as total,\n         -- La primera cuota cae en el resumen del mes SIGUIENTE a la compra.\n         (date_trunc('month', t.occurred_on) + (n || ' month')::interval)::date as mes,\n         round(abs(e.amount) / t.installments, 2) as monto,\n         e.unit\n    from transaction t\n    join entry e on e.transaction_id = t.id\n                and e.account_id is not null\n    join account a on a.id = e.account_id\n                  and a.kind = 'liability'\n    cross join generate_series(1, t.installments) as n\n   where t.installments is not null","alter view cuota set (security_invoker = on)","grant select on cuota to authenticated","-- ---------------------------------------------------------------------------\n-- Lo que de verdad se queria: cuanto va a venir en cada resumen.\n-- ---------------------------------------------------------------------------\n\ncreate view resumen_tarjeta as\n  select account_id,\n         tarjeta,\n         ledger_id,\n         mes,\n         unit,\n         sum(monto)  as total,\n         count(*)    as cuotas\n    from cuota\n   where mes >= date_trunc('month', current_date)\n   group by account_id, tarjeta, ledger_id, mes, unit","alter view resumen_tarjeta set (security_invoker = on)","grant select on resumen_tarjeta to authenticated","comment on view resumen_tarjeta is\n  'Lo que cae en cada resumen futuro por compras en cuotas. NO incluye los '\n  'consumos de una sola cuota: esos ya estan en el saldo y se pagan enseguida.'","-- ---------------------------------------------------------------------------\n-- El cliente necesita poder decirlo al registrar.\n--\n-- Es la MISMA funcion de 20260915110000_rpc.sql con un parametro mas: se copio\n-- entera a proposito, porque reescribirla de memoria habria perdido la\n-- validacion de las dos lineas y el comentario sobre la atomicidad diferida.\n--\n-- Y el `drop` explicito porque agregar un parametro con valor por defecto NO\n-- reemplaza la funcion: crea una sobrecarga y las llamadas de cuatro argumentos\n-- quedan ambiguas. Ya paso con comprar_activo.\n-- ---------------------------------------------------------------------------\n\ndrop function if exists create_transaction(date, text, jsonb, text)","create or replace function create_transaction(\n  p_occurred_on  date,\n  p_kind         text,\n  p_entries      jsonb,      -- [{account_id|category_id, amount, unit}, ...]\n  p_description  text default null,\n  p_installments int default null\n) returns uuid\nlanguage plpgsql\nsecurity invoker\nset search_path = public, pg_temp\nas $$\ndeclare\n  v_ledger uuid := my_ledger();\n  v_tx     uuid;\n  v_n      int;\nbegin\n  if v_ledger is null then\n    raise exception 'El usuario no pertenece a ningun libro';\n  end if;\n\n  v_n := jsonb_array_length(p_entries);\n  if v_n is null or v_n < 2 then\n    raise exception 'Un movimiento necesita al menos dos lineas (recibio %)', coalesce(v_n, 0);\n  end if;\n\n  insert into transaction (ledger_id, occurred_on, description, kind, created_by, installments)\n       values (v_ledger, p_occurred_on, nullif(trim(p_description), ''), p_kind, auth.uid(),\n               p_installments)\n    returning id into v_tx;\n\n  insert into entry (transaction_id, ledger_id, account_id, category_id, amount, unit)\n  select v_tx,\n         v_ledger,\n         nullif(e->>'account_id', '')::uuid,\n         nullif(e->>'category_id', '')::uuid,\n         (e->>'amount')::numeric,\n         e->>'unit'\n    from jsonb_array_elements(p_entries) e;\n\n  -- Al salir de la funcion se confirma la transaccion de base y recien ahi dispara\n  -- el trigger diferido de ADR-010. Si no balancea, no queda NADA: ni el movimiento\n  -- ni las lineas. Esa es la atomicidad que se buscaba.\n  return v_tx;\nend $$","grant execute on function create_transaction(date, text, jsonb, text, int) to authenticated"}	cuotas
20260918150000	{"-- Compartir un libro, y el concepto que faltaba para que eso no rompa nada.\n-- ADR-028 / OD-36.\n--\n-- EL PROBLEMA REAL, verificado antes de escribir una linea:\n--\n--   create function my_ledger() as $$ select * from my_ledgers() limit 1 $$;\n--   create policy ... using (ledger_id in (select my_ledgers()))\n--\n-- El dia que alguien perteneciera a dos libros, SIN CAMBIAR NADA:\n--   1. toda lectura mostraria los dos libros MEZCLADOS -la politica filtra por\n--      \\"alguno de los tuyos\\", no por \\"el que estas mirando\\"-, y\n--   2. toda escritura iria a uno arbitrario: `limit 1` sin `order by`.\n--\n-- Asi que lo que faltaba no era una pantalla de invitaciones: era el concepto de\n-- LIBRO ACTIVO. Y vive en la base, no en el cliente, por la misma razon de\n-- ADR-003: si cada consulta tuviera que acordarse de filtrar, alcanza con\n-- olvidarse en una para volver a mezclar, y consultas nuevas se escriben siempre.\n\ncreate table active_ledger (\n  user_id   uuid primary key references auth.users(id) on delete cascade,\n  ledger_id uuid not null references ledger(id) on delete cascade,\n  set_at    timestamptz not null default now()\n)","alter table active_ledger enable row level security","alter table active_ledger force row level security","-- La politica NO puede llamar a my_ledger(): my_ledger() lee esta tabla.\ncreate policy active_ledger_self on active_ledger for all to authenticated\n  using (user_id = auth.uid()) with check (user_id = auth.uid())","grant select on active_ledger to authenticated","-- ---------------------------------------------------------------------------\n-- Cual es el libro que estoy mirando.\n--\n-- SECURITY DEFINER porque lo llaman las politicas de RLS de todas las tablas: si\n-- fuera invoker, leer `active_ledger` disparia su propia politica y entraria en\n-- recursion.\n--\n-- El respaldo tiene ORDER BY a proposito. El original decia `limit 1` a secas y\n-- eso no es \\"el primero\\": es cualquiera, y podia cambiar entre dos consultas.\n-- ---------------------------------------------------------------------------\n\ncreate or replace function my_ledger() returns uuid\nlanguage sql\nstable\nsecurity definer\nset search_path = public, pg_temp\nas $$\n  select coalesce(\n    -- el elegido, siempre que siga siendo mio\n    (select a.ledger_id\n       from active_ledger a\n       join ledger_member m on m.ledger_id = a.ledger_id and m.user_id = a.user_id\n      where a.user_id = auth.uid()),\n    -- si no eligio ninguno, el primero al que entro. Determinista.\n    (select m.ledger_id from ledger_member m\n      where m.user_id = auth.uid()\n      order by m.joined_at, m.ledger_id\n      limit 1)\n  )\n$$","grant execute on function my_ledger() to authenticated","/** Que soy en el libro que estoy mirando: 'owner' o 'member'. */\ncreate or replace function mi_rol() returns text\nlanguage sql\nstable\nsecurity definer\nset search_path = public, pg_temp\nas $$\n  select m.role from ledger_member m\n   where m.user_id = auth.uid() and m.ledger_id = my_ledger()\n$$","grant execute on function mi_rol() to authenticated","-- ---------------------------------------------------------------------------\n-- RLS: de \\"alguno de los tuyos\\" a \\"el que estas mirando\\".\n--\n-- Y la linea de los permisos, que decidio el usuario: un invitado carga y borra\n-- MOVIMIENTOS, pero no toca la ESTRUCTURA. La linea esta donde duele el error —\n-- un movimiento mal cargado se corrige, una cuenta borrada se lleva su historia.\n-- ---------------------------------------------------------------------------\n\ndo $$\ndeclare t text;\nbegin\n  -- Datos del dia a dia: cualquier miembro.\n  foreach t in array array['transaction','entry','budget','scheduled_event','price','fx_rate'] loop\n    execute format('drop policy if exists %1$I_member_rw on %1$I', t);\n    execute format($p$\n      create policy %1$I_activo_rw on %1$I for all to authenticated\n        using      (ledger_id = my_ledger())\n        with check (ledger_id = my_ledger())\n    $p$, t);\n  end loop;\n\n  -- Estructura: todos la ven, solo el duenio la cambia.\n  foreach t in array array['account','category','instrument'] loop\n    execute format('drop policy if exists %1$I_member_rw on %1$I', t);\n    execute format($p$\n      create policy %1$I_activo_ro on %1$I for select to authenticated\n        using (ledger_id = my_ledger())\n    $p$, t);\n    execute format($p$\n      create policy %1$I_activo_rw on %1$I for insert to authenticated\n        with check (ledger_id = my_ledger() and mi_rol() = 'owner')\n    $p$, t);\n    execute format($p$\n      create policy %1$I_activo_up on %1$I for update to authenticated\n        using      (ledger_id = my_ledger() and mi_rol() = 'owner')\n        with check (ledger_id = my_ledger() and mi_rol() = 'owner')\n    $p$, t);\n    execute format($p$\n      create policy %1$I_activo_del on %1$I for delete to authenticated\n        using (ledger_id = my_ledger() and mi_rol() = 'owner')\n    $p$, t);\n  end loop;\nend $$","-- El libro y sus miembros: se ven los propios, pero solo el duenio suma o saca.\ndrop policy if exists ledger_member_rw on ledger","create policy ledger_activo on ledger for select to authenticated\n  using (id in (select my_ledgers()))","drop policy if exists ledger_member_self on ledger_member","create policy ledger_member_ver on ledger_member for select to authenticated\n  using (ledger_id in (select my_ledgers()))","create policy ledger_member_admin on ledger_member for all to authenticated\n  using      (ledger_id = my_ledger() and mi_rol() = 'owner')\n  with check (ledger_id = my_ledger() and mi_rol() = 'owner')","-- ---------------------------------------------------------------------------\n-- Invitaciones por codigo, no por correo.\n--\n-- Buscar a alguien por su correo exigiria una funcion que diga si ese correo\n-- esta registrado, y eso es un enumerador de usuarios. Con un codigo no hace\n-- falta saber nada del otro: se lo pasas por donde quieras.\n--\n-- La tabla NO tiene grants para `authenticated`: si se pudiera leer, se podrian\n-- listar los codigos vigentes. Se toca solo por las dos funciones de abajo.\n-- ---------------------------------------------------------------------------\n\ncreate table ledger_invite (\n  code       text primary key,\n  ledger_id  uuid not null references ledger(id) on delete cascade,\n  role       text not null default 'member' check (role in ('owner','member')),\n  created_by uuid not null references auth.users(id),\n  created_at timestamptz not null default now(),\n  expires_at timestamptz not null default now() + interval '7 days',\n  used_by    uuid references auth.users(id),\n  used_at    timestamptz\n)","alter table ledger_invite enable row level security","alter table ledger_invite force row level security","-- Sin politicas ni grants: nadie llega por el Data API. A proposito (ADR-020).\n\ncreate or replace function crear_invitacion(p_role text default 'member')\nreturns text\nlanguage plpgsql\nsecurity definer\nset search_path = public, pg_temp\nas $$\ndeclare\n  v_libro  uuid := my_ledger();\n  v_codigo text;\nbegin\n  if mi_rol() is distinct from 'owner' then\n    raise exception 'Solo quien creo el libro puede invitar';\n  end if;\n  if p_role not in ('owner','member') then\n    raise exception 'Rol invalido';\n  end if;\n\n  -- Ocho caracteres: suficiente con vencimiento y un solo uso, y corto como para\n  -- dictarlo por telefono sin equivocarse.\n  v_codigo := upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8));\n\n  insert into ledger_invite (code, ledger_id, role, created_by)\n  values (v_codigo, v_libro, p_role, auth.uid());\n\n  return v_codigo;\nend $$","grant execute on function crear_invitacion(text) to authenticated","create or replace function aceptar_invitacion(p_code text)\nreturns uuid\nlanguage plpgsql\nsecurity definer\nset search_path = public, pg_temp\nas $$\ndeclare\n  v_inv ledger_invite%rowtype;\nbegin\n  select * into v_inv from ledger_invite\n   where code = upper(trim(p_code)) for update;\n\n  -- El mismo mensaje para \\"no existe\\", \\"ya se uso\\" y \\"vencio\\": distinguirlos\n  -- convertiria esto en un oraculo para adivinar codigos.\n  if not found or v_inv.used_at is not null or v_inv.expires_at < now() then\n    raise exception 'Ese codigo no sirve: puede estar vencido o ya usado';\n  end if;\n\n  if exists (select 1 from ledger_member\n              where ledger_id = v_inv.ledger_id and user_id = auth.uid()) then\n    raise exception 'Ya formas parte de ese libro';\n  end if;\n\n  insert into ledger_member (ledger_id, user_id, role)\n  values (v_inv.ledger_id, auth.uid(), v_inv.role);\n\n  update ledger_invite set used_by = auth.uid(), used_at = now() where code = v_inv.code;\n\n  -- Entrar a un libro es querer verlo: se pasa a ser el activo.\n  insert into active_ledger (user_id, ledger_id) values (auth.uid(), v_inv.ledger_id)\n  on conflict (user_id) do update set ledger_id = excluded.ledger_id, set_at = now();\n\n  return v_inv.ledger_id;\nend $$","grant execute on function aceptar_invitacion(text) to authenticated","create or replace function cambiar_libro(p_ledger uuid)\nreturns void\nlanguage plpgsql\nsecurity definer\nset search_path = public, pg_temp\nas $$\nbegin\n  if not exists (select 1 from ledger_member\n                  where ledger_id = p_ledger and user_id = auth.uid()) then\n    raise exception 'Ese libro no es tuyo';\n  end if;\n\n  insert into active_ledger (user_id, ledger_id) values (auth.uid(), p_ledger)\n  on conflict (user_id) do update set ledger_id = excluded.ledger_id, set_at = now();\nend $$","grant execute on function cambiar_libro(uuid) to authenticated","-- ---------------------------------------------------------------------------\n-- Para el selector. Definer a proposito: ADR-020 le niega al cliente la tabla\n-- `ledger`, y esta vista le da exactamente lo que necesita y nada mas.\n-- ---------------------------------------------------------------------------\n\ncreate view mi_libro\nwith (security_invoker = off) as\n  select l.id                                   as ledger_id,\n         l.name,\n         m.role,\n         (l.id = my_ledger())                   as activo,\n         (select count(*) from ledger_member x where x.ledger_id = l.id) as miembros,\n         m.joined_at\n    from ledger l\n    join ledger_member m on m.ledger_id = l.id\n   where m.user_id = auth.uid()","grant select on mi_libro to authenticated","comment on view mi_libro is\n  'Los libros a los que pertenece quien pregunta, y cual esta mirando. Es lo '\n  'unico que la interfaz sabe del libro: ADR-003 sigue valiendo.'"}	libros_compartidos
20260918160000	{"-- Una sola definicion de \\"como nace un libro\\".\n--\n-- Estaba escrita DOS veces: en el trigger de alta y en reset_ledger.sql. Y ya\n-- habian discrepado: el reseteo seguia sembrando las veinte categorias viejas y\n-- la cuenta \\"Efectivo ARS\\" que ADR-027 saco. Quien usara el reseteo para probar\n-- \\"desde cero\\" habria probado un cero distinto del real.\n--\n-- Es la cuarta vez que este proyecto tropieza con lo mismo: cuando algo se\n-- define en dos lugares, los dos dejan de coincidir.\n\ncreate or replace function sembrar_libro(p_ledger uuid) returns void\nlanguage plpgsql\nsecurity definer\nset search_path = public, pg_temp\nas $$\nbegin\n  insert into category (ledger_id, name, kind, is_system, sort_order) values\n    (p_ledger, 'Sueldo',           'income',  false, 10),\n    (p_ledger, 'Intereses',        'income',  true,  20),   -- ADR-013, ADR-014\n    (p_ledger, 'Otros ingresos',   'income',  false, 30),\n    (p_ledger, 'Gastos fijos',     'expense', false, 10),\n    (p_ledger, 'Gastos variables', 'expense', false, 20),\n    (p_ledger, 'Ajuste de saldo',  'expense', true,  90);   -- ADR-005\n\n  -- NO se siembra ninguna cuenta ni ninguna hoja de categoria: lo pregunta la\n  -- puesta en marcha (ADR-027). Los padres son estructura; los hijos, opinion.\nend $$","comment on function sembrar_libro(uuid) is\n  'Lo minimo con lo que nace un libro. La usan el trigger de alta Y el reseteo, '\n  'para que no puedan discrepar.'","create or replace function handle_new_user() returns trigger\nlanguage plpgsql\nsecurity definer\nset search_path = public, pg_temp\nas $$\ndeclare\n  v_ledger uuid;\nbegin\n  insert into ledger (name) values ('Personal') returning id into v_ledger;\n  insert into ledger_member (ledger_id, user_id, role) values (v_ledger, new.id, 'owner');\n  perform sembrar_libro(v_ledger);\n  return new;\nend $$"}	sembrar_libro
20260918170000	{"-- Un bono no cotiza por unidad: cotiza por cada 100 nominales — OD-39.\n--\n-- Verificado el 2026-09-18 contra data912 con la cartera real del usuario:\n--\n--   AL30  -> 85100      no es el precio de UNO, es por 100 VN\n--   PN43O -> 165700     idem, una obligacion negociable\n--   YPFD  -> 8735       esto SI es por accion\n--\n-- Guardar 85100 como precio unitario haria que una tenencia de 10.000 nominales\n-- valiera CIEN VECES de mas. Y no fallaria: mostraria un patrimonio enorme y\n-- perfectamente creible.\n--\n-- Se arregla en el modelo y no en el script de precios a proposito. Si la\n-- division viviera en el script, quien cargue un precio A MANO escribiria el\n-- valor que ve en su broker -85100- y volveria a estar cien veces arriba. El\n-- precio se guarda TAL COMO SE COTIZA, y el instrumento dice a cuantas unidades\n-- corresponde.\n\nalter table instrument\n  add column quote_size numeric(38,18) not null default 1\n  check (quote_size > 0)","comment on column instrument.quote_size is\n  'A cuantas unidades corresponde el precio cotizado. 1 para acciones, CEDEARs y '\n  'cripto; 100 para bonos y obligaciones negociables, que cotizan por cada 100 '\n  'nominales. El valor de una posicion es saldo * precio / quote_size.'","-- Lo que ya existe: los bonos pasan a 100, el resto queda en 1.\nupdate instrument set quote_size = 100 where kind = 'bond'","-- ---------------------------------------------------------------------------\n-- Las dos vistas que multiplican por el precio tienen que dividir por la lamina.\n-- Se recrean COMPLETAS desde su ultima version -20260916200000_portafolios.sql y\n-- 20260916170000_cedears.sql-, no desde la primera: ya me equivoque una vez\n-- recreando account_balance desde su definicion original y borre una columna.\n-- ---------------------------------------------------------------------------\n\n-- valor_portafolio cuelga de valor_cuenta, asi que cae y se vuelve a crear\n-- IDENTICA, copiada de 20260916200000_portafolios.sql.\ndrop view if exists valor_portafolio","drop view if exists valor_inversion","drop view if exists valor_cuenta","create view valor_cuenta as\n  select a.id            as account_id,\n         a.ledger_id,\n         a.portfolio_id,\n         a.name,\n         a.kind          as account_kind,\n         a.valuation,\n         a.unit,\n         a.institution,\n         a.matures_on,\n         (a.archived_at is not null) as cerrada,\n         coalesce(a.fx_source, pf.fx_source) as fx_source,\n         i.symbol,\n         i.kind          as kind,\n         i.quote_currency,\n         i.ratio,\n         i.underlying_symbol,\n         i.quote_size,\n         coalesce(sal.saldo, 0) as saldo,\n         v.valor_nativo,\n         case when a.valuation = 'market' then i.quote_currency else a.unit end as moneda,\n         pr.on_date as precio_al,\n         convertir(v.valor_nativo,\n                   case when a.valuation = 'market' then i.quote_currency else a.unit end,\n                   current_date, 'USD', coalesce(a.fx_source, pf.fx_source)) as usd,\n         convertir(v.valor_nativo,\n                   case when a.valuation = 'market' then i.quote_currency else a.unit end,\n                   current_date, 'UVA', coalesce(a.fx_source, pf.fx_source)) as uva\n    from account a\n    left join portfolio pf on pf.id = a.portfolio_id\n    left join instrument i on i.id = a.instrument_id\n    left join lateral (\n      select sum(e.amount) as saldo from entry e where e.account_id = a.id\n    ) sal on true\n    left join lateral (\n      select p.price, p.on_date from price p\n       where p.instrument_id = a.instrument_id\n       order by p.on_date desc limit 1\n    ) pr on true\n    left join lateral (\n      select case\n               when coalesce(sal.saldo, 0) = 0 then 0\n               when a.valuation = 'market'\n                 then sal.saldo * pr.price / coalesce(i.quote_size, 1)\n               else sal.saldo\n             end as valor_nativo\n    ) v on true","alter view valor_cuenta set (security_invoker = on)","grant select on valor_cuenta to authenticated","create view valor_inversion as\n  select * from valor_cuenta where valuation in ('market', 'accrual')","alter view valor_inversion set (security_invoker = on)","grant select on valor_inversion to authenticated","create view valor_portafolio as\n  select p.id          as portfolio_id,\n         p.ledger_id,\n         p.name,\n         p.fx_source,\n         (p.archived_at is not null) as cerrado,\n         count(v.account_id)                                  as cuentas,\n         count(*) filter (where v.usd is null\n                            and v.account_id is not null)     as sin_valuar,\n         sum(v.usd)                                           as usd,\n         sum(v.uva)                                           as uva\n    from portfolio p\n    left join valor_cuenta v on v.portfolio_id = p.id\n   group by p.id, p.ledger_id, p.name, p.fx_source, p.archived_at","alter view valor_portafolio set (security_invoker = on)","grant select on valor_portafolio to authenticated","drop view if exists posicion","create view posicion as\n  select a.id           as account_id,\n         a.ledger_id,\n         a.name,\n         a.institution,\n         a.fx_source,\n         i.id           as instrument_id,\n         i.symbol,\n         i.name         as instrument_name,\n         i.kind,\n         i.quote_currency,\n         i.decimals,\n         i.ratio,\n         i.underlying_symbol,\n         i.quote_size,\n         coalesce(u.unidades, 0)                as unidades,\n         p.price                                as precio,\n         p.on_date                              as precio_al,\n         p.source                               as precio_fuente,\n         coalesce(u.unidades, 0) * p.price / coalesce(i.quote_size, 1) as valor,\n         coalesce(f.invertido, 0)               as invertido,\n         coalesce(u.unidades, 0) * p.price / coalesce(i.quote_size, 1)\n           - coalesce(f.invertido, 0)           as ganancia\n    from account a\n    join instrument i on i.id = a.instrument_id\n    left join lateral (\n      select sum(e.amount) as unidades from entry e where e.account_id = a.id\n    ) u on true\n    left join lateral (\n      select -sum(c.amount) as invertido\n        from entry pe\n        join entry c on c.transaction_id = pe.transaction_id\n                    and c.account_id is not null\n                    and c.account_id <> a.id\n       where pe.account_id = a.id\n    ) f on true\n    left join lateral (\n      select pr.price, pr.on_date, pr.source\n        from price pr where pr.instrument_id = i.id\n       order by pr.on_date desc limit 1\n    ) p on true\n   where a.valuation = 'market'\n     and a.archived_at is null","alter view posicion set (security_invoker = on)","grant select on posicion to authenticated","-- ---------------------------------------------------------------------------\n-- Al comprar, la lamina sale del tipo de instrumento.\n-- ---------------------------------------------------------------------------\n\ncreate or replace function lamina_de(p_kind text) returns numeric\nlanguage sql immutable\nset search_path = public, pg_temp\nas $$ select case when p_kind = 'bond' then 100 else 1 end $$","grant execute on function lamina_de(text) to authenticated","-- Un trigger y no un cambio en comprar_activo: esa funcion habria que copiarla\n-- entera para no perderle nada, y ya me paso hoy de reescribir de memoria algo\n-- que no habia leido. Ademas asi vale para cualquier alta de instrumento, venga\n-- de donde venga.\n--\n-- Solo corrige el caso imposible -un bono con lamina 1 siempre esta mal-, asi que\n-- un valor puesto a proposito sigue mandando.\ncreate or replace function lamina_por_defecto() returns trigger\nlanguage plpgsql\nset search_path = public, pg_temp\nas $$\nbegin\n  if new.quote_size = 1 and lamina_de(new.kind) <> 1 then\n    new.quote_size := lamina_de(new.kind);\n  end if;\n  return new;\nend $$","create trigger instrument_lamina\n  before insert on instrument\n  for each row execute function lamina_por_defecto()","comment on function lamina_por_defecto() is\n  'Un bono con lamina 1 siempre esta mal: cotiza por 100 nominales. Corrige solo '\n  'ese caso, asi un valor explicito sigue ganando. OD-39.'"}	lamina
20260918180000	{"-- El mes tiene que poder decir que parte suya se paga en cuotas — OD-24.\n--\n-- El resultado del mes se lleva el TOTAL de una compra en cuotas el dia que la\n-- hiciste. Eso es honesto —ese dia tu patrimonio bajo 120.000, te comprometiste\n-- a pagarlos— pero distorsiona la comparacion mes contra mes, que es el corazon\n-- de la aplicacion: octubre se ve pesimo y noviembre artificialmente bueno.\n--\n-- LA DECISION: un solo numero, y que sea el honesto. Mostrar un segundo\n-- resultado \\"como se paga\\" seria dar dos verdades sin decir cual mirar, y el\n-- usuario terminaria creyendole a la mas amable. Lo que faltaba no era otro\n-- numero: era que la pantalla pudiera EXPLICAR el que hay.\n--\n-- Para eso alcanza con que entry_detail traiga las cuotas de su movimiento.\n\ndrop view if exists entry_detail","create view entry_detail as\n  select e.id,\n         e.transaction_id,\n         e.ledger_id,\n         e.amount,\n         e.unit,\n         e.account_id,\n         a.name       as account_name,\n         a.kind       as account_kind,\n         a.valuation  as account_valuation,\n         e.category_id,\n         c.name       as category_name,\n         c.kind       as category_kind,\n         c.is_system  as category_is_system,\n         p.name       as category_parent,\n         t.occurred_on,\n         t.description,\n         t.kind       as tx_kind,\n         t.installments,\n         t.created_at\n    from entry e\n    join transaction t on t.id = e.transaction_id\n    left join account  a on a.id = e.account_id\n    left join category c on c.id = e.category_id\n    left join category p on p.id = c.parent_id","alter view entry_detail set (security_invoker = on)","grant select on entry_detail to authenticated"}	cuotas_en_el_mes
20260918190000	{"-- Una posicion puede estar en varias carteras — OD-40.\n--\n-- `account.portfolio_id` era UN campo, asi que AAPL podia estar en \\"Todo\\" o en\n-- \\"Tecnologia\\", nunca en las dos. El usuario pidio poder armar carteras logicas\n-- que se solapen, y ademas que exista una por defecto en vez de tildar a mano.\n--\n-- LO QUE PARECIA UN PROBLEMA Y NO LO ES. Si una posicion esta en dos carteras,\n-- la misma operacion puede ser aporte en una y no en la otra. Suena a\n-- contradiccion y es exactamente lo correcto:\n--\n--   \\"Todo\\"        tiene AAPL y el efectivo de Balanz\n--   \\"Tecnologia\\"  tiene solo AAPL\n--\n--   Comprar AAPL con pesos de Balanz:\n--     para \\"Todo\\"        las dos patas estan adentro  -> NO es aporte\n--     para \\"Tecnologia\\"  la plata vino de afuera      -> SI es aporte\n--\n-- Las dos lecturas son ciertas porque los bordes son distintos, y ADR-026 define\n-- el flujo por borde, no por operacion. No hubo que cambiar la regla: solo hubo\n-- que dejar de suponer que cada cuenta tiene un solo borde.\n--\n-- LO QUE SI SE ROMPIA: la fuente de cotizacion. `valor_cuenta` resolvia\n-- cuenta -> cartera -> libro, y con varias carteras \\"la cartera\\" es ambigua. Se\n-- resolvio bajando esa resolucion un nivel: la CUENTA se mide con su propia\n-- fuente (o la del libro), y la fuente de la cartera se aplica al valuar ESA\n-- cartera. Cada borde convierte con su vara, que es lo que ADR-023 ya decia.\n\ncreate table portfolio_account (\n  portfolio_id uuid not null,\n  account_id   uuid not null,\n  ledger_id    uuid not null,\n  added_at     timestamptz not null default now(),\n  primary key (portfolio_id, account_id),\n  constraint pa_portfolio_same_ledger\n    foreign key (portfolio_id, ledger_id) references portfolio(id, ledger_id) on delete cascade,\n  constraint pa_account_same_ledger\n    foreign key (account_id, ledger_id) references account(id, ledger_id) on delete cascade\n)","create index portfolio_account_cuenta_idx on portfolio_account (account_id)","alter table portfolio_account enable row level security","alter table portfolio_account force row level security","create policy portfolio_account_activo on portfolio_account for all to authenticated\n  using      (ledger_id = my_ledger())\n  with check (ledger_id = my_ledger())","grant select, insert, update, delete on portfolio_account to authenticated","-- Lo que ya estaba asignado se muda, y recien despues cae la columna: dos\n-- fuentes de verdad conviviendo es como empiezan a discrepar.\ninsert into portfolio_account (portfolio_id, account_id, ledger_id)\nselect a.portfolio_id, a.id, a.ledger_id\n  from account a where a.portfolio_id is not null\non conflict do nothing","-- ---------------------------------------------------------------------------\n-- Las vistas. Se recrean COMPLETAS desde su ultima version.\n-- ---------------------------------------------------------------------------\n\ndrop view if exists valor_portafolio","drop view if exists flujo_portafolio","drop view if exists valor_inversion","drop view if exists valor_cuenta","alter table account drop column portfolio_id","create view valor_cuenta as\n  select a.id            as account_id,\n         a.ledger_id,\n         a.name,\n         a.kind          as account_kind,\n         a.valuation,\n         a.unit,\n         a.institution,\n         a.matures_on,\n         (a.archived_at is not null) as cerrada,\n         -- Ya NO mezcla la cartera: una cuenta puede estar en varias y \\"la\n         -- cartera\\" seria ambiguo. Cada cartera aplica la suya al valuarse.\n         a.fx_source,\n         i.symbol,\n         i.kind          as kind,\n         i.quote_currency,\n         i.ratio,\n         i.underlying_symbol,\n         i.quote_size,\n         coalesce(sal.saldo, 0) as saldo,\n         -- En cuantas carteras esta. Con pertenencia multiple, \\"suelta\\" ya no es\n         -- un campo nulo: es este contador en cero. Y una cuenta suelta mide mal\n         -- en silencio, asi que la pantalla necesita poder decirlo.\n         coalesce(car.n, 0) as carteras,\n         v.valor_nativo,\n         case when a.valuation = 'market' then i.quote_currency else a.unit end as moneda,\n         pr.on_date as precio_al,\n         convertir(v.valor_nativo,\n                   case when a.valuation = 'market' then i.quote_currency else a.unit end,\n                   current_date, 'USD', a.fx_source) as usd,\n         convertir(v.valor_nativo,\n                   case when a.valuation = 'market' then i.quote_currency else a.unit end,\n                   current_date, 'UVA', a.fx_source) as uva\n    from account a\n    left join instrument i on i.id = a.instrument_id\n    left join lateral (\n      select sum(e.amount) as saldo from entry e where e.account_id = a.id\n    ) sal on true\n    left join lateral (\n      select count(*) as n from portfolio_account pa where pa.account_id = a.id\n    ) car on true\n    left join lateral (\n      select p.price, p.on_date from price p\n       where p.instrument_id = a.instrument_id\n       order by p.on_date desc limit 1\n    ) pr on true\n    left join lateral (\n      select case\n               when coalesce(sal.saldo, 0) = 0 then 0\n               when a.valuation = 'market'\n                 then sal.saldo * pr.price / coalesce(i.quote_size, 1)\n               else sal.saldo\n             end as valor_nativo\n    ) v on true","alter view valor_cuenta set (security_invoker = on)","grant select on valor_cuenta to authenticated","create view valor_inversion as\n  select * from valor_cuenta where valuation in ('market', 'accrual')","alter view valor_inversion set (security_invoker = on)","grant select on valor_inversion to authenticated","-- Cada cartera convierte con SU vara: la de la cuenta si la tiene, la de la\n-- cartera si no. Un CEDEAR sigue midiendose al CCL aunque la cartera diga MEP.\ncreate view valor_portafolio as\n  select p.id          as portfolio_id,\n         p.ledger_id,\n         p.name,\n         p.fx_source,\n         (p.archived_at is not null) as cerrado,\n         count(v.account_id)                              as cuentas,\n         count(*) filter (where v.account_id is not null\n                            and convertir(v.valor_nativo, v.moneda, current_date,\n                                          'USD', coalesce(v.fx_source, p.fx_source)) is null)\n                                                          as sin_valuar,\n         sum(convertir(v.valor_nativo, v.moneda, current_date,\n                       'USD', coalesce(v.fx_source, p.fx_source)))  as usd,\n         sum(convertir(v.valor_nativo, v.moneda, current_date,\n                       'UVA', coalesce(v.fx_source, p.fx_source)))  as uva\n    from portfolio p\n    left join portfolio_account pa on pa.portfolio_id = p.id\n    left join valor_cuenta v on v.account_id = pa.account_id\n   group by p.id, p.ledger_id, p.name, p.fx_source, p.archived_at","alter view valor_portafolio set (security_invoker = on)","grant select on valor_portafolio to authenticated","-- Es flujo lo que tiene la contraparte fuera de ESTA cartera. Con carteras que\n-- se solapan, \\"fuera\\" se evalua por cartera, y por eso la misma compra puede ser\n-- aporte en una y movimiento interno en otra.\ncreate view flujo_portafolio as\n  with participa as (\n    select distinct pa.portfolio_id, e.transaction_id\n      from entry e\n      join portfolio_account pa on pa.account_id = e.account_id\n  )\n  select pp.portfolio_id,\n         t.occurred_on           as fecha,\n         c.unit                  as unidad,\n         sum(c.amount)           as monto,\n         convertir(sum(c.amount), c.unit, t.occurred_on, 'USD', pf.fx_source) as usd,\n         convertir(sum(c.amount), c.unit, t.occurred_on, 'UVA', pf.fx_source) as uva\n    from participa pp\n    join portfolio pf on pf.id = pp.portfolio_id\n    join transaction t on t.id = pp.transaction_id\n    join entry c on c.transaction_id = t.id\n                and c.account_id is not null\n   where not exists (\n           select 1 from portfolio_account x\n            where x.portfolio_id = pp.portfolio_id\n              and x.account_id  = c.account_id)\n   group by pp.portfolio_id, t.id, t.occurred_on, c.unit, pf.fx_source","alter view flujo_portafolio set (security_invoker = on)","grant select on flujo_portafolio to authenticated","comment on view flujo_portafolio is\n  'Solo lo que cruza el borde de cada cartera. Con carteras que se solapan, la '\n  'misma operacion puede cruzar una y no otra: los bordes son distintos y las '\n  'dos lecturas son ciertas. ADR-026 / OD-40.'","-- ---------------------------------------------------------------------------\n-- La cartera por defecto: la del broker.\n--\n-- El usuario tenia que crear la cartera y tildar cuenta por cuenta, y hasta que\n-- lo hiciera el rendimiento se medi­a mal en silencio (ADR-026: una cuenta suelta\n-- hace que comprar con ese efectivo cuente como aporte nuevo).\n--\n-- La regla: si una cuenta es de broker -una posicion, o efectivo que NO es\n-- gastable- y dice donde esta, entra sola a la cartera de ese lugar, creandola\n-- si no existe. Es exactamente \\"una cartera por cuenta comitente con sus activos\n-- adentro\\", y sale gratis porque `comprar_activo` ya guarda el broker en\n-- `institution`.\n--\n-- Lo que NO entra: una caja de ahorro. Tener plata en el Macro no es una cartera\n-- de inversion, y meterla ahi dentro haria que mover plata del banco al broker\n-- dejara de contarse como aporte.\n--\n-- Es un trigger y no un cambio en `comprar_activo` por la misma razon de siempre:\n-- esa funcion habria que copiarla entera para no perderle nada, y asi la regla\n-- vale para cualquier alta de cuenta, venga de donde venga.\n\ncreate or replace function cartera_del_broker() returns trigger\nlanguage plpgsql\nsecurity definer\nset search_path = public, pg_temp\nas $$\ndeclare\n  v_cartera uuid;\n  v_donde   text := nullif(trim(coalesce(new.institution, '')), '');\nbegin\n  if v_donde is null then return new; end if;\n  if not (new.valuation = 'market' or (new.valuation = 'balance' and not new.is_spendable)) then\n    return new;\n  end if;\n\n  select id into v_cartera\n    from portfolio\n   where ledger_id = new.ledger_id and lower(name) = lower(v_donde) and archived_at is null;\n\n  if v_cartera is null then\n    insert into portfolio (ledger_id, name) values (new.ledger_id, v_donde)\n    returning id into v_cartera;\n  end if;\n\n  insert into portfolio_account (portfolio_id, account_id, ledger_id)\n  values (v_cartera, new.id, new.ledger_id)\n  on conflict do nothing;\n\n  return new;\nend $$","create trigger account_cartera_del_broker\n  after insert on account\n  for each row execute function cartera_del_broker()","comment on function cartera_del_broker() is\n  'Una cuenta de broker entra sola a la cartera de su institucion. Sin esto habia '\n  'que tildar cuenta por cuenta, y hasta hacerlo el rendimiento se media mal en '\n  'silencio. OD-40.'"}	carteras_multiples
20260918200000	{"-- Varios libros, y plata que pasa de uno a otro — ADR-032 / OD-41.\n--\n-- Dos cosas que hoy no se pueden, y solo una era facil.\n--\n-- 1. NO SE PUEDE CREAR UN LIBRO. El unico lugar donde nace uno es el trigger de\n--    alta, asi que sos duenio de exactamente uno. Para una cuenta compartida con\n--    una pareja hacen falta TRES: el de cada uno mas el comun.\n--\n-- 2. UN MOVIMIENTO NO PUEDE CRUZAR LIBROS, y eso no se toca. La restriccion\n--    `entry_account_same_ledger` obliga a que toda linea viva en el mismo libro\n--    que su movimiento, y es lo que hace que cada libro cierre en cero POR SI\n--    SOLO. Si una pata viviera afuera, ningun libro cerraria solo y la partida\n--    doble dejaria de servir como control.\n--\n--    Se resuelve con DOS movimientos encadenados, uno en cada libro, con la misma\n--    referencia. Y con una respuesta que dio el usuario: aportar al libro comun\n--    ES GASTAR. Esa plata ya no la podes usar sola, asi que tu patrimonio baja.\n--    La alternativa -que siguiera siendo tuya- exigiria modelar QUE PARTE del\n--    fondo comun te pertenece, y eso cambia cada vez que alguien aporta o gasta.\n\n-- ---------------------------------------------------------------------------\n-- Primero, arreglar como se identifica una categoria de sistema.\n--\n-- Se buscaban por `is_system` MAS el tipo: \\"la de sistema de gasto\\" era la de\n-- ajustes y \\"la de ingreso\\" la de intereses. Eso alcanzaba con dos y se rompe con\n-- cuatro: agregar los aportes haria que el ajuste de saldo se confundiera con\n-- ellos, y el resumen del mes contaria los aportes como ajustes.\n--\n-- `is_system` decia que no se puede borrar; nunca dijo PARA QUE es.\n-- ---------------------------------------------------------------------------\n\nalter table category add column system_role text\n  check (system_role in ('ajuste', 'interes', 'aporte_enviado', 'aporte_recibido'))","create unique index category_system_role_idx\n  on category (ledger_id, system_role) where system_role is not null","comment on column category.system_role is\n  'Para que sirve una categoria de sistema. Antes se deducia de is_system + kind, '\n  'que alcanzaba con dos roles y se rompe con cuatro.'","update category set system_role = 'ajuste'  where is_system and kind = 'expense'","update category set system_role = 'interes' where is_system and kind = 'income'","create or replace function sembrar_libro(p_ledger uuid) returns void\nlanguage plpgsql\nsecurity definer\nset search_path = public, pg_temp\nas $$\nbegin\n  insert into category (ledger_id, name, kind, is_system, sort_order, system_role) values\n    (p_ledger, 'Sueldo',           'income',  false, 10, null),\n    (p_ledger, 'Intereses',        'income',  true,  20, 'interes'),   -- ADR-013, ADR-014\n    (p_ledger, 'Otros ingresos',   'income',  false, 30, null),\n    (p_ledger, 'Gastos fijos',     'expense', false, 10, null),\n    (p_ledger, 'Gastos variables', 'expense', false, 20, null),\n    (p_ledger, 'Ajuste de saldo',  'expense', true,  90, 'ajuste');    -- ADR-005\nend $$","drop view if exists entry_detail","create view entry_detail as\n  select e.id,\n         e.transaction_id,\n         e.ledger_id,\n         e.amount,\n         e.unit,\n         e.account_id,\n         a.name       as account_name,\n         a.kind       as account_kind,\n         a.valuation  as account_valuation,\n         e.category_id,\n         c.name       as category_name,\n         c.kind       as category_kind,\n         c.is_system  as category_is_system,\n         c.system_role as category_role,\n         p.name       as category_parent,\n         t.occurred_on,\n         t.description,\n         t.kind       as tx_kind,\n         t.installments,\n         t.created_at\n    from entry e\n    join transaction t on t.id = e.transaction_id\n    left join account  a on a.id = e.account_id\n    left join category c on c.id = e.category_id\n    left join category p on p.id = c.parent_id","alter view entry_detail set (security_invoker = on)","grant select on entry_detail to authenticated","-- ---------------------------------------------------------------------------\n-- Crear un libro.\n-- ---------------------------------------------------------------------------\n\ncreate or replace function crear_libro(p_nombre text) returns uuid\nlanguage plpgsql\nsecurity definer\nset search_path = public, pg_temp\nas $$\ndeclare\n  v_libro  uuid;\n  v_nombre text := nullif(trim(p_nombre), '');\nbegin\n  if v_nombre is null then raise exception 'El libro necesita un nombre'; end if;\n  if auth.uid() is null then raise exception 'Hace falta estar identificado'; end if;\n\n  insert into ledger (name) values (v_nombre) returning id into v_libro;\n  insert into ledger_member (ledger_id, user_id, role) values (v_libro, auth.uid(), 'owner');\n  perform sembrar_libro(v_libro);\n\n  -- Crear un libro es querer usarlo. Si no, quedaria creado e invisible.\n  insert into active_ledger (user_id, ledger_id) values (auth.uid(), v_libro)\n  on conflict (user_id) do update set ledger_id = excluded.ledger_id, set_at = now();\n\n  return v_libro;\nend $$","grant execute on function crear_libro(text) to authenticated","-- ---------------------------------------------------------------------------\n-- Pasar plata a otro libro.\n--\n-- Dos movimientos, uno en cada libro, con la misma referencia para poder verlos\n-- como lo que son: las dos mitades de una misma cosa.\n-- ---------------------------------------------------------------------------\n\nalter table transaction add column cross_ref uuid","create index transaction_cross_ref_idx on transaction (cross_ref) where cross_ref is not null","comment on column transaction.cross_ref is\n  'Une las dos mitades de un aporte entre libros. No es una clave foranea: las '\n  'dos mitades viven en libros distintos a proposito. ADR-032.'","/** La categoria de sistema de un rol, creandola la primera vez que hace falta. */\ncreate or replace function categoria_de_rol(p_ledger uuid, p_rol text)\nreturns uuid\nlanguage plpgsql\nsecurity definer\nset search_path = public, pg_temp\nas $$\ndeclare\n  v_cat uuid;\nbegin\n  select id into v_cat from category where ledger_id = p_ledger and system_role = p_rol;\n  if v_cat is not null then return v_cat; end if;\n\n  -- Se crean reci­en cuando se usan: quien nunca comparta un libro no tiene por\n  -- que ver estas categorias en su lista.\n  insert into category (ledger_id, name, kind, is_system, sort_order, system_role)\n  values (p_ledger,\n          case p_rol when 'aporte_enviado' then 'Aporte a otro libro'\n                     else 'Aporte recibido' end,\n          case p_rol when 'aporte_enviado' then 'expense' else 'income' end,\n          true, 95, p_rol)\n  returning id into v_cat;\n\n  return v_cat;\nend $$","create or replace function aportar_a_libro(\n  p_destino        uuid,\n  p_cuenta_origen  uuid,\n  p_cuenta_destino uuid,\n  p_monto          numeric,\n  p_on             date default null,\n  p_detalle        text default null\n) returns uuid\nlanguage plpgsql\nsecurity definer\nset search_path = public, pg_temp\nas $$\ndeclare\n  v_origen  uuid := my_ledger();\n  v_ref     uuid := gen_random_uuid();\n  v_fecha   date := coalesce(p_on, current_date);\n  v_unidad  text;\n  v_tx      uuid;\n  v_cat     uuid;\nbegin\n  if p_monto is null or p_monto <= 0 then\n    raise exception 'El aporte tiene que ser mayor que cero';\n  end if;\n  if v_origen = p_destino then\n    raise exception 'Ese es el mismo libro: usa una transferencia comun';\n  end if;\n\n  -- Tiene que ser miembro de LOS DOS. Es SECURITY DEFINER, asi que RLS no lo\n  -- comprueba por nosotros: se comprueba aca, explicito.\n  if not exists (select 1 from ledger_member where ledger_id = v_origen   and user_id = auth.uid())\n  or not exists (select 1 from ledger_member where ledger_id = p_destino and user_id = auth.uid()) then\n    raise exception 'Solo podes mover plata entre libros que sean tuyos';\n  end if;\n\n  select unit into v_unidad from account\n   where id = p_cuenta_origen and ledger_id = v_origen;\n  if v_unidad is null then raise exception 'Esa cuenta de origen no es de tu libro'; end if;\n\n  if not exists (select 1 from account\n                  where id = p_cuenta_destino and ledger_id = p_destino and unit = v_unidad) then\n    raise exception 'La cuenta de destino no existe en ese libro, o esta en otra moneda';\n  end if;\n\n  -- En TU libro: sale plata y es un GASTO. Esa plata ya no la podes usar sola.\n  v_cat := categoria_de_rol(v_origen, 'aporte_enviado');\n  insert into transaction (ledger_id, occurred_on, description, kind, created_by, cross_ref)\n       values (v_origen, v_fecha, coalesce(nullif(trim(p_detalle), ''), 'Aporte a otro libro'),\n               'expense', auth.uid(), v_ref)\n    returning id into v_tx;\n  insert into entry (transaction_id, ledger_id, account_id, category_id, amount, unit) values\n    (v_tx, v_origen, p_cuenta_origen, null, -p_monto, v_unidad),\n    (v_tx, v_origen, null, v_cat,        p_monto, v_unidad);\n\n  -- En el OTRO libro: entra plata y es un ingreso.\n  v_cat := categoria_de_rol(p_destino, 'aporte_recibido');\n  insert into transaction (ledger_id, occurred_on, description, kind, created_by, cross_ref)\n       values (p_destino, v_fecha, coalesce(nullif(trim(p_detalle), ''), 'Aporte recibido'),\n               'income', auth.uid(), v_ref)\n    returning id into v_tx;\n  insert into entry (transaction_id, ledger_id, account_id, category_id, amount, unit) values\n    (v_tx, p_destino, p_cuenta_destino, null,  p_monto, v_unidad),\n    (v_tx, p_destino, null,             v_cat, -p_monto, v_unidad);\n\n  return v_ref;\nend $$","grant execute on function aportar_a_libro(uuid, uuid, uuid, numeric, date, text) to authenticated","comment on function aportar_a_libro(uuid, uuid, uuid, numeric, date, text) is\n  'Dos movimientos encadenados, uno por libro. No es una transferencia: aportar '\n  'al libro comun es GASTAR, porque esa plata ya no la podes usar sola. ADR-032.'","-- ---------------------------------------------------------------------------\n-- Para elegir la cuenta de destino hay que ver las cuentas del OTRO libro, y RLS\n-- lo impide: la politica es `ledger_id = my_ledger()`, y esta bien que lo sea.\n--\n-- Esta funcion es la excepcion minima: devuelve nombre, moneda y nada mas, solo\n-- de libros a los que el que pregunta pertenece. No abre la puerta a los\n-- movimientos ni a los saldos del otro libro.\n-- ---------------------------------------------------------------------------\n\ncreate or replace function cuentas_de_libro(p_ledger uuid)\nreturns table (id uuid, name text, unit text)\nlanguage sql\nstable\nsecurity definer\nset search_path = public, pg_temp\nas $$\n  select a.id, a.name, a.unit\n    from account a\n   where a.ledger_id = p_ledger\n     and a.archived_at is null\n     and a.valuation = 'balance'\n     and exists (select 1 from ledger_member m\n                  where m.ledger_id = p_ledger and m.user_id = auth.uid())\n   order by a.name\n$$","grant execute on function cuentas_de_libro(uuid) to authenticated"}	aportes
20260918210000	{"-- Archivar y borrar un libro, y la institucion en los movimientos.\n--\n-- Se podian crear libros y no sacarlos. Y la regla es la MISMA que ya rige para\n-- cuentas y categorias, que es lo que la hace facil de explicar:\n--\n--   se BORRA lo que no tiene historia    -> no se pierde nada\n--   se ARCHIVA lo que si la tiene        -> la historia no se toca\n--\n-- Un libro con movimientos no se borra ni pidiendo por favor: es exactamente lo\n-- que ADR-018 vino a proteger.\n\nalter table ledger add column archived_at timestamptz","comment on column ledger.archived_at is\n  'Un libro archivado deja de aparecer y deja de poder ser el activo, pero su '\n  'historia queda entera.'","-- Los libros archivados dejan de contar como tuyos: ni para elegir, ni para RLS.\ncreate or replace function my_ledgers() returns setof uuid\nlanguage sql stable security definer set search_path = public, pg_temp\nas $$\n  select m.ledger_id from ledger_member m\n    join ledger l on l.id = m.ledger_id\n   where m.user_id = auth.uid() and l.archived_at is null\n$$","create or replace function my_ledger() returns uuid\nlanguage sql\nstable\nsecurity definer\nset search_path = public, pg_temp\nas $$\n  select coalesce(\n    (select a.ledger_id\n       from active_ledger a\n       join ledger_member m on m.ledger_id = a.ledger_id and m.user_id = a.user_id\n       join ledger l on l.id = a.ledger_id and l.archived_at is null\n      where a.user_id = auth.uid()),\n    (select m.ledger_id from ledger_member m\n       join ledger l on l.id = m.ledger_id and l.archived_at is null\n      where m.user_id = auth.uid()\n      order by m.joined_at, m.ledger_id\n      limit 1)\n  )\n$$","create or replace function archivar_libro(p_ledger uuid) returns void\nlanguage plpgsql\nsecurity definer\nset search_path = public, pg_temp\nas $$\nbegin\n  if not exists (select 1 from ledger_member\n                  where ledger_id = p_ledger and user_id = auth.uid() and role = 'owner') then\n    raise exception 'Solo quien creo el libro puede archivarlo';\n  end if;\n\n  -- Quedarse sin ningun libro deja la aplicacion sin nada que mostrar y sin\n  -- forma de volver: no hay pantalla para crear el primero desde afuera.\n  if (select count(*) from my_ledgers()) <= 1 then\n    raise exception 'Es tu unico libro: no se puede archivar';\n  end if;\n\n  update ledger set archived_at = now() where id = p_ledger;\n\n  -- Si era el que estabas mirando, hay que sacarte de ahi.\n  delete from active_ledger where user_id = auth.uid() and ledger_id = p_ledger;\nend $$","grant execute on function archivar_libro(uuid) to authenticated","create or replace function eliminar_libro(p_ledger uuid) returns void\nlanguage plpgsql\nsecurity definer\nset search_path = public, pg_temp\nas $$\ndeclare v_movs int;\nbegin\n  if not exists (select 1 from ledger_member\n                  where ledger_id = p_ledger and user_id = auth.uid() and role = 'owner') then\n    raise exception 'Solo quien creo el libro puede borrarlo';\n  end if;\n  if (select count(*) from my_ledgers()) <= 1 then\n    raise exception 'Es tu unico libro: no se puede borrar';\n  end if;\n\n  select count(*) into v_movs from transaction where ledger_id = p_ledger;\n  if v_movs > 0 then\n    raise exception 'Ese libro tiene % movimientos: archivalo, no lo borres', v_movs;\n  end if;\n\n  delete from ledger where id = p_ledger;   -- todo lo demas cae por cascada\nend $$","grant execute on function eliminar_libro(uuid) to authenticated","-- El selector solo muestra los vivos. `create or replace` no sirve cuando se\n-- agrega una columna en el medio: hay que tirarla y rehacerla.\ndrop view if exists mi_libro","create view mi_libro\nwith (security_invoker = off) as\n  select l.id                                   as ledger_id,\n         l.name,\n         m.role,\n         (l.id = my_ledger())                   as activo,\n         (select count(*) from ledger_member x where x.ledger_id = l.id) as miembros,\n         (select count(*) from transaction t where t.ledger_id = l.id)   as movimientos,\n         m.joined_at\n    from ledger l\n    join ledger_member m on m.ledger_id = l.id\n   where m.user_id = auth.uid()\n     and l.archived_at is null","grant select on mi_libro to authenticated","-- ---------------------------------------------------------------------------\n-- Y la institucion en la lista de movimientos: dos cuentas pueden llamarse\n-- igual en bancos distintos, y ahi el nombre solo no alcanza para saber cual es.\n-- ---------------------------------------------------------------------------\n\ndrop view if exists entry_detail","create view entry_detail as\n  select e.id,\n         e.transaction_id,\n         e.ledger_id,\n         e.amount,\n         e.unit,\n         e.account_id,\n         a.name        as account_name,\n         a.kind        as account_kind,\n         a.valuation   as account_valuation,\n         a.institution as account_institution,\n         e.category_id,\n         c.name        as category_name,\n         c.kind        as category_kind,\n         c.is_system   as category_is_system,\n         c.system_role as category_role,\n         p.name        as category_parent,\n         t.occurred_on,\n         t.description,\n         t.kind        as tx_kind,\n         t.installments,\n         t.created_at\n    from entry e\n    join transaction t on t.id = e.transaction_id\n    left join account  a on a.id = e.account_id\n    left join category c on c.id = e.category_id\n    left join category p on p.id = c.parent_id","alter view entry_detail set (security_invoker = on)","grant select on entry_detail to authenticated"}	archivar_libro
20260919100000	{"-- Un aporte entre libros dice A QUE libro fue, y DE cual vino.\n--\n-- La descripcion por defecto era \\"Aporte a otro libro\\" y \\"Aporte recibido\\", que\n-- en la lista de movimientos no dice nada: con dos libros compartidos no se\n-- sabe cual. El dato existe -las dos mitades se crean juntas y cada una conoce\n-- el nombre del otro libro- y no se estaba usando.\n--\n-- Va en la DESCRIPCION y no en una columna nueva: la otra mitad vive en otro\n-- libro y RLS no la deja leer, asi que una columna con el id obligaria a una\n-- funcion SECURITY DEFINER para resolver el nombre. Guardarlo cuando se crea es\n-- mas barato y sobrevive aunque despues te saquen de ese libro.\n--\n-- Solo es el valor POR DEFECTO: si escribis un detalle, manda el tuyo.\n\ncreate or replace function aportar_a_libro(\n  p_destino        uuid,\n  p_cuenta_origen  uuid,\n  p_cuenta_destino uuid,\n  p_monto          numeric,\n  p_on             date default null,\n  p_detalle        text default null\n) returns uuid\nlanguage plpgsql\nsecurity definer\nset search_path = public, pg_temp\nas $$\ndeclare\n  v_origen  uuid := my_ledger();\n  v_ref     uuid := gen_random_uuid();\n  v_fecha   date := coalesce(p_on, current_date);\n  v_unidad  text;\n  v_tx      uuid;\n  v_cat     uuid;\n  v_detalle text := nullif(trim(p_detalle), '');\n  v_alla    text;\n  v_aca     text;\nbegin\n  if p_monto is null or p_monto <= 0 then\n    raise exception 'El aporte tiene que ser mayor que cero';\n  end if;\n  if v_origen = p_destino then\n    raise exception 'Ese es el mismo libro: usa una transferencia comun';\n  end if;\n\n  -- Tiene que ser miembro de LOS DOS. Es SECURITY DEFINER, asi que RLS no lo\n  -- comprueba por nosotros: se comprueba aca, explicito.\n  if not exists (select 1 from ledger_member where ledger_id = v_origen   and user_id = auth.uid())\n  or not exists (select 1 from ledger_member where ledger_id = p_destino and user_id = auth.uid()) then\n    raise exception 'Solo podes mover plata entre libros que sean tuyos';\n  end if;\n\n  select name into v_alla from ledger where id = p_destino;\n  select name into v_aca  from ledger where id = v_origen;\n\n  select unit into v_unidad from account\n   where id = p_cuenta_origen and ledger_id = v_origen;\n  if v_unidad is null then raise exception 'Esa cuenta de origen no es de tu libro'; end if;\n\n  if not exists (select 1 from account\n                  where id = p_cuenta_destino and ledger_id = p_destino and unit = v_unidad) then\n    raise exception 'La cuenta de destino no existe en ese libro, o esta en otra moneda';\n  end if;\n\n  -- En TU libro: sale plata y es un GASTO. Esa plata ya no la podes usar sola.\n  v_cat := categoria_de_rol(v_origen, 'aporte_enviado');\n  insert into transaction (ledger_id, occurred_on, description, kind, created_by, cross_ref)\n       values (v_origen, v_fecha, coalesce(v_detalle, 'Aporte a ' || v_alla),\n               'expense', auth.uid(), v_ref)\n    returning id into v_tx;\n  insert into entry (transaction_id, ledger_id, account_id, category_id, amount, unit) values\n    (v_tx, v_origen, p_cuenta_origen, null, -p_monto, v_unidad),\n    (v_tx, v_origen, null, v_cat,        p_monto, v_unidad);\n\n  -- En el OTRO libro: entra plata y es un ingreso.\n  v_cat := categoria_de_rol(p_destino, 'aporte_recibido');\n  insert into transaction (ledger_id, occurred_on, description, kind, created_by, cross_ref)\n       values (p_destino, v_fecha, coalesce(v_detalle, 'Aporte de ' || v_aca),\n               'income', auth.uid(), v_ref)\n    returning id into v_tx;\n  insert into entry (transaction_id, ledger_id, account_id, category_id, amount, unit) values\n    (v_tx, p_destino, p_cuenta_destino, null,  p_monto, v_unidad),\n    (v_tx, p_destino, null,             v_cat, -p_monto, v_unidad);\n\n  return v_ref;\nend $$"}	aporte_nombra_libro
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: -
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: -
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 62, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: -
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_identifier_key UNIQUE (identifier);


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: mfa_recovery_code_sets mfa_recovery_code_sets_mfa_factor_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_recovery_code_sets
    ADD CONSTRAINT mfa_recovery_code_sets_mfa_factor_id_key UNIQUE (mfa_factor_id);


--
-- Name: mfa_recovery_code_sets mfa_recovery_code_sets_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_recovery_code_sets
    ADD CONSTRAINT mfa_recovery_code_sets_pkey PRIMARY KEY (id);


--
-- Name: mfa_recovery_code_sets mfa_recovery_code_sets_user_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_recovery_code_sets
    ADD CONSTRAINT mfa_recovery_code_sets_user_id_key UNIQUE (user_id);


--
-- Name: mfa_recovery_codes mfa_recovery_codes_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_recovery_codes
    ADD CONSTRAINT mfa_recovery_codes_pkey PRIMARY KEY (id);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_code_key UNIQUE (authorization_code);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_id_key UNIQUE (authorization_id);


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_client_states
    ADD CONSTRAINT oauth_client_states_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_client_unique UNIQUE (user_id, client_id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: scim_tokens scim_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.scim_tokens
    ADD CONSTRAINT scim_tokens_pkey PRIMARY KEY (id);


--
-- Name: scim_users scim_users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.scim_users
    ADD CONSTRAINT scim_users_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: account account_id_ledger_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_id_ledger_id_key UNIQUE (id, ledger_id);


--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (id);


--
-- Name: active_ledger active_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_ledger
    ADD CONSTRAINT active_ledger_pkey PRIMARY KEY (user_id);


--
-- Name: budget budget_ledger_id_category_id_period_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget
    ADD CONSTRAINT budget_ledger_id_category_id_period_key UNIQUE (ledger_id, category_id, period);


--
-- Name: budget budget_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget
    ADD CONSTRAINT budget_pkey PRIMARY KEY (id);


--
-- Name: category category_id_ledger_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_id_ledger_id_key UNIQUE (id, ledger_id);


--
-- Name: category category_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_pkey PRIMARY KEY (id);


--
-- Name: entry entry_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entry
    ADD CONSTRAINT entry_pkey PRIMARY KEY (id);


--
-- Name: fx_rate fx_rate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fx_rate
    ADD CONSTRAINT fx_rate_pkey PRIMARY KEY (ledger_id, on_date, base, quote, source);


--
-- Name: instrument instrument_id_ledger_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.instrument
    ADD CONSTRAINT instrument_id_ledger_id_key UNIQUE (id, ledger_id);


--
-- Name: instrument instrument_ledger_id_symbol_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.instrument
    ADD CONSTRAINT instrument_ledger_id_symbol_key UNIQUE (ledger_id, symbol);


--
-- Name: instrument instrument_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.instrument
    ADD CONSTRAINT instrument_pkey PRIMARY KEY (id);


--
-- Name: ledger_invite ledger_invite_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ledger_invite
    ADD CONSTRAINT ledger_invite_pkey PRIMARY KEY (code);


--
-- Name: ledger_member ledger_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ledger_member
    ADD CONSTRAINT ledger_member_pkey PRIMARY KEY (ledger_id, user_id);


--
-- Name: ledger ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ledger
    ADD CONSTRAINT ledger_pkey PRIMARY KEY (id);


--
-- Name: portfolio_account portfolio_account_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portfolio_account
    ADD CONSTRAINT portfolio_account_pkey PRIMARY KEY (portfolio_id, account_id);


--
-- Name: portfolio portfolio_id_ledger_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portfolio
    ADD CONSTRAINT portfolio_id_ledger_id_key UNIQUE (id, ledger_id);


--
-- Name: portfolio portfolio_ledger_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portfolio
    ADD CONSTRAINT portfolio_ledger_id_name_key UNIQUE (ledger_id, name);


--
-- Name: portfolio portfolio_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portfolio
    ADD CONSTRAINT portfolio_pkey PRIMARY KEY (id);


--
-- Name: price price_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price
    ADD CONSTRAINT price_pkey PRIMARY KEY (instrument_id, on_date, source);


--
-- Name: scheduled_event scheduled_event_id_ledger_uk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_event
    ADD CONSTRAINT scheduled_event_id_ledger_uk UNIQUE (id, ledger_id);


--
-- Name: scheduled_event scheduled_event_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_event
    ADD CONSTRAINT scheduled_event_pkey PRIMARY KEY (id);


--
-- Name: transaction transaction_id_ledger_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT transaction_id_ledger_id_key UNIQUE (id, ledger_id);


--
-- Name: transaction transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT transaction_pkey PRIMARY KEY (id);


--
-- Name: messages messages_payload_exclusive; Type: CHECK CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages
    ADD CONSTRAINT messages_payload_exclusive CHECK (((payload IS NULL) OR (binary_payload IS NULL))) NOT VALID;


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_vectors
    ADD CONSTRAINT buckets_vectors_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: supabase_migrations; Owner: -
--

ALTER TABLE ONLY supabase_migrations.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_created_at_idx ON auth.custom_oauth_providers USING btree (created_at);


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_enabled_idx ON auth.custom_oauth_providers USING btree (enabled);


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_identifier_idx ON auth.custom_oauth_providers USING btree (identifier);


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_provider_type_idx ON auth.custom_oauth_providers USING btree (provider_type);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_oauth_client_states_created_at ON auth.oauth_client_states USING btree (created_at);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: idx_users_created_at_desc; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_created_at_desc ON auth.users USING btree (created_at DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_email ON auth.users USING btree (email);


--
-- Name: idx_users_last_sign_in_at_desc; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_last_sign_in_at_desc ON auth.users USING btree (last_sign_in_at DESC);


--
-- Name: idx_users_name; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_name ON auth.users USING btree (((raw_user_meta_data ->> 'name'::text))) WHERE ((raw_user_meta_data ->> 'name'::text) IS NOT NULL);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: mfa_recovery_codes_set_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_recovery_codes_set_id_idx ON auth.mfa_recovery_codes USING btree (mfa_recovery_code_set_id);


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_auth_pending_exp_idx ON auth.oauth_authorizations USING btree (expires_at) WHERE (status = 'pending'::auth.oauth_authorization_status);


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_active_client_idx ON auth.oauth_consents USING btree (client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_active_user_client_idx ON auth.oauth_consents USING btree (user_id, client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_user_order_idx ON auth.oauth_consents USING btree (user_id, granted_at DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: scim_tokens_expires_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX scim_tokens_expires_at_idx ON auth.scim_tokens USING btree (expires_at);


--
-- Name: scim_tokens_revoked_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX scim_tokens_revoked_at_idx ON auth.scim_tokens USING btree (revoked_at);


--
-- Name: scim_tokens_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX scim_tokens_sso_provider_id_idx ON auth.scim_tokens USING btree (sso_provider_id);


--
-- Name: scim_tokens_token_hash_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX scim_tokens_token_hash_key ON auth.scim_tokens USING btree (token_hash);


--
-- Name: scim_users_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX scim_users_created_at_idx ON auth.scim_users USING btree (sso_provider_id, created_at, id) WHERE (deleted_at IS NULL);


--
-- Name: scim_users_deleted_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX scim_users_deleted_at_idx ON auth.scim_users USING btree (deleted_at);


--
-- Name: scim_users_external_id_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX scim_users_external_id_key ON auth.scim_users USING btree (sso_provider_id, external_id) WHERE ((external_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: scim_users_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX scim_users_id_idx ON auth.scim_users USING btree (sso_provider_id, id) WHERE (deleted_at IS NULL);


--
-- Name: scim_users_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX scim_users_sso_provider_id_idx ON auth.scim_users USING btree (sso_provider_id);


--
-- Name: scim_users_updated_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX scim_users_updated_at_idx ON auth.scim_users USING btree (sso_provider_id, updated_at, id) WHERE (deleted_at IS NULL);


--
-- Name: scim_users_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX scim_users_user_id_idx ON auth.scim_users USING btree (user_id);


--
-- Name: scim_users_user_name_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX scim_users_user_name_idx ON auth.scim_users USING btree (sso_provider_id, user_name COLLATE "C", id) WHERE (deleted_at IS NULL);


--
-- Name: scim_users_user_name_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX scim_users_user_name_key ON auth.scim_users USING btree (sso_provider_id, user_name) WHERE (deleted_at IS NULL);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_oauth_client_id_idx ON auth.sessions USING btree (oauth_client_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_challenges_expires_at_idx ON auth.webauthn_challenges USING btree (expires_at);


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_challenges_user_id_idx ON auth.webauthn_challenges USING btree (user_id);


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX webauthn_credentials_credential_id_key ON auth.webauthn_credentials USING btree (credential_id);


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_credentials_user_id_idx ON auth.webauthn_credentials USING btree (user_id);


--
-- Name: category_system_role_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX category_system_role_idx ON public.category USING btree (ledger_id, system_role) WHERE (system_role IS NOT NULL);


--
-- Name: entry_ledger_account_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX entry_ledger_account_idx ON public.entry USING btree (ledger_id, account_id);


--
-- Name: entry_ledger_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX entry_ledger_category_idx ON public.entry USING btree (ledger_id, category_id);


--
-- Name: entry_transaction_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX entry_transaction_idx ON public.entry USING btree (transaction_id);


--
-- Name: portfolio_account_cuenta_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX portfolio_account_cuenta_idx ON public.portfolio_account USING btree (account_id);


--
-- Name: transaction_cross_ref_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transaction_cross_ref_idx ON public.transaction USING btree (cross_ref) WHERE (cross_ref IS NOT NULL);


--
-- Name: transaction_ledger_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transaction_ledger_date_idx ON public.transaction USING btree (ledger_id, occurred_on DESC);


--
-- Name: transaction_sched_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transaction_sched_idx ON public.transaction USING btree (scheduled_event_id) WHERE (scheduled_event_id IS NOT NULL);


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_selec; Type: INDEX; Schema: realtime; Owner: -
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_action_filter_selec ON realtime.subscription USING btree (subscription_id, entity, filters, action_filter, COALESCE(selected_columns, '{}'::text[]));


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX buckets_analytics_unique_name_idx ON storage.buckets_analytics USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name_lower ON storage.objects USING btree (bucket_id, lower(name) COLLATE "C");


--
-- Name: idx_objects_current_version; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX idx_objects_current_version ON storage.objects USING btree (bucket_id, name COLLATE "C") WHERE (archived_at IS NULL);


--
-- Name: idx_objects_null_version; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX idx_objects_null_version ON storage.objects USING btree (bucket_id, name COLLATE "C") WHERE (NOT is_versioned);


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: objects_bucket_id_name_version_key; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX objects_bucket_id_name_version_key ON storage.objects USING btree (bucket_id, name COLLATE "C", version) NULLS NOT DISTINCT;


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX vector_indexes_name_bucket_id_idx ON storage.vector_indexes USING btree (name, bucket_id);


--
-- Name: account_balance _RETURN; Type: RULE; Schema: public; Owner: -
--

CREATE OR REPLACE VIEW public.account_balance WITH (security_invoker='on') AS
 SELECT a.id AS account_id,
    a.ledger_id,
    a.name,
    a.kind,
    a.valuation,
    a.unit,
    a.is_spendable,
    a.institution,
    COALESCE(sum(e.amount), (0)::numeric) AS balance,
    count(e.id) AS movimientos
   FROM (public.account a
     LEFT JOIN public.entry e ON ((e.account_id = a.id)))
  WHERE (a.archived_at IS NULL)
  GROUP BY a.id;


--
-- Name: users on_auth_user_created; Type: TRIGGER; Schema: auth; Owner: -
--

CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();


--
-- Name: account account_cartera_del_broker; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER account_cartera_del_broker AFTER INSERT ON public.account FOR EACH ROW EXECUTE FUNCTION public.cartera_del_broker();


--
-- Name: category category_two_levels; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER category_two_levels BEFORE INSERT OR UPDATE ON public.category FOR EACH ROW EXECUTE FUNCTION public.check_category_depth();


--
-- Name: entry entry_unit_matches_account; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER entry_unit_matches_account BEFORE INSERT OR UPDATE ON public.entry FOR EACH ROW EXECUTE FUNCTION public.check_entry_unit();


--
-- Name: instrument instrument_lamina; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER instrument_lamina BEFORE INSERT ON public.instrument FOR EACH ROW EXECUTE FUNCTION public.lamina_por_defecto();


--
-- Name: scheduled_event scheduled_event_fin_de_mes; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER scheduled_event_fin_de_mes BEFORE INSERT OR UPDATE OF next_on, month_end ON public.scheduled_event FOR EACH ROW EXECUTE FUNCTION public.ajustar_fin_de_mes();


--
-- Name: entry transaction_balances; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER transaction_balances AFTER INSERT OR DELETE OR UPDATE ON public.entry DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.check_transaction_balances();


--
-- Name: transaction transaction_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER transaction_touch BEFORE UPDATE ON public.transaction FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: -
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER protect_buckets_delete BEFORE DELETE ON storage.buckets FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER protect_objects_delete BEFORE DELETE ON storage.objects FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_recovery_code_sets mfa_recovery_code_sets_mfa_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_recovery_code_sets
    ADD CONSTRAINT mfa_recovery_code_sets_mfa_factor_id_fkey FOREIGN KEY (mfa_factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_recovery_code_sets mfa_recovery_code_sets_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_recovery_code_sets
    ADD CONSTRAINT mfa_recovery_code_sets_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_recovery_codes mfa_recovery_codes_mfa_recovery_code_set_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_recovery_codes
    ADD CONSTRAINT mfa_recovery_codes_mfa_recovery_code_set_id_fkey FOREIGN KEY (mfa_recovery_code_set_id) REFERENCES auth.mfa_recovery_code_sets(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: scim_tokens scim_tokens_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.scim_tokens
    ADD CONSTRAINT scim_tokens_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: scim_users scim_users_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.scim_users
    ADD CONSTRAINT scim_users_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: scim_users scim_users_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.scim_users
    ADD CONSTRAINT scim_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_oauth_client_id_fkey FOREIGN KEY (oauth_client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: account account_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES public.ledger(id) ON DELETE CASCADE;


--
-- Name: active_ledger active_ledger_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_ledger
    ADD CONSTRAINT active_ledger_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES public.ledger(id) ON DELETE CASCADE;


--
-- Name: active_ledger active_ledger_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_ledger
    ADD CONSTRAINT active_ledger_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: budget budget_category_same_ledger; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget
    ADD CONSTRAINT budget_category_same_ledger FOREIGN KEY (category_id, ledger_id) REFERENCES public.category(id, ledger_id);


--
-- Name: budget budget_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget
    ADD CONSTRAINT budget_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES public.ledger(id) ON DELETE CASCADE;


--
-- Name: category category_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES public.ledger(id) ON DELETE CASCADE;


--
-- Name: category category_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.category(id);


--
-- Name: entry entry_account_same_ledger; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entry
    ADD CONSTRAINT entry_account_same_ledger FOREIGN KEY (account_id, ledger_id) REFERENCES public.account(id, ledger_id);


--
-- Name: entry entry_category_same_ledger; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entry
    ADD CONSTRAINT entry_category_same_ledger FOREIGN KEY (category_id, ledger_id) REFERENCES public.category(id, ledger_id);


--
-- Name: entry entry_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entry
    ADD CONSTRAINT entry_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES public.ledger(id) ON DELETE CASCADE;


--
-- Name: entry entry_tx_same_ledger; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entry
    ADD CONSTRAINT entry_tx_same_ledger FOREIGN KEY (transaction_id, ledger_id) REFERENCES public.transaction(id, ledger_id) ON DELETE CASCADE;


--
-- Name: fx_rate fx_rate_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fx_rate
    ADD CONSTRAINT fx_rate_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES public.ledger(id) ON DELETE CASCADE;


--
-- Name: instrument instrument_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.instrument
    ADD CONSTRAINT instrument_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES public.ledger(id) ON DELETE CASCADE;


--
-- Name: account instrument_same_ledger; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT instrument_same_ledger FOREIGN KEY (instrument_id, ledger_id) REFERENCES public.instrument(id, ledger_id);


--
-- Name: ledger_invite ledger_invite_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ledger_invite
    ADD CONSTRAINT ledger_invite_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: ledger_invite ledger_invite_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ledger_invite
    ADD CONSTRAINT ledger_invite_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES public.ledger(id) ON DELETE CASCADE;


--
-- Name: ledger_invite ledger_invite_used_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ledger_invite
    ADD CONSTRAINT ledger_invite_used_by_fkey FOREIGN KEY (used_by) REFERENCES auth.users(id);


--
-- Name: ledger_member ledger_member_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ledger_member
    ADD CONSTRAINT ledger_member_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES public.ledger(id) ON DELETE CASCADE;


--
-- Name: ledger_member ledger_member_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ledger_member
    ADD CONSTRAINT ledger_member_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: portfolio_account pa_account_same_ledger; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portfolio_account
    ADD CONSTRAINT pa_account_same_ledger FOREIGN KEY (account_id, ledger_id) REFERENCES public.account(id, ledger_id) ON DELETE CASCADE;


--
-- Name: portfolio_account pa_portfolio_same_ledger; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portfolio_account
    ADD CONSTRAINT pa_portfolio_same_ledger FOREIGN KEY (portfolio_id, ledger_id) REFERENCES public.portfolio(id, ledger_id) ON DELETE CASCADE;


--
-- Name: portfolio portfolio_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portfolio
    ADD CONSTRAINT portfolio_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES public.ledger(id) ON DELETE CASCADE;


--
-- Name: price price_instrument_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price
    ADD CONSTRAINT price_instrument_id_fkey FOREIGN KEY (instrument_id) REFERENCES public.instrument(id) ON DELETE CASCADE;


--
-- Name: price price_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price
    ADD CONSTRAINT price_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES public.ledger(id) ON DELETE CASCADE;


--
-- Name: scheduled_event sched_account_same_ledger; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_event
    ADD CONSTRAINT sched_account_same_ledger FOREIGN KEY (account_id, ledger_id) REFERENCES public.account(id, ledger_id);


--
-- Name: scheduled_event sched_category_same_ledger; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_event
    ADD CONSTRAINT sched_category_same_ledger FOREIGN KEY (category_id, ledger_id) REFERENCES public.category(id, ledger_id);


--
-- Name: scheduled_event sched_counter_same_ledger; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_event
    ADD CONSTRAINT sched_counter_same_ledger FOREIGN KEY (counter_account_id, ledger_id) REFERENCES public.account(id, ledger_id);


--
-- Name: scheduled_event scheduled_event_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_event
    ADD CONSTRAINT scheduled_event_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES public.ledger(id) ON DELETE CASCADE;


--
-- Name: transaction transaction_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT transaction_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: transaction transaction_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT transaction_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES public.ledger(id) ON DELETE CASCADE;


--
-- Name: transaction transaction_sched_same_ledger; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT transaction_sched_same_ledger FOREIGN KEY (scheduled_event_id, ledger_id) REFERENCES public.scheduled_event(id, ledger_id) ON DELETE SET NULL;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_vectors(id);


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: account; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.account ENABLE ROW LEVEL SECURITY;

--
-- Name: account account_activo_del; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY account_activo_del ON public.account FOR DELETE TO authenticated USING (((ledger_id = public.my_ledger()) AND (public.mi_rol() = 'owner'::text)));


--
-- Name: account account_activo_ro; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY account_activo_ro ON public.account FOR SELECT TO authenticated USING ((ledger_id = public.my_ledger()));


--
-- Name: account account_activo_rw; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY account_activo_rw ON public.account FOR INSERT TO authenticated WITH CHECK (((ledger_id = public.my_ledger()) AND (public.mi_rol() = 'owner'::text)));


--
-- Name: account account_activo_up; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY account_activo_up ON public.account FOR UPDATE TO authenticated USING (((ledger_id = public.my_ledger()) AND (public.mi_rol() = 'owner'::text))) WITH CHECK (((ledger_id = public.my_ledger()) AND (public.mi_rol() = 'owner'::text)));


--
-- Name: active_ledger; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.active_ledger ENABLE ROW LEVEL SECURITY;

--
-- Name: active_ledger active_ledger_self; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY active_ledger_self ON public.active_ledger TO authenticated USING ((user_id = auth.uid())) WITH CHECK ((user_id = auth.uid()));


--
-- Name: budget; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.budget ENABLE ROW LEVEL SECURITY;

--
-- Name: budget budget_activo_rw; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY budget_activo_rw ON public.budget TO authenticated USING ((ledger_id = public.my_ledger())) WITH CHECK ((ledger_id = public.my_ledger()));


--
-- Name: category; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.category ENABLE ROW LEVEL SECURITY;

--
-- Name: category category_activo_del; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY category_activo_del ON public.category FOR DELETE TO authenticated USING (((ledger_id = public.my_ledger()) AND (public.mi_rol() = 'owner'::text)));


--
-- Name: category category_activo_ro; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY category_activo_ro ON public.category FOR SELECT TO authenticated USING ((ledger_id = public.my_ledger()));


--
-- Name: category category_activo_rw; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY category_activo_rw ON public.category FOR INSERT TO authenticated WITH CHECK (((ledger_id = public.my_ledger()) AND (public.mi_rol() = 'owner'::text)));


--
-- Name: category category_activo_up; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY category_activo_up ON public.category FOR UPDATE TO authenticated USING (((ledger_id = public.my_ledger()) AND (public.mi_rol() = 'owner'::text))) WITH CHECK (((ledger_id = public.my_ledger()) AND (public.mi_rol() = 'owner'::text)));


--
-- Name: entry; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.entry ENABLE ROW LEVEL SECURITY;

--
-- Name: entry entry_activo_rw; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY entry_activo_rw ON public.entry TO authenticated USING ((ledger_id = public.my_ledger())) WITH CHECK ((ledger_id = public.my_ledger()));


--
-- Name: fx_rate; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fx_rate ENABLE ROW LEVEL SECURITY;

--
-- Name: fx_rate fx_rate_activo_rw; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY fx_rate_activo_rw ON public.fx_rate TO authenticated USING ((ledger_id = public.my_ledger())) WITH CHECK ((ledger_id = public.my_ledger()));


--
-- Name: instrument; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.instrument ENABLE ROW LEVEL SECURITY;

--
-- Name: instrument instrument_activo_del; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY instrument_activo_del ON public.instrument FOR DELETE TO authenticated USING (((ledger_id = public.my_ledger()) AND (public.mi_rol() = 'owner'::text)));


--
-- Name: instrument instrument_activo_ro; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY instrument_activo_ro ON public.instrument FOR SELECT TO authenticated USING ((ledger_id = public.my_ledger()));


--
-- Name: instrument instrument_activo_rw; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY instrument_activo_rw ON public.instrument FOR INSERT TO authenticated WITH CHECK (((ledger_id = public.my_ledger()) AND (public.mi_rol() = 'owner'::text)));


--
-- Name: instrument instrument_activo_up; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY instrument_activo_up ON public.instrument FOR UPDATE TO authenticated USING (((ledger_id = public.my_ledger()) AND (public.mi_rol() = 'owner'::text))) WITH CHECK (((ledger_id = public.my_ledger()) AND (public.mi_rol() = 'owner'::text)));


--
-- Name: ledger; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ledger ENABLE ROW LEVEL SECURITY;

--
-- Name: ledger ledger_activo; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ledger_activo ON public.ledger FOR SELECT TO authenticated USING ((id IN ( SELECT public.my_ledgers() AS my_ledgers)));


--
-- Name: ledger_invite; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ledger_invite ENABLE ROW LEVEL SECURITY;

--
-- Name: ledger_member; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ledger_member ENABLE ROW LEVEL SECURITY;

--
-- Name: ledger_member ledger_member_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ledger_member_admin ON public.ledger_member TO authenticated USING (((ledger_id = public.my_ledger()) AND (public.mi_rol() = 'owner'::text))) WITH CHECK (((ledger_id = public.my_ledger()) AND (public.mi_rol() = 'owner'::text)));


--
-- Name: ledger_member ledger_member_ver; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ledger_member_ver ON public.ledger_member FOR SELECT TO authenticated USING ((ledger_id IN ( SELECT public.my_ledgers() AS my_ledgers)));


--
-- Name: portfolio; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.portfolio ENABLE ROW LEVEL SECURITY;

--
-- Name: portfolio_account; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.portfolio_account ENABLE ROW LEVEL SECURITY;

--
-- Name: portfolio_account portfolio_account_activo; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY portfolio_account_activo ON public.portfolio_account TO authenticated USING ((ledger_id = public.my_ledger())) WITH CHECK ((ledger_id = public.my_ledger()));


--
-- Name: portfolio portfolio_member_rw; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY portfolio_member_rw ON public.portfolio TO authenticated USING ((ledger_id IN ( SELECT public.my_ledgers() AS my_ledgers))) WITH CHECK ((ledger_id IN ( SELECT public.my_ledgers() AS my_ledgers)));


--
-- Name: price; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.price ENABLE ROW LEVEL SECURITY;

--
-- Name: price price_activo_rw; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY price_activo_rw ON public.price TO authenticated USING ((ledger_id = public.my_ledger())) WITH CHECK ((ledger_id = public.my_ledger()));


--
-- Name: scheduled_event; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.scheduled_event ENABLE ROW LEVEL SECURITY;

--
-- Name: scheduled_event scheduled_event_activo_rw; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY scheduled_event_activo_rw ON public.scheduled_event TO authenticated USING ((ledger_id = public.my_ledger())) WITH CHECK ((ledger_id = public.my_ledger()));


--
-- Name: transaction; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.transaction ENABLE ROW LEVEL SECURITY;

--
-- Name: transaction transaction_activo_rw; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY transaction_activo_rw ON public.transaction TO authenticated USING ((ledger_id = public.my_ledger())) WITH CHECK ((ledger_id = public.my_ledger()));


--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_vectors ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.vector_indexes ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: -
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


--
-- Name: ensure_rls; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER ensure_rls ON ddl_command_end
         WHEN TAG IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO')
   EXECUTE FUNCTION public.rls_auto_enable();


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


--
-- PostgreSQL database dump complete
--

\unrestrict qqZbKaGM48j2aFVAPpFEBu3mHCfawWZUAZdqu2MVQIgzVXBTk4lKFSw6gqOMGYp

